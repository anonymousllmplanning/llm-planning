# Gemma4 Filtered DAGs

This folder contains the replay-filtered Augmented GAIA DAG view.

- Source DAGs: `DAGs`
- Replay evidence: `replay_evidence/gemma4_replay_validation_catA_20260501_catBCD_20260502.combined.jsonl`
- Filter policy: `gemma4_behavior_preserving_replay_filter`
- Replay model: `gemma-4-31B-it`

`DAGs/` stores GPT-4o dependency annotations and all candidate async orderings.
This folder keeps the same task-level dependency DAGs, but replaces
`sampled_orderings` with only the Gemma4 behavior-preserving replay-retained
orderings. Tasks with no retained async ordering remain present and have an
empty `sampled_orderings` list, so the native chain remains the fallback
reference during evaluation.
