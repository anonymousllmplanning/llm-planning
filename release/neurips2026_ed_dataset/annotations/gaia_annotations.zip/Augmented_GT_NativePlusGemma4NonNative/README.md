# Augmented GT: native plus Gemma4-retained non-native rows

This derived view starts from `data/Augmented/DAGs/gaia_cat_*_async_plan.jsonl`, removes retained identity/native sampled orderings from `sampled_orderings`, and then inserts exactly one native chain reference `[0, 1, ..., n-1]` for every task.

Thus each task has the native chain plus all Gemma4 behavior-preserving replay-retained non-native async orderings.

Key counts: 165 native chain references + 1,357 Gemma4-retained non-native async ordering rows = 1,522 total ordering rows in this view.
