# Augmented GAIA Annotation Bundle

This bundle omits GAIA questions, final answers, and attachments. It is
intended to be merged with an official GAIA snapshot by
`scripts/prepare_gaia_from_official.py`.

The final scoring view is `Augmented_GT_NativePlusGemma4NonNative`: one
native chain reference per GAIA task plus Gemma 4-retained non-native
async orderings. Rebuilding maps this view to `data/Augmented/DAGs` for
compatibility with the experiment scripts.

Caution: planning step labels and tool annotations are derived benchmark
annotations and may reveal task-specific solution structure. Distribute
this bundle through the controlled artifact channel chosen for release.
