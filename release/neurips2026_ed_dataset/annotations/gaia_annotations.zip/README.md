# Augmented GAIA Annotation Bundle

This bundle omits GAIA questions, final answers, and attachments. It is
intended to be merged with an official GAIA snapshot by
`scripts/prepare_gaia_from_official.py`.

Caution: planning step labels and tool annotations are derived benchmark
annotations and may reveal task-specific solution structure. Distribute
this bundle through the controlled artifact channel chosen for release.
