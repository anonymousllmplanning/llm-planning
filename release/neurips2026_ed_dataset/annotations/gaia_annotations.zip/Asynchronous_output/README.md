# GPT-4o annotations non-native rows

This derived view starts from `Asynchronous/gaia_cat_*_async_plan.jsonl` and keeps the original JSONL schema, but removes identity/native sampled orderings of the form `[0, 1, ..., n-1]` from `sampled_orderings`.

The remaining rows are GPT-4o dependency-preserving non-native candidate async orderings. They have not yet been Gemma4 replay-filtered.

Key count: 1,771 non-native candidate async ordering rows across 165 GAIA tasks.
