# Paper Results Snapshot

This folder collects paper-facing result summaries regenerated from the current experiment outputs.

## Gemma4 replay validation
- Total candidate ordering rows: 1913 (100.0% (1913/1913))
- Retained under gold-equivalent behavior-preserving replay: 1468 (76.7% (1468/1913))
- Filtered: 445 (23.3% (445/1913))
- Native chain replay unavailable or failed: 90 (20.2% (90/445) of filtered)
- Ordering-specific non-reproducible outcome: 355 (79.8% (355/445) of filtered)

## Key files
- `official_modified_gt_20260504/`: official modified-GT recomputation for GAIA ToolF1 and alternative-aware ATS/tool-clean subsets. The raw organized results are not modified.
- `gemma4_replay_validation/replay_filter_summary.csv`: headline replay filter counts.
- `gemma4_replay_validation/replay_transition_counts.csv`: all replay outcome transitions.
- `dataset/gaia_domain_construction_summary.csv`: original GAIA and Augmented GAIA construction summary by scenario.
- `dataset/gaia_level_construction_summary.csv`: construction summary by difficulty level.
- `dataset/gaia_domain_tool_mapping.csv`: scenario-to-tool-interface mapping.
- `tables/table2_gaia_three_facet_headline.csv`, `tables/table3_score_lift_augmented_reference.csv`, `tables/table4_level2_toolclean_text_document_audio_correlation.csv`: current paper table data.
- `gaia_dataset_profile.md`: consolidated dataset-construction table for original GAIA and Augmented GAIA.
- `tables/table_cross_benchmark_taskbench_ultratool.csv`: TaskBench/UltraTool staged table with UltraTool Llama-3.1 405B integrated.
- `tables/benchmark_completion_status.csv`: raw-output completion status for TaskBench/UltraTool models.
- `tables/table5_tool_intensive_level2_text_document_audio_correlation.csv`: tool-intensive Level 2 Text/Document/Audio diagnostic table.

## Modified-GT tool scoring
- Cat_B document-access gold slots are displayed and scored with typed reader alternatives (`excel_reader`, `file_reader`, `pdf_reader`, `pptx_reader`, `zip_extractor`) while preserving the original code-execution realization as an equivalent candidate.
- Cat_A was audited but left unchanged; candidate additions are review-only.
- ToolF1 and ATS/tool-clean subsets in the paper-facing GAIA tables are computed from `official_modified_gt_20260504`.
