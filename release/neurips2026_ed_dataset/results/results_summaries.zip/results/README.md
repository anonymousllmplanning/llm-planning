# Result Artifacts

This directory contains paper-supporting result artifacts that are safe to keep
in the public repository. It intentionally excludes paper manuscripts, compiled
paper PDFs, LaTeX build products, and local `version2/` workspace files.

## Layout

- `paper/tables/`: CSV tables used for the main and appendix results.
- `paper/dataset/`: Augmented GAIA construction summaries by domain, level, and
  retained async-ordering bucket.
- `paper/gemma4_replay_validation/`: replay-filter aggregate summaries and a
  sanitized row manifest produced from the Gemma 4 replay validation runs.
- `replay_evidence/`: sanitized replay summary counts, transition counts, and
  checksums. Raw replay traces and answer strings are intentionally excluded.
- `paper/official_modified_gt_20260504/`: modified-GT scoring outputs used for
  the final tool-reference layer.
- `paper/value_f1_v2/`: ParamValueF1 audit outputs.
- `paper/tool_type_f1_audit_20260504/` and
  `paper/tool_candidate_overlay_20260504/`: tool-reference and ToolF1 audit
  artifacts.
- `paper/tool_related_subset_20260504/`: tool-clean and tool-intensive
  correlation slices.
- `paper/figure_exports/`: exported figure assets and number audit notes.

The current paper workspace remains local and ignored. Do not add
`version2/paper/final.tex` or `version2/paper/final.pdf` to the repository.
