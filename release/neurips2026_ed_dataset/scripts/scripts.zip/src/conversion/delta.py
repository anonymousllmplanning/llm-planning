#!/usr/bin/env python3
"""
Convert Delta MCP dataset to unified format for LLM planning evaluation.

Delta datasets come in two files:
1. queries JSON: Contains query with ground_truth_tools (nested list with dependencies)
2. tools JSON: Contains server/tool catalog with input_schema

This converter:
- Handles both new_delta (17 tools) and old_delta (2397 tools)
- Preserves alternative tools from nested ground_truth structure
- Extracts proper parameter schemas from tool catalog
- Creates proper unified format with plan_dag, tool_calls, and tool_environment

Usage:
    python convert_delta_to_unified.py \
        --queries new_queries_delta.json \
        --tools new_tools_delta.json \
        --output unified_new_delta.jsonl
"""

import json
import argparse
from pathlib import Path
from typing import Dict, Any, List, Optional, Set, Tuple


def load_tool_catalog(tools_path: Path) -> Tuple[Dict[str, Dict], List[Dict]]:
    """
    Load tool catalog and build lookup by tool_id.
    
    Returns:
        - tool_lookup: Dict mapping tool_id -> tool info with schema
        - flat_tools: List of all tools in flat format for tool_environment
    """
    with open(tools_path) as f:
        data = json.load(f)
    
    tool_lookup = {}
    flat_tools = []
    
    for server in data.get("servers", []):
        server_name = server.get("server_name", "")
        for tool in server.get("tools", []):
            tool_name = tool.get("tool_name", "")
            tool_id = f"{server_name}::{tool_name}"
            
            # Build arguments schema from input_schema
            input_schema = tool.get("input_schema", {})
            properties = input_schema.get("properties", {})
            required_fields = input_schema.get("required", [])
            
            arguments_schema = {}
            for prop_name, prop_spec in properties.items():
                arguments_schema[prop_name] = {
                    "type": prop_spec.get("type", "string"),
                    "description": prop_spec.get("description", ""),
                    "required": prop_name in required_fields,
                }
            
            tool_info = {
                "tool_id": tool_id,
                "tool_name": tool_name,
                "server_name": server_name,
                "description": tool.get("tool_description", ""),
                "arguments_schema": arguments_schema,
            }
            
            tool_lookup[tool_id] = tool_info
            flat_tools.append(tool_info)
    
    print(f"[INFO] Loaded {len(flat_tools)} tools from catalog")
    return tool_lookup, flat_tools


def extract_plan_dag_and_tool_calls(
    ground_truth_tools: List[List[Dict]],
    tool_lookup: Dict[str, Dict]
) -> Tuple[Dict, List[Dict]]:
    """
    Convert Delta's nested ground_truth_tools to plan_dag and tool_calls.
    
    Delta's ground_truth_tools structure:
    [
        [tool_at_step_0],  # Step 0: one tool (no dependencies)
        [tool_at_step_1],  # Step 1: depends on step 0
        [tool_at_step_2_option_a, tool_at_step_2_option_b],  # Step 2: alternatives
    ]
    
    Each tool has:
    - tool_id: "server_name::tool_name"
    - dependencies: list of step indices this step depends on
    """
    nodes = []
    edges = []
    tool_calls = []
    
    for step_idx, step_tools in enumerate(ground_truth_tools):
        if not step_tools:
            continue
        
        # Primary tool (first in list)
        primary_tool = step_tools[0]
        tool_id = primary_tool.get("tool_id", "")
        tool_name = primary_tool.get("tool_name", "")
        description = primary_tool.get("description", "")[:100]
        dependencies = primary_tool.get("dependencies", [])
        
        # Alternative tools (rest of list)
        alternative_tools = []
        for alt in step_tools[1:]:
            alt_id = alt.get("tool_id")
            if alt_id:
                alternative_tools.append(alt_id)
        
        # Create node
        node = {
            "node_id": f"n{step_idx}",
            "step_index": step_idx,
            "label": f"Call {tool_name}: {description}",
            "step_type": "tool",
            "tool_id": tool_id,
            "alternative_tools": alternative_tools,
            "arguments": {},  # Delta doesn't specify argument values
            "output_vars": [f"<n{step_idx}>"],
            "needs_tool": True,
            "needs_new_tool": False,
        }
        nodes.append(node)
        
        # Create edges from dependencies
        for dep_idx in dependencies:
            edges.append({
                "source": f"n{dep_idx}",
                "target": f"n{step_idx}",
                "edge_type": "data_dep",  # Assume data dependency
            })
        
        # Create tool_call
        tool_call = {
            "call_index": step_idx,
            "node_id": f"n{step_idx}",
            "tool_id": tool_id,
            "alternative_tools": alternative_tools,
            "arguments": [],  # No argument values in Delta
        }
        tool_calls.append(tool_call)
    
    plan_dag = {
        "nodes": nodes,
        "edges": edges,
    }
    
    return plan_dag, tool_calls


def convert_delta_to_unified(
    queries_path: Path,
    tools_path: Path,
    output_path: Path,
    dataset_name: str = "delta",
    subset_name: str = "default"
):
    """
    Convert Delta dataset to unified format.
    """
    # Load tool catalog
    tool_lookup, flat_tools = load_tool_catalog(tools_path)
    
    # Load queries
    with open(queries_path) as f:
        queries = json.load(f)
    
    print(f"[INFO] Converting {len(queries)} queries to unified format")
    
    # Convert each query
    with open(output_path, "w") as out_f:
        for query_data in queries:
            query_id = query_data.get("query_id")
            query_text = query_data.get("query", "")
            ground_truth_tools = query_data.get("ground_truth_tools", [])
            expected_tool_count = query_data.get("ground_truth_tools_count", 0)
            
            # Extract plan_dag and tool_calls from ground_truth
            plan_dag, tool_calls = extract_plan_dag_and_tool_calls(
                ground_truth_tools, tool_lookup
            )
            
            # Build unified record
            unified = {
                "meta": {
                    "id": str(query_id),
                    "dataset": dataset_name,
                    "subset": subset_name,
                    "plan_type": "dag" if len(tool_calls) > 1 else "single",
                    "expected_tool_count": expected_tool_count,
                },
                "query": {
                    "user_query": query_text,
                    "extra_instruction": None,
                },
                "tool_environment": {
                    "tools": flat_tools,  # Full catalog for model to choose from
                },
                "gold": {
                    "plan_dag": plan_dag,
                    "tool_calls": tool_calls,
                    "final_answer": {
                        "answer_type": "none",
                        "answer": None,
                        "aliases": [],
                        "tolerance": 0.0,
                    },
                },
            }
            
            out_f.write(json.dumps(unified, ensure_ascii=False) + "\n")
    
    print(f"[INFO] Output written to: {output_path}")
    print(f"[INFO] Converted {len(queries)} queries")


def main():
    parser = argparse.ArgumentParser(
        description="Convert Delta MCP dataset to unified format",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--queries", type=Path, required=True,
        help="Path to queries JSON (e.g., new_queries_delta.json)"
    )
    parser.add_argument(
        "--tools", type=Path, required=True,
        help="Path to tools JSON (e.g., new_tools_delta.json)"
    )
    parser.add_argument(
        "--output", type=Path, required=True,
        help="Output path for unified JSONL"
    )
    parser.add_argument(
        "--dataset_name", type=str, default="delta",
        help="Dataset name for metadata"
    )
    parser.add_argument(
        "--subset_name", type=str, default="default",
        help="Subset name for metadata"
    )
    
    args = parser.parse_args()
    
    convert_delta_to_unified(
        queries_path=args.queries,
        tools_path=args.tools,
        output_path=args.output,
        dataset_name=args.dataset_name,
        subset_name=args.subset_name,
    )


if __name__ == "__main__":
    main()