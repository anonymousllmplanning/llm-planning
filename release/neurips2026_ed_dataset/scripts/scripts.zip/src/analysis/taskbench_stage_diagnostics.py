#!/usr/bin/env python3
"""
Recompute TaskBench planning metrics under the current PlanningScore definition.

PlanningScore = (SpanNodeF1 + DW-OrderF1) / 2

The script re-evaluates TaskBench unified runs with the current evaluator, then
joins stable tool-grounding / parse-error values from the existing
`organized_results/taskbench/figures/overall_metrics_table.csv` so the paper's
order-based table can stay aligned with prior TaskBench reporting.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from statistics import mean
from typing import Dict, List

from src.evaluation.metrics import ASTEvaluationSystem


def _read_existing_overall(path: Path) -> Dict[str, Dict[str, float]]:
    rows: Dict[str, Dict[str, float]] = {}
    with path.open() as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows[row["model"]] = {
                "tool_usage_score": float(row["tool_usage_score"]),
                "parse_error_rate": float(row["parse_error_rate"]),
            }
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description="Recompute TaskBench planning metrics under the current PlanningScore.")
    parser.add_argument(
        "--taskbench_dir",
        type=Path,
        default=Path("organized_results/taskbench"),
        help="Directory containing unified.*.jsonl TaskBench runs.",
    )
    parser.add_argument(
        "--legacy_overall_csv",
        type=Path,
        default=Path("organized_results/taskbench/figures/overall_metrics_table.csv"),
        help="Existing overall metrics CSV used to preserve tool-grounding and parse-error columns.",
    )
    parser.add_argument(
        "--output_csv",
        type=Path,
        default=Path("docs/neurips/generated/taskbench_stage_main.csv"),
        help="Where to write the merged TaskBench table data.",
    )
    args = parser.parse_args()

    evaluator = ASTEvaluationSystem(use_embeddings=False, verifier_model=None)
    legacy = _read_existing_overall(args.legacy_overall_csv)
    rows: List[Dict[str, float]] = []

    for unified_path in sorted(args.taskbench_dir.glob("unified.*.jsonl")):
        model = unified_path.stem.replace("unified.", "")
        per_sample = []
        with unified_path.open() as f:
            for line in f:
                rec = json.loads(line)
                gold_dag = (rec.get("gold") or {}).get("plan_dag") or {"nodes": [], "edges": []}
                pred_dag = (rec.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []}
                scores = evaluator.evaluate_plan_dag(gold_dag, pred_dag)
                per_sample.append(scores)

        rows.append({
            "model": model,
            "n": len(per_sample),
            "planning_score": mean(s.planning_score for s in per_sample),
            "span_node_f1": mean(s.span_node_f1 for s in per_sample),
            "semantic_node_f1": mean(s.span_node_f1 for s in per_sample),
            "strict_node_f1": mean(s.strict_node_f1 for s in per_sample),
            "dw_order_f1": mean(s.dw_order_f1 for s in per_sample),
            "edge_f1": mean(s.edge_f1 for s in per_sample),
            "semantic_edge_f1": mean(s.semantic_edge_f1 for s in per_sample),
            "order_precision": mean(s.order_precision for s in per_sample),
            "order_recall": mean(s.order_recall for s in per_sample),
            "order_f1": mean(s.order_f1 for s in per_sample),
            "tool_usage_score": legacy.get(model, {}).get("tool_usage_score"),
            "parse_error_rate": legacy.get(model, {}).get("parse_error_rate"),
        })

    rows.sort(key=lambda row: (-(row["planning_score"] or 0.0), row["model"]))
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    print(f"[OK] Wrote {args.output_csv}")


if __name__ == "__main__":
    main()
