#!/usr/bin/env python3
"""
Correlation Analysis for Three-Facet Evaluation Framework

Analyzes correlations between:
- Facet A: Planning Fidelity (PlanningScore = avg(SpanNodeF1, DW-Order F1))
- Facet B: Tool Awareness (ToolUsageScore when available; otherwise Tool F1)
- Facet C: Answer Accuracy (Exact Match, Token F1)

Usage:
    python -m src.analysis.correlation_analysis --results_dir ./organized_results/gaia/cat_B/xxx
    python -m src.analysis.correlation_analysis --results_dir ./organized_results/gaia/cat_B/xxx --output_dir ./analysis_output
"""

import json
import argparse
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import sys

# Import numpy and scipy (available in project requirements)
import numpy as np
from scipy.stats import pearsonr, spearmanr

# Import matplotlib for visualization
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Model name mapping to unify variants
MODEL_NAME_MAPPING = {
    "Llama-3.3-70B-Instruct-Gaudi3": "Llama-3.3-70B-Instruct",
    "Llama-3.3-70B-Instruct-MI210": "Llama-3.3-70B-Instruct",
}


def _planning_score(sample: Dict) -> float:
    existing = sample.get("planning_score")
    try:
        if existing is not None and not np.isnan(float(existing)):
            return float(existing)
    except (TypeError, ValueError):
        pass
    span_node_f1 = sample.get("span_node_f1", sample.get("node_f1", np.nan))
    dw_order_f1 = sample.get("dw_order_f1", np.nan)
    return (float(span_node_f1) + float(dw_order_f1)) / 2


def load_per_sample_data(results_dir: Path) -> Dict[str, List[Dict]]:
    """
    Load per-sample CSV data for all models.

    Returns:
        {model_name: [sample_dict, ...], ...}
    """
    import pandas as pd

    data_by_model = {}

    # Find all per_sample.*.csv files
    for csv_file in results_dir.glob("per_sample.*.csv"):
        # Extract model name from filename
        model_name = csv_file.stem.replace("per_sample.", "")
        # Apply name mapping to unify variants
        model_name = MODEL_NAME_MAPPING.get(model_name, model_name)

        try:
            df = pd.read_csv(csv_file)
            # Convert to list of dicts
            samples = df.to_dict('records')
            data_by_model[model_name] = samples
            print(f"  Loaded {len(samples)} samples for model: {model_name}")
        except Exception as e:
            print(f"  [WARN] Failed to load {csv_file}: {e}")

    return data_by_model


def compute_pearson_correlation(
    facet_a: List[float],
    facet_b: List[float],
    facet_names: Tuple[str, str]
) -> Dict:
    """
    Compute Pearson correlation between two facet scores.

    Returns:
        {
            "r": correlation coefficient,
            "p_value": p-value,
            "n": sample size,
            "interpretation": strength interpretation
        }
    """
    # Filter out NaN values
    valid_pairs = [(a, b) for a, b in zip(facet_a, facet_b) if not (np.isnan(a) or np.isnan(b))]

    if len(valid_pairs) < 3:
        return {
            "r": np.nan,
            "p_value": np.nan,
            "n": len(valid_pairs),
            "interpretation": "insufficient data"
        }

    facet_a_clean, facet_b_clean = zip(*valid_pairs)

    r, p_value = pearsonr(facet_a_clean, facet_b_clean)

    # Interpret correlation strength
    abs_r = abs(r)
    if abs_r < 0.3:
        strength = "weak"
    elif abs_r < 0.7:
        strength = "moderate"
    else:
        strength = "strong"

    direction = "positive" if r > 0 else "negative"
    interpretation = f"{strength} {direction}" if not np.isnan(r) else "no correlation"

    return {
        "r": r,
        "p_value": p_value,
        "n": len(valid_pairs),
        "interpretation": interpretation,
        "facet_pair": f"{facet_names[0]} vs {facet_names[1]}"
    }


def analyze_model_correlations(samples: List[Dict], model_name: str) -> Dict:
    """
    Analyze correlations for a single model.

    Returns:
        {
            "model": model_name,
            "n_samples": int,
            "plan_tool": {...},
            "plan_answer": {...},
            "tool_answer": {...}
        }
    """
    # Extract facet scores
    facet_a_plan = [_planning_score(s) for s in samples]
    facet_b_tool = [
        s.get("tool_usage_score",
              np.nanmean([
                  s.get("tool_name_f1", np.nan),
                  s.get("param_name_f1", np.nan),
                  s.get("type_aware_value_f1", np.nan),
              ]))
        for s in samples
    ]

    # For answer, only use samples that have answers
    facet_c_em = []
    facet_a_plan_with_answer = []
    facet_b_tool_with_answer = []

    for s in samples:
        if s.get("has_answer", False):
            facet_c_em.append(s.get("exact_match", np.nan))
            facet_a_plan_with_answer.append(_planning_score(s))
            facet_b_tool_with_answer.append(
                s.get("tool_usage_score",
                      np.nanmean([
                          s.get("tool_name_f1", np.nan),
                          s.get("param_name_f1", np.nan),
                          s.get("type_aware_value_f1", np.nan),
                      ]))
            )

    # Compute correlations
    plan_tool_corr = compute_pearson_correlation(facet_a_plan, facet_b_tool, ("PlanningScore", "ToolUsageScore"))

    plan_answer_corr = compute_pearson_correlation(
        facet_a_plan_with_answer, facet_c_em, ("PlanningScore", "Exact Match")
    )

    tool_answer_corr = compute_pearson_correlation(
        facet_b_tool_with_answer, facet_c_em, ("ToolUsageScore", "Exact Match")
    )

    return {
        "model": model_name,
        "n_samples": len(samples),
        "n_with_answer": len(facet_c_em),
        "plan_tool": plan_tool_corr,
        "plan_answer": plan_answer_corr,
        "tool_answer": tool_answer_corr
    }


def plot_correlation_heatmap(correlations: List[Dict], output_path: Path):
    """
    Plot correlation heatmap for all models.
    """
    models = [c["model"] for c in correlations]

    # Prepare data matrix
    data = []
    for c in correlations:
        row = [
            c["plan_tool"]["r"],
            c["plan_answer"]["r"],
            c["tool_answer"]["r"]
        ]
        data.append(row)

    data = np.array(data)

    # Create heatmap using matplotlib
    fig, ax = plt.subplots(figsize=(8, len(models) * 0.6 + 2))

    # Plot heatmap
    im = ax.imshow(data, cmap="RdYlGn", vmin=-1, vmax=1, aspect='auto')

    # Add colorbar
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label("Pearson r", fontsize=11)

    # Set ticks and labels
    ax.set_xticks(np.arange(3))
    ax.set_yticks(np.arange(len(models)))
    ax.set_xticklabels(["Plan-Tool", "Plan-Answer", "Tool-Answer"])
    ax.set_yticklabels(models)

    # Add text annotations
    for i in range(len(models)):
        for j in range(3):
            text = ax.text(j, i, f'{data[i, j]:.3f}',
                          ha="center", va="center", color="black", fontsize=10, fontweight='bold')

    ax.set_title("Facet Correlation Analysis (Pearson r)", fontsize=14, fontweight='bold')
    ax.set_xlabel("Facet Pair", fontsize=12)
    ax.set_ylabel("Model", fontsize=12)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.savefig(output_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close()

    print(f"  [SAVED] Correlation heatmap: {output_path}")


def plot_scatter_facets(samples: List[Dict], model_name: str, output_dir: Path):
    """
    Plot scatter plots for facet pairs.
    """
    # Extract data
    planning_score = [_planning_score(s) for s in samples]
    tool_usage = [
        s.get("tool_usage_score",
              np.nanmean([
                  s.get("tool_name_f1", np.nan),
                  s.get("param_name_f1", np.nan),
                  s.get("type_aware_value_f1", np.nan),
              ]))
        for s in samples
    ]
    em = [s.get("exact_match", np.nan) if s.get("has_answer", False) else np.nan for s in samples]

    # Filter valid data
    def filter_valid(x, y):
        valid = [(xi, yi) for xi, yi in zip(x, y) if not (np.isnan(xi) or np.isnan(yi))]
        if valid:
            return zip(*valid)
        return [], []

    fig, axes = plt.subplots(1, 3, figsize=(15, 4))

    # Plan vs Tool
    x, y = filter_valid(planning_score, tool_usage)
    if x:
        axes[0].scatter(x, y, alpha=0.6, s=50, edgecolors='black', linewidth=0.5)
        axes[0].set_xlabel("PlanningScore", fontsize=11)
        axes[0].set_ylabel("ToolUsageScore", fontsize=11)
        axes[0].set_title(f"Plan-Tool Correlation", fontsize=12)
        axes[0].grid(True, alpha=0.3)

        # Add trend line
        if len(x) >= 2:
            try:
                # Check if data has variance
                if np.std(x) > 1e-10 and np.std(y) > 1e-10:
                    z = np.polyfit(x, y, 1)
                    p = np.poly1d(z)
                    x_line = np.linspace(min(x), max(x), 100)
                    axes[0].plot(x_line, p(x_line), "r--", alpha=0.8, linewidth=2)
            except (np.linalg.LinAlgError, ValueError):
                pass  # Skip trend line if numerical issues

    # Plan vs Answer
    x, y = filter_valid(planning_score, em)
    if x:
        axes[1].scatter(x, y, alpha=0.6, s=50, edgecolors='black', linewidth=0.5)
        axes[1].set_xlabel("PlanningScore", fontsize=11)
        axes[1].set_ylabel("Exact Match", fontsize=11)
        axes[1].set_title(f"Plan-Answer Correlation", fontsize=12)
        axes[1].grid(True, alpha=0.3)

        if len(x) >= 2:
            try:
                if np.std(x) > 1e-10 and np.std(y) > 1e-10:
                    z = np.polyfit(x, y, 1)
                    p = np.poly1d(z)
                    x_line = np.linspace(min(x), max(x), 100)
                    axes[1].plot(x_line, p(x_line), "r--", alpha=0.8, linewidth=2)
            except (np.linalg.LinAlgError, ValueError):
                pass

    # Tool vs Answer
    x, y = filter_valid(tool_usage, em)
    if x:
        axes[2].scatter(x, y, alpha=0.6, s=50, edgecolors='black', linewidth=0.5)
        axes[2].set_xlabel("ToolUsageScore", fontsize=11)
        axes[2].set_ylabel("Exact Match", fontsize=11)
        axes[2].set_title(f"Tool-Answer Correlation", fontsize=12)
        axes[2].grid(True, alpha=0.3)

        if len(x) >= 2:
            try:
                if np.std(x) > 1e-10 and np.std(y) > 1e-10:
                    z = np.polyfit(x, y, 1)
                    p = np.poly1d(z)
                    x_line = np.linspace(min(x), max(x), 100)
                    axes[2].plot(x_line, p(x_line), "r--", alpha=0.8, linewidth=2)
            except (np.linalg.LinAlgError, ValueError):
                pass

    fig.suptitle(f"Facet Scatter Plots - {model_name}", fontsize=14, fontweight='bold')
    plt.tight_layout()

    output_path = output_dir / f"scatter_{model_name}.png"
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()

    print(f"  [SAVED] Scatter plots: {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Facet Correlation Analysis for LLM Planning Framework"
    )
    parser.add_argument(
        "--results_dir",
        type=str,
        required=True,
        help="Directory containing per_sample.*.csv files"
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=None,
        help="Output directory for analysis results (default: {results_dir}/correlation_analysis)"
    )
    args = parser.parse_args()

    results_dir = Path(args.results_dir)

    if not results_dir.exists():
        print(f"[ERROR] Results directory not found: {results_dir}")
        sys.exit(1)

    # Determine output directory
    if args.output_dir:
        output_dir = Path(args.output_dir)
    else:
        output_dir = results_dir / "correlation_analysis"

    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 70)
    print("Facet Correlation Analysis")
    print("=" * 70)
    print(f"Results directory: {results_dir}")
    print(f"Output directory: {output_dir}")
    print()

    # Load data
    print("Loading per-sample data...")
    data_by_model = load_per_sample_data(results_dir)

    if not data_by_model:
        print("[ERROR] No per_sample.*.csv files found")
        sys.exit(1)

    print(f"Found {len(data_by_model)} models")
    print()

    # Analyze correlations
    print("Computing correlations...")
    all_correlations = []

    for model_name, samples in data_by_model.items():
        print(f"\n  Analyzing model: {model_name}")
        corr = analyze_model_correlations(samples, model_name)
        all_correlations.append(corr)

        # Print summary
        print(f"    Samples: {corr['n_samples']} (with answer: {corr['n_with_answer']})")
        print(f"    Plan-Tool:   r={corr['plan_tool']['r']:.3f}, p={corr['plan_tool']['p_value']:.4f} ({corr['plan_tool']['interpretation']})")
        print(f"    Plan-Answer: r={corr['plan_answer']['r']:.3f}, p={corr['plan_answer']['p_value']:.4f} ({corr['plan_answer']['interpretation']})")
        print(f"    Tool-Answer: r={corr['tool_answer']['r']:.3f}, p={corr['tool_answer']['p_value']:.4f} ({corr['tool_answer']['interpretation']})")

        # Generate scatter plots
        plot_scatter_facets(samples, model_name, output_dir)

    # Save correlation results to JSON
    output_json = output_dir / "correlation_results.json"
    with open(output_json, 'w') as f:
        json.dump(all_correlations, f, indent=2)
    print(f"\n[SAVED] Correlation results: {output_json}")

    # Generate heatmap
    print("\nGenerating correlation heatmap...")
    plot_correlation_heatmap(all_correlations, output_dir / "correlation_heatmap.png")

    print("\n" + "=" * 70)
    print("Analysis Complete!")
    print("=" * 70)
    print(f"Output directory: {output_dir}")
    print()


if __name__ == "__main__":
    main()
