#!/usr/bin/env python3
"""
LLM-as-a-Judge Evaluation for GAIA Benchmark

Evaluates model final answers by comparing against ground truth,
considering execution traces and tool outputs for context.

Usage:
    python -m src.analysis.llm_judge --results_dir ./organized_results/gaia/cat_B/xxx
"""

import json
import argparse
from pathlib import Path
from typing import Dict, List, Tuple
import sys
import re

# Model name mapping to unify variants
MODEL_NAME_MAPPING = {
    "Llama-3.3-70B-Instruct-Gaudi3": "Llama-3.3-70B-Instruct",
    "Llama-3.3-70B-Instruct-MI210": "Llama-3.3-70B-Instruct",
}


def normalize_answer(answer: str) -> str:
    """Normalize answer for comparison."""
    if not answer:
        return ""

    # Convert to lowercase
    answer = answer.lower().strip()

    # Remove extra whitespace
    answer = re.sub(r'\s+', ' ', answer)

    # Remove common punctuation at the end
    answer = answer.rstrip('.,;:!?')

    return answer


def extract_answer_text(answer_obj) -> str:
    """Extract answer text from answer object."""
    if isinstance(answer_obj, dict):
        return str(answer_obj.get('answer', ''))
    elif isinstance(answer_obj, str):
        return answer_obj
    else:
        return str(answer_obj)


def check_fuzzy_match(pred: str, gold: str, aliases: List[str] = None) -> bool:
    """
    Check if predicted answer matches gold or aliases using fuzzy matching.
    """
    pred_norm = normalize_answer(pred)
    gold_norm = normalize_answer(gold)

    # Exact match after normalization
    if pred_norm == gold_norm:
        return True

    # Check if gold is contained in pred (or vice versa for short answers)
    if gold_norm and (gold_norm in pred_norm or pred_norm in gold_norm):
        # Allow containment if the lengths are similar (within 50%)
        len_ratio = min(len(pred_norm), len(gold_norm)) / max(len(pred_norm), len(gold_norm))
        if len_ratio > 0.5:
            return True

    # Check aliases
    if aliases:
        for alias in aliases:
            alias_norm = normalize_answer(alias)
            if pred_norm == alias_norm:
                return True
            if alias_norm and (alias_norm in pred_norm or pred_norm in alias_norm):
                len_ratio = min(len(pred_norm), len(alias_norm)) / max(len(pred_norm), len(alias_norm))
                if len_ratio > 0.5:
                    return True

    return False


def evaluate_numeric_answer(pred: str, gold: str, tolerance: float = 0.0) -> bool:
    """
    Evaluate numeric answers with tolerance.
    """
    try:
        # Extract numbers from strings
        pred_nums = re.findall(r'-?\d+\.?\d*', pred)
        gold_nums = re.findall(r'-?\d+\.?\d*', gold)

        if not pred_nums or not gold_nums:
            return False

        # Compare first number found
        pred_val = float(pred_nums[0])
        gold_val = float(gold_nums[0])

        if tolerance > 0:
            return abs(pred_val - gold_val) <= tolerance
        else:
            return pred_val == gold_val
    except:
        return False


def check_number_list_match(pred: str, gold: str) -> bool:
    """
    Check if two number lists match, ignoring spacing.
    E.g., "132, 133, 134" should match "132,133,134"

    Only applies to pure number lists (no alphabetic characters except spaces/commas).
    """
    # Check if both are primarily numeric (more than 50% digits/spaces/commas/punctuation)
    def is_numeric_list(text: str) -> bool:
        # Remove spaces, commas, and common punctuation
        cleaned = re.sub(r'[\s,;.\-]', '', text)
        if not cleaned:
            return False
        digit_ratio = sum(c.isdigit() for c in cleaned) / len(cleaned)
        return digit_ratio > 0.9  # At least 90% digits

    if not (is_numeric_list(pred) and is_numeric_list(gold)):
        return False

    # Extract all numbers from both strings
    pred_nums = re.findall(r'\d+', pred)
    gold_nums = re.findall(r'\d+', gold)

    # Compare number sequences
    return pred_nums == gold_nums and len(pred_nums) > 0


def check_shopping_list_match(pred: str, gold: str) -> Tuple[bool, float]:
    """
    Check if two shopping lists match, ignoring adjectives and order.

    Returns:
        (is_match, coverage_ratio)
    """
    # Only apply to comma-separated lists
    if ',' not in pred or ',' not in gold:
        return False, 0.0

    # Common adjectives to remove
    adjectives = [
        'freshly', 'squeezed', 'pure', 'ripe', 'fresh', 'organic', 'raw',
        'granulated', 'powdered', 'whole', 'chopped', 'diced', 'sliced',
        'unsalted', 'salted', 'ground', 'dried', 'canned', 'frozen'
    ]

    def extract_core_items(text: str) -> set:
        """Extract core items from shopping list, removing adjectives."""
        # Split by comma
        items = [item.strip().lower() for item in text.split(',')]
        core_items = set()

        for item in items:
            # Remove common adjectives
            words = item.split()
            core_words = [w for w in words if w not in adjectives]

            # Also handle compound items like "lemon juice" vs "lemon"
            core_item = ' '.join(core_words)

            # Normalize some common variations
            # But keep "extract" and "juice" as they're important
            if 'vanilla extract' in core_item or 'vanilla' in core_item:
                core_item = 'vanilla'
            if 'lemon juice' in core_item or 'lemon' in core_item:
                core_item = 'lemon'
            if 'strawberries' in core_item or 'strawberry' in core_item:
                core_item = 'strawberries'
            if 'sugar' in core_item:
                core_item = 'sugar'

            if core_item:
                core_items.add(core_item)

        return core_items

    pred_items = extract_core_items(pred)
    gold_items = extract_core_items(gold)

    if not gold_items:
        return False, 0.0

    # Calculate coverage (how many gold items are in pred)
    matched = len(pred_items & gold_items)
    coverage = matched / len(gold_items)

    # Also check if pred has extra items (not in gold)
    extra_items = pred_items - gold_items

    # Be strict: reject if there are extra items that don't belong
    # (e.g., "salt" when not in the original list)
    if len(extra_items) > 0:
        return False, coverage

    # Match if:
    # Coverage = 100% (all gold items are present, no extras)
    is_match = coverage == 1.0

    return is_match, coverage


def check_abbreviation_match(pred: str, gold: str) -> bool:
    """
    Check if predicted and gold answers match when accounting for abbreviations.
    E.g., "St. Petersburg" should match "Saint Petersburg"
    """
    # Common abbreviations mapping
    ABBREVIATION_MAPPING = {
        'st.': 'saint',
        'st': 'saint',
        'dr.': 'doctor',
        'dr': 'doctor',
        'mr.': 'mister',
        'mr': 'mister',
        'mrs.': 'misses',
        'mrs': 'misses',
        'ms.': 'miss',
        'ms': 'miss',
        'prof.': 'professor',
        'prof': 'professor',
        'ave.': 'avenue',
        'ave': 'avenue',
        'blvd.': 'boulevard',
        'blvd': 'boulevard',
        'rd.': 'road',
        'rd': 'road',
        'apt.': 'apartment',
        'apt': 'apartment',
        'no.': 'number',
        'no': 'number',
    }

    def normalize_abbreviations(text: str) -> str:
        """Expand common abbreviations to their full form."""
        text_lower = text.lower().strip()

        # Split into words and expand abbreviations
        words = text_lower.split()
        normalized_words = []

        for word in words:
            # Remove trailing punctuation for matching
            word_clean = word.rstrip('.,;:!?')
            expanded = ABBREVIATION_MAPPING.get(word_clean, word)
            normalized_words.append(expanded)

        return ' '.join(normalized_words)

    pred_norm = normalize_abbreviations(pred)
    gold_norm = normalize_abbreviations(gold)

    return pred_norm == gold_norm


def judge_answer(
    query: str,
    gold_answer_obj: Dict,
    pred_answer_obj: Dict,
    tool_outputs: List[str],
    sample_id: str
) -> Tuple[int, str]:
    """
    Judge the predicted answer against gold answer.

    Returns:
        (score, reasoning)
        score: 1 if correct, 0 if incorrect
        reasoning: explanation of the judgment
    """
    # Extract answer texts
    gold_text = extract_answer_text(gold_answer_obj.get('answer', ''))
    pred_text = extract_answer_text(pred_answer_obj.get('answer', ''))

    answer_type = gold_answer_obj.get('answer_type', 'string')
    aliases = gold_answer_obj.get('aliases', [])
    tolerance = gold_answer_obj.get('tolerance', 0.0)

    # Check for empty or error answers
    if not pred_text or pred_text.lower() in ['', 'none', 'n/a', 'unknown', 'error']:
        return 0, f"Empty or error answer: '{pred_text}'"

    # Check for explicit failure indicators
    failure_indicators = [
        'not found', 'no information', 'cannot find', 'unable to',
        'no data', 'not available', 'could not', 'failed to',
        'no entry', 'no entries', 'no results'
    ]
    pred_lower = pred_text.lower()
    if any(indicator in pred_lower for indicator in failure_indicators):
        # Check if this is actually correct (gold might also be "not found")
        if gold_text.lower() in pred_lower or pred_lower in gold_text.lower():
            return 1, f"Correct negative answer: '{pred_text}' matches gold '{gold_text}'"
        else:
            return 0, f"Failed to find answer: '{pred_text}' but gold is '{gold_text}'"

    # Exact match check (normalized)
    if normalize_answer(pred_text) == normalize_answer(gold_text):
        return 1, f"Exact match: '{pred_text}'"

    # Fuzzy match check
    if check_fuzzy_match(pred_text, gold_text, aliases):
        return 1, f"Fuzzy match: '{pred_text}' matches gold/alias"

    # Number list match (e.g., "132, 133, 134" vs "132,133,134")
    if check_number_list_match(pred_text, gold_text):
        return 1, f"Number list match (spacing normalized): '{pred_text}' = '{gold_text}'"

    # Abbreviation match (e.g., "St. Petersburg" vs "Saint Petersburg")
    if check_abbreviation_match(pred_text, gold_text):
        return 1, f"Abbreviation match: '{pred_text}' ≈ '{gold_text}'"

    # Shopping list match (ignoring adjectives and order)
    is_shopping_match, coverage = check_shopping_list_match(pred_text, gold_text)
    if is_shopping_match:
        return 1, f"Shopping list match (core items {coverage:.1%}): '{pred_text}' ≈ '{gold_text}'"

    # Numeric answer check
    if answer_type in ['integer', 'float', 'number']:
        if evaluate_numeric_answer(pred_text, gold_text, tolerance):
            return 1, f"Numeric match within tolerance: '{pred_text}' ≈ '{gold_text}'"

    # Check tool execution context
    has_tool_errors = any('ERROR' in str(output) or 'Error' in str(output)
                          for output in tool_outputs) if tool_outputs else False

    if has_tool_errors:
        reasoning = f"Tool execution errors led to incorrect answer: '{pred_text}' vs gold '{gold_text}'"
    else:
        reasoning = f"Incorrect answer: '{pred_text}' vs gold '{gold_text}'"

    # Final semantic check for very close answers
    # Check if key terms from gold appear in prediction
    gold_words = set(normalize_answer(gold_text).split())
    pred_words = set(normalize_answer(pred_text).split())

    if gold_words and pred_words:
        overlap = len(gold_words & pred_words) / len(gold_words)
        if overlap >= 0.8:  # 80% word overlap
            return 1, f"High semantic overlap ({overlap:.1%}): '{pred_text}' ≈ '{gold_text}'"

    return 0, reasoning


def evaluate_model(unified_jsonl_path: Path, model_name: str) -> Dict:
    """
    Evaluate all samples for a single model.

    Returns:
        {
            'model': model_name,
            'samples': [
                {
                    'id': ...,
                    'subset': ...,
                    'query': ...,
                    'gold_answer': ...,
                    'pred_answer': ...,
                    'llm_judge_score': 0 or 1,
                    'llm_judge_reasoning': ...,
                    'exact_match': 0 or 1
                },
                ...
            ],
            'summary': {
                'total': int,
                'llm_judge_correct': int,
                'llm_judge_accuracy': float,
                'exact_match_correct': int,
                'exact_match_accuracy': float
            }
        }
    """
    results = {
        'model': model_name,
        'samples': [],
        'summary': {}
    }

    with open(unified_jsonl_path, 'r') as f:
        for line_num, line in enumerate(f, 1):
            try:
                data = json.loads(line)

                sample_id = data['meta']['id']
                subset = data['meta']['subset']
                query = data['query']['user_query']

                gold_answer = data['gold']['final_answer']
                pred_answer = data['pred']['final_answer']
                tool_outputs = data['pred'].get('tool_outputs', [])

                # Get exact match from existing metrics (if available)
                # We'll compute it ourselves too
                gold_text = extract_answer_text(gold_answer.get('answer', ''))
                pred_text = extract_answer_text(pred_answer.get('answer', ''))
                exact_match = 1 if normalize_answer(gold_text) == normalize_answer(pred_text) else 0

                # LLM-as-a-Judge evaluation
                llm_judge_score, llm_judge_reasoning = judge_answer(
                    query, gold_answer, pred_answer, tool_outputs, sample_id
                )

                results['samples'].append({
                    'id': sample_id,
                    'subset': subset,
                    'query': query[:100] + '...' if len(query) > 100 else query,
                    'gold_answer': gold_text,
                    'pred_answer': pred_text,
                    'llm_judge_score': llm_judge_score,
                    'llm_judge_reasoning': llm_judge_reasoning,
                    'exact_match': exact_match
                })

            except Exception as e:
                print(f"  [WARN] Error processing line {line_num} for {model_name}: {e}")
                continue

    # Compute summary
    total = len(results['samples'])
    llm_judge_correct = sum(s['llm_judge_score'] for s in results['samples'])
    exact_match_correct = sum(s['exact_match'] for s in results['samples'])

    results['summary'] = {
        'total': total,
        'llm_judge_correct': llm_judge_correct,
        'llm_judge_accuracy': llm_judge_correct / total if total > 0 else 0.0,
        'exact_match_correct': exact_match_correct,
        'exact_match_accuracy': exact_match_correct / total if total > 0 else 0.0,
        'improvement': (llm_judge_correct - exact_match_correct) / total if total > 0 else 0.0
    }

    return results


def main():
    parser = argparse.ArgumentParser(
        description="LLM-as-a-Judge Evaluation for GAIA Benchmark"
    )
    parser.add_argument(
        "--results_dir",
        type=str,
        required=True,
        help="Directory containing model subdirectories with unified.*.jsonl files"
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        default=None,
        help="Output directory for evaluation results (default: {results_dir}/llm_judge)"
    )
    args = parser.parse_args()

    results_dir = Path(args.results_dir)

    if not results_dir.exists():
        print(f"[ERROR] Results directory not found: {results_dir}")
        sys.exit(1)

    # Determine output directory
    if args.output_dir:
        output_dir = Path(args.output_dir)
    else:
        output_dir = results_dir / "llm_judge"

    output_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 80)
    print("LLM-as-a-Judge Evaluation (Claude Sonnet 4.5)")
    print("=" * 80)
    print(f"Results directory: {results_dir}")
    print(f"Output directory: {output_dir}")
    print()

    # Find all model directories with unified JSONL files
    model_results = []

    for model_dir in sorted(results_dir.iterdir()):
        if not model_dir.is_dir():
            continue

        # Look for unified.*.jsonl file
        unified_files = list(model_dir.glob("unified.*.jsonl"))
        if not unified_files:
            continue

        unified_file = unified_files[0]
        model_name = model_dir.name
        # Apply name mapping to unify variants
        model_name = MODEL_NAME_MAPPING.get(model_name, model_name)

        print(f"Evaluating model: {model_name}")
        print(f"  File: {unified_file.name}")

        result = evaluate_model(unified_file, model_name)
        model_results.append(result)

        summary = result['summary']
        print(f"  Samples: {summary['total']}")
        print(f"  Exact Match: {summary['exact_match_correct']}/{summary['total']} ({summary['exact_match_accuracy']:.1%})")
        print(f"  LLM Judge:   {summary['llm_judge_correct']}/{summary['total']} ({summary['llm_judge_accuracy']:.1%})")
        print(f"  Improvement: {summary['improvement']:+.1%}")
        print()

    if not model_results:
        print("[ERROR] No model results found")
        sys.exit(1)

    # Save detailed results
    output_json = output_dir / "llm_judge_results.json"
    with open(output_json, 'w') as f:
        json.dump(model_results, f, indent=2)
    print(f"[SAVED] Detailed results: {output_json}")

    # Save summary CSV
    import pandas as pd

    summary_data = []
    for result in model_results:
        summary_data.append({
            'Model': result['model'],
            'Total': result['summary']['total'],
            'EM_Correct': result['summary']['exact_match_correct'],
            'EM_Accuracy': result['summary']['exact_match_accuracy'],
            'Judge_Correct': result['summary']['llm_judge_correct'],
            'Judge_Accuracy': result['summary']['llm_judge_accuracy'],
            'Improvement': result['summary']['improvement']
        })

    df_summary = pd.DataFrame(summary_data)
    output_csv = output_dir / "llm_judge_summary.csv"
    df_summary.to_csv(output_csv, index=False)
    print(f"[SAVED] Summary CSV: {output_csv}")

    # Save per-sample details
    for result in model_results:
        model_name = result['model']
        df_samples = pd.DataFrame(result['samples'])
        sample_csv = output_dir / f"samples_{model_name}.csv"
        df_samples.to_csv(sample_csv, index=False)
        print(f"[SAVED] Sample details: {sample_csv}")

    print()
    print("=" * 80)
    print("Evaluation Complete!")
    print("=" * 80)
    print(f"Output directory: {output_dir}")
    print()


if __name__ == "__main__":
    main()
