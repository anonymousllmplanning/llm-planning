#!/usr/bin/env python3
"""
Update existing figures with LLM-as-a-Judge scores and generate new visualizations.

Usage:
    python -m src.analysis.update_figures_with_judge --results_dir ./organized_results/gaia/cat_B/xxx
"""

import json
import argparse
from pathlib import Path
from typing import Dict
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Model name mapping to unify variants
MODEL_NAME_MAPPING = {
    "Llama-3.3-70B-Instruct-Gaudi3": "Llama-3.3-70B-Instruct",
    "Llama-3.3-70B-Instruct-MI210": "Llama-3.3-70B-Instruct",
}


def load_llm_judge_results(llm_judge_dir: Path) -> pd.DataFrame:
    """Load LLM judge summary results."""
    summary_csv = llm_judge_dir / "llm_judge_summary.csv"
    if not summary_csv.exists():
        raise FileNotFoundError(f"LLM judge summary not found: {summary_csv}")

    df = pd.read_csv(summary_csv)
    return df


def load_existing_summary_data(results_dir: Path) -> Dict[str, pd.DataFrame]:
    """Load existing summary.*.json files and convert to DataFrames."""
    summary_data = {}

    for summary_file in results_dir.glob("summary.*.json"):
        model_name = summary_file.stem.replace("summary.", "")
        # Apply name mapping to unify variants
        model_name = MODEL_NAME_MAPPING.get(model_name, model_name)

        with open(summary_file, 'r') as f:
            data = json.load(f)

        # Extract overall metrics
        if '_overall' in data:
            overall = data['_overall']
            answer_metrics = overall.get('answer', {})

            summary_data[model_name] = {
                'exact_match': answer_metrics.get('exact_match', 0.0),
                'token_f1': answer_metrics.get('token_f1', 0.0),
                'num_samples': overall.get('num_samples', 0)
            }

    return summary_data


def plot_comparison_with_judge(
    df_judge: pd.DataFrame,
    output_path: Path,
    title: str = "Model Answer Accuracy: Summary EM vs LLM-as-a-Judge"
):
    """
    Generate bar chart comparing Summary Exact Match and LLM Judge scores.
    Note: Uses Summary EM (from summary.*.json with smart_match) not Judge strict EM.
    """
    fig, ax = plt.subplots(figsize=(12, 7))

    models = df_judge['Model'].tolist()
    em_scores = df_judge['Summary_EM'].tolist()  # Changed from EM_Accuracy to Summary_EM
    judge_scores = df_judge['Judge_Accuracy'].tolist()

    x = np.arange(len(models))
    width = 0.35

    # Plot bars
    bars1 = ax.bar(x - width/2, em_scores, width, label='Summary EM (smart match)', color='#3498db', alpha=0.8)
    bars2 = ax.bar(x + width/2, judge_scores, width, label='LLM-as-a-Judge', color='#e74c3c', alpha=0.8)

    # Add value labels on bars
    for bars in [bars1, bars2]:
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{height:.1%}',
                   ha='center', va='bottom', fontsize=9, fontweight='bold')

    ax.set_xlabel('Model', fontsize=12, fontweight='bold')
    ax.set_ylabel('Accuracy', fontsize=12, fontweight='bold')
    ax.set_title(title, fontsize=14, fontweight='bold', pad=20)
    ax.set_xticks(x)
    ax.set_xticklabels(models, rotation=45, ha='right')
    ax.legend(loc='upper left', fontsize=11)
    ax.set_ylim(0, 1.0)
    ax.grid(axis='y', alpha=0.3, linestyle='--')

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.savefig(output_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close()

    print(f"[SAVED] {output_path}")


def plot_improvement_analysis(df_judge: pd.DataFrame, output_path: Path):
    """
    Generate bar chart showing improvement from Summary EM to LLM Judge.
    Note: Improvement = Judge Accuracy - Summary EM (smart match).
    """
    fig, ax = plt.subplots(figsize=(12, 7))

    models = df_judge['Model'].tolist()
    improvements = (df_judge['Improvement'] * 100).tolist()  # Convert to percentage points

    # Sort by improvement
    sorted_indices = sorted(range(len(improvements)), key=lambda i: improvements[i], reverse=True)
    models = [models[i] for i in sorted_indices]
    improvements = [improvements[i] for i in sorted_indices]

    colors = ['#27ae60' if imp > 0 else '#95a5a6' for imp in improvements]

    bars = ax.barh(range(len(models)), improvements, color=colors, alpha=0.8)

    # Add value labels
    for i, (bar, imp) in enumerate(zip(bars, improvements)):
        width = bar.get_width()
        label_x = width + 0.5 if width >= 0 else width - 0.5
        ax.text(label_x, bar.get_y() + bar.get_height()/2.,
               f'{imp:+.1f}%',
               ha='left' if width >= 0 else 'right',
               va='center', fontsize=10, fontweight='bold')

    ax.set_yticks(range(len(models)))
    ax.set_yticklabels(models, fontsize=11)
    ax.set_xlabel('Improvement (Percentage Points)', fontsize=12, fontweight='bold')
    ax.set_title('Accuracy Improvement: LLM-as-a-Judge vs Summary EM', fontsize=14, fontweight='bold', pad=20)
    ax.axvline(x=0, color='black', linewidth=1, linestyle='-', alpha=0.3)
    ax.grid(axis='x', alpha=0.3, linestyle='--')

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.savefig(output_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close()

    print(f"[SAVED] {output_path}")


def plot_by_level_with_judge(df_judge: pd.DataFrame, results_dir: Path, output_path: Path):
    """
    Generate bar chart showing performance by difficulty level (if available).
    """
    # Load per-sample data to get level information
    level_data = {}

    for model_dir in results_dir.iterdir():
        if not model_dir.is_dir():
            continue

        model_name = model_dir.name
        # Apply name mapping to unify variants
        model_name = MODEL_NAME_MAPPING.get(model_name, model_name)
        unified_file = list(model_dir.glob("unified.*.jsonl"))

        if not unified_file:
            continue

        unified_file = unified_file[0]

        level_scores = {'level_1': [], 'level_2': [], 'level_3': []}

        # Load LLM judge sample results
        judge_sample_file = results_dir / "llm_judge" / f"samples_{model_name}.csv"
        if not judge_sample_file.exists():
            continue

        df_samples = pd.read_csv(judge_sample_file)

        # Read unified file to get level info
        with open(unified_file, 'r') as f:
            for i, line in enumerate(f):
                data = json.loads(line)
                subset = data['meta']['subset']

                # Extract level from subset (e.g., "level_2_B" -> "level_2")
                level = '_'.join(subset.split('_')[:2]) if '_' in subset else subset

                if i < len(df_samples):
                    judge_score = df_samples.iloc[i]['llm_judge_score']
                    if level in level_scores:
                        level_scores[level].append(judge_score)

        # Calculate average per level
        level_data[model_name] = {
            level: np.mean(scores) if scores else 0.0
            for level, scores in level_scores.items()
        }

    if not level_data:
        print("[WARN] No level data available for level-wise plot")
        return

    # Create DataFrame
    plot_data = []
    for model, levels in level_data.items():
        for level, score in levels.items():
            # Include all levels, even if score is 0
            plot_data.append({
                'Model': model,
                'Level': level.replace('_', ' ').title(),
                'Accuracy': score
            })

    if not plot_data:
        print("[WARN] No plot data available")
        return

    df_plot = pd.DataFrame(plot_data)

    # Plot grouped bar chart
    fig, ax = plt.subplots(figsize=(12, 7))

    levels = sorted(df_plot['Level'].unique())
    models = sorted(df_plot['Model'].unique())
    x = np.arange(len(levels))
    width = 0.8 / len(models)

    for i, model in enumerate(models):
        model_data = df_plot[df_plot['Model'] == model]
        scores = [model_data[model_data['Level'] == level]['Accuracy'].values[0]
                 if len(model_data[model_data['Level'] == level]) > 0 else 0
                 for level in levels]

        bars = ax.bar(x + i * width, scores, width, label=model, alpha=0.8)

        # Add value labels
        for bar in bars:
            height = bar.get_height()
            if height > 0:
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{height:.1%}',
                       ha='center', va='bottom', fontsize=8, rotation=0)

    ax.set_xlabel('Difficulty Level', fontsize=12, fontweight='bold')
    ax.set_ylabel('LLM-as-a-Judge Accuracy', fontsize=12, fontweight='bold')
    ax.set_title('Model Performance by Difficulty Level (LLM-as-a-Judge)', fontsize=14, fontweight='bold', pad=20)
    ax.set_xticks(x + width * (len(models) - 1) / 2)
    ax.set_xticklabels(levels)
    ax.legend(loc='best', fontsize=9, ncol=2)
    ax.set_ylim(0, 1.0)
    ax.grid(axis='y', alpha=0.3, linestyle='--')

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.savefig(output_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close()

    print(f"[SAVED] {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Update figures with LLM-as-a-Judge scores"
    )
    parser.add_argument(
        "--results_dir",
        type=str,
        required=True,
        help="Directory containing model results and llm_judge subdirectory"
    )
    args = parser.parse_args()

    results_dir = Path(args.results_dir)

    if not results_dir.exists():
        print(f"[ERROR] Results directory not found: {results_dir}")
        sys.exit(1)

    llm_judge_dir = results_dir / "llm_judge"
    if not llm_judge_dir.exists():
        print(f"[ERROR] LLM judge results not found: {llm_judge_dir}")
        print("Please run: python -m src.analysis.llm_judge --results_dir {results_dir}")
        sys.exit(1)

    figures_dir = results_dir / "figures"
    figures_dir.mkdir(exist_ok=True)

    print("=" * 80)
    print("Updating Figures with LLM-as-a-Judge Scores")
    print("=" * 80)
    print(f"Results directory: {results_dir}")
    print(f"Figures directory: {figures_dir}")
    print()

    # Load LLM judge results
    print("Loading LLM judge results...")
    df_judge = load_llm_judge_results(llm_judge_dir)
    print(f"Loaded judge results for {len(df_judge)} models")

    # Load summary data (contains smart-match EM)
    print("Loading summary data...")
    summary_data = load_existing_summary_data(results_dir)
    print(f"Loaded summary data for {len(summary_data)} models")

    # Merge summary EM into judge DataFrame
    summary_em_list = []
    for _, row in df_judge.iterrows():
        model_name = row['Model']
        if model_name in summary_data:
            summary_em_list.append(summary_data[model_name]['exact_match'])
        else:
            # Fallback to judge EM if summary not found
            print(f"[WARN] No summary data for {model_name}, using judge EM as fallback")
            summary_em_list.append(row['EM_Accuracy'])

    df_judge['Summary_EM'] = summary_em_list

    # Recalculate improvement using Summary EM
    df_judge['Improvement'] = df_judge['Judge_Accuracy'] - df_judge['Summary_EM']

    print()
    print("Data merged successfully:")
    print(df_judge[['Model', 'Summary_EM', 'Judge_Accuracy', 'Improvement']].to_string())
    print()

    # Generate new figures
    print("Generating visualizations...")

    # 1. Comparison chart (Summary EM vs Judge)
    plot_comparison_with_judge(
        df_judge,
        figures_dir / "fig_final_answer_comparison_with_judge.png",
        "Model Answer Accuracy: Summary EM vs LLM-as-a-Judge"
    )

    # 2. Improvement analysis
    plot_improvement_analysis(
        df_judge,
        figures_dir / "fig_judge_improvement.png"
    )

    # 3. By level analysis (with judge scores)
    plot_by_level_with_judge(
        df_judge,
        results_dir,
        figures_dir / "fig_final_answer_by_level_judge.png"
    )

    # Copy summary to figures dir for easy access
    import shutil
    shutil.copy(
        llm_judge_dir / "llm_judge_summary.csv",
        figures_dir / "llm_judge_summary.csv"
    )
    print(f"[SAVED] {figures_dir / 'llm_judge_summary.csv'}")

    print()
    print("=" * 80)
    print("Figure Update Complete!")
    print("=" * 80)
    print(f"Figures directory: {figures_dir}")
    print()
    print("Generated files:")
    print("  - fig_final_answer_comparison_with_judge.png (EM vs Judge comparison)")
    print("  - fig_judge_improvement.png (improvement analysis)")
    print("  - fig_final_answer_by_level_judge.png (by difficulty level)")
    print("  - llm_judge_summary.csv (summary table)")
    print()


if __name__ == "__main__":
    main()
