#!/usr/bin/env python3
"""
Stage-wise GAIA diagnostics for planning -> tool -> answer analysis.

This script reads unified answer-mode run artifacts and derives:
- PlanningScore = (SpanNodeF1 + DW-OrderF1) / 2
- ToolUsageScore = avg(ToolNameF1, ParamNameF1, TypeAwareValueF1)
- GT-aligned Tool Success Rate
- Observation Support Rate (OSR)
- Final answer metrics (EM / Token F1)

It writes per-sample, per-run, and weighted per-model summaries plus a compact
bar chart for paper figures.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import pearsonr, spearmanr

matplotlib.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": [
            "TeX Gyre Termes",
            "Times New Roman",
            "Times",
            "Nimbus Roman",
            "DejaVu Serif",
        ],
        "mathtext.fontset": "stix",
        "axes.titlesize": 13,
        "axes.labelsize": 11,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "legend.fontsize": 10,
    }
)

from src.evaluation.metrics import ASTEvaluationSystem, _extract_tool_name


CAT_WEIGHTS = {"A": 127, "B": 25, "C": 10, "D": 3}
MODEL_NAME_MAPPING = {
    "Llama-3.3-70B-Instruct-Gaudi3": "Llama-3.3-70B-Instruct",
    "Llama-3.3-70B-Instruct-MI210": "Llama-3.3-70B-Instruct",
}


def _mean(values: Iterable[Optional[float]]) -> Optional[float]:
    vals = [v for v in values if v is not None and not (isinstance(v, float) and math.isnan(v))]
    return sum(vals) / len(vals) if vals else None


def _normalize_model_name(name: str) -> str:
    return MODEL_NAME_MAPPING.get(name, name)


def _corr(xs: List[Optional[float]], ys: List[Optional[float]]) -> Dict[str, Optional[float]]:
    pairs = [
        (x, y)
        for x, y in zip(xs, ys)
        if x is not None and y is not None
        and not (isinstance(x, float) and math.isnan(x))
        and not (isinstance(y, float) and math.isnan(y))
    ]
    if len(pairs) < 3:
        return {"n": len(pairs), "pearson": None, "spearman": None}
    x = np.array([a for a, _ in pairs], dtype=float)
    y = np.array([b for _, b in pairs], dtype=float)
    return {
        "n": len(pairs),
        "pearson": float(pearsonr(x, y).statistic),
        "spearman": float(spearmanr(x, y).statistic),
    }


def _is_success_output(output: str) -> bool:
    text = str(output or "")
    if "Output:\n" in text:
        text = text.split("Output:\n", 1)[1]
    norm = text.strip().lower()
    return not (
        norm.startswith("[error]")
        or norm.startswith("error:")
        or norm.startswith("execution failed:")
    )


def _extract_output_text(output: str) -> str:
    text = str(output or "")
    if "Output:\n" in text:
        return text.split("Output:\n", 1)[1]
    return text


@dataclass
class SampleRow:
    sample_id: str
    category: str
    model: str
    planning_score: float
    span_node_f1: float
    semantic_node_f1: float
    dw_order_f1: float
    edge_f1: float
    semantic_edge_f1: float
    tool_usage_score: Optional[float]
    gt_aligned_tool_success_rate: Optional[float]
    pred_exec_success_rate: Optional[float]
    observation_support_rate: float
    exact_match: Optional[float]
    token_f1: Optional[float]
    gold_tool_count: int
    pred_tool_count: int
    successful_pred_tool_count: int
    has_answer: bool


@dataclass
class RunRow:
    category: str
    model: str
    n: int
    planning_score: Optional[float]
    span_node_f1: Optional[float]
    semantic_node_f1: Optional[float]
    dw_order_f1: Optional[float]
    edge_f1: Optional[float]
    semantic_edge_f1: Optional[float]
    tool_usage_score: Optional[float]
    gt_aligned_tool_success_rate: Optional[float]
    pred_exec_success_rate: Optional[float]
    observation_support_rate: Optional[float]
    exact_match: Optional[float]
    token_f1: Optional[float]


def _tool_usage_score(tool_scores: Dict[str, Any]) -> Optional[float]:
    return _mean([
        tool_scores.get("tool_name_f1"),
        tool_scores.get("param_name_f1"),
        tool_scores.get("type_aware_value_f1"),
    ])


def _find_unified_file(run_dir: Path) -> Path:
    matches = list(run_dir.glob("*/unified.*.jsonl"))
    if not matches:
        raise FileNotFoundError(f"No unified jsonl found under {run_dir}")
    return matches[0]


def _weighted_model_rows(run_rows: List[RunRow]) -> List[Dict[str, Any]]:
    by_model: Dict[str, Dict[str, RunRow]] = defaultdict(dict)
    for row in run_rows:
        by_model[row.model][row.category] = row

    weighted_rows: List[Dict[str, Any]] = []
    unsorted_rows: List[Dict[str, Any]] = []
    for model, cat_rows in by_model.items():
        def weighted_metric(key: str) -> Optional[float]:
            values = [
                (CAT_WEIGHTS[cat], getattr(cat_rows[cat], key))
                for cat in cat_rows
                if getattr(cat_rows[cat], key) is not None
            ]
            if not values:
                return None
            num = sum(weight * value for weight, value in values)
            den = sum(weight for weight, _ in values)
            return num / den if den else None

        unsorted_rows.append({
            "model": model,
            "weighted_planning_score": weighted_metric("planning_score"),
            "weighted_span_node_f1": weighted_metric("span_node_f1"),
            "weighted_semantic_node_f1": weighted_metric("semantic_node_f1"),
            "weighted_dw_order_f1": weighted_metric("dw_order_f1"),
            "weighted_edge_f1": weighted_metric("edge_f1"),
            "weighted_semantic_edge_f1": weighted_metric("semantic_edge_f1"),
            "weighted_tool_usage_score": weighted_metric("tool_usage_score"),
            "weighted_gt_aligned_tool_success_rate": weighted_metric("gt_aligned_tool_success_rate"),
            "weighted_pred_exec_success_rate": weighted_metric("pred_exec_success_rate"),
            "weighted_osr": weighted_metric("observation_support_rate"),
            "weighted_em": weighted_metric("exact_match"),
            "weighted_token_f1": weighted_metric("token_f1"),
            "solved_165": round((weighted_metric("exact_match") or 0.0) * 165),
        })
    return sorted(
        unsorted_rows,
        key=lambda row: (-(row.get("weighted_planning_score") or 0.0), row["model"]),
    )


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def _plot_weighted_stages(weighted_rows: List[Dict[str, Any]], output_dir: Path) -> None:
    models = [row["model"] for row in weighted_rows]
    short_names = [
        "Llama-4" if "Llama-4" in m else
        "gpt-oss-120b" if "120b" in m else
        "gpt-oss-20b" if "20b" in m else
        "Mistral" if "Mistral" in m else m
        for m in models
    ]
    stage_keys = [
        ("weighted_planning_score", "Planning"),
        ("weighted_tool_usage_score", "Tool Grounding"),
        ("weighted_gt_aligned_tool_success_rate", "Tool Success"),
        ("weighted_osr", "OSR"),
        ("weighted_em", "Answer EM"),
    ]
    colors = ["#4C72B0", "#55A868", "#C44E52", "#8172B2", "#DD8452"]

    x = np.arange(len(models))
    width = 0.15
    fig, ax = plt.subplots(figsize=(10.5, 4.6))

    for idx, ((key, label), color) in enumerate(zip(stage_keys, colors)):
        values = [row.get(key) or 0.0 for row in weighted_rows]
        offset = (idx - (len(stage_keys) - 1) / 2) * width
        bars = ax.bar(x + offset, values, width, label=label, color=color, alpha=0.9)
        for bar, value in zip(bars, values):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.01,
                f"{value:.2f}",
                ha="center",
                va="bottom",
                fontsize=8,
                rotation=90,
            )

    ax.set_xticks(x)
    ax.set_xticklabels(short_names)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Weighted Score")
    ax.set_title("GAIA A--D Stage-wise Weighted Summary")
    ax.legend(loc="upper right", ncol=3, frameon=True)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(output_dir / "gaia_stage_weighted_summary.png", dpi=220, bbox_inches="tight")
    fig.savefig(output_dir / "gaia_stage_weighted_summary.pdf", bbox_inches="tight")
    fig.savefig(output_dir / "gaia_stage_weighted_summary.svg", bbox_inches="tight")
    plt.close(fig)


def analyze_runs(run_dirs: List[Path], output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    evaluator = ASTEvaluationSystem(use_embeddings=False, verifier_model=None)

    sample_rows: List[SampleRow] = []
    run_rows: List[RunRow] = []

    for run_dir in run_dirs:
        unified_path = _find_unified_file(run_dir)
        category_match = next((part for part in run_dir.parts if part.startswith("cat_")), None)
        if not category_match:
            raise ValueError(f"Could not infer category from {run_dir}")
        category = category_match.split("_", 1)[1].upper()

        run_sample_rows: List[SampleRow] = []
        with unified_path.open() as f:
            for line in f:
                rec = json.loads(line)
                meta = rec.get("meta", {}) or {}
                query = rec.get("query", {}) or {}
                gold = rec.get("gold", {}) or {}
                pred = rec.get("pred", {}) or {}
                sample_id = str(meta.get("id", ""))
                model_name = str(meta.get("model_name", "")) or unified_path.stem.replace("unified.", "")
                model_name = _normalize_model_name(model_name)

                scores = evaluator.evaluate_record(gold, pred, meta, query=query)
                tool_scores = scores["tool"]
                plan_scores = scores["plan"]
                answer_scores = scores["answer"]

                pred_calls = pred.get("tool_calls") or []
                pred_outputs = pred.get("tool_outputs") or []
                success_flags = [_is_success_output(output) for output in pred_outputs]
                if len(success_flags) < len(pred_calls):
                    success_flags.extend([False] * (len(pred_calls) - len(success_flags)))
                success_flags = success_flags[:len(pred_calls)]

                pred_exec_success_rate = (
                    sum(1 for ok in success_flags if ok) / len(pred_calls)
                    if pred_calls else None
                )

                gold_tools = [
                    _extract_tool_name(call.get("tool_id", ""))
                    for call in (gold.get("tool_calls") or [])
                    if call.get("tool_id")
                ]
                successful_pred_tools = [
                    _extract_tool_name(call.get("tool_id", ""))
                    for call, ok in zip(pred_calls, success_flags)
                    if ok and call.get("tool_id")
                ]
                gold_counter = Counter(gold_tools)
                pred_counter = Counter(successful_pred_tools)
                matched_success = sum(min(gold_counter[key], pred_counter[key]) for key in gold_counter)
                gt_aligned_success_rate = (
                    matched_success / len(gold_tools) if gold_tools else None
                )

                successful_observation_text = "\n\n".join(
                    _extract_output_text(output)
                    for output, ok in zip(pred_outputs, success_flags)
                    if ok
                )
                osr = 0.0
                if answer_scores.get("has_answer") and successful_observation_text.strip():
                    observation_answer = evaluator.evaluate_answer(
                        gold.get("final_answer", {}) or {},
                        {"answer": successful_observation_text},
                        query_text=query.get("user_query", ""),
                    )
                    osr = float(observation_answer.exact_match or 0.0)

                span_node_f1 = float(plan_scores.get("span_node_f1", plan_scores.get("node_f1", 0.0)) or 0.0)
                dw_order_f1 = float(plan_scores.get("dw_order_f1", 0.0) or 0.0)
                row = SampleRow(
                    sample_id=sample_id,
                    category=category,
                    model=model_name,
                    planning_score=(span_node_f1 + dw_order_f1) / 2.0,
                    span_node_f1=span_node_f1,
                    semantic_node_f1=span_node_f1,
                    dw_order_f1=dw_order_f1,
                    edge_f1=float(plan_scores.get("edge_f1", 0.0) or 0.0),
                    semantic_edge_f1=float(plan_scores.get("semantic_edge_f1", 0.0) or 0.0),
                    tool_usage_score=_tool_usage_score(tool_scores),
                    gt_aligned_tool_success_rate=gt_aligned_success_rate,
                    pred_exec_success_rate=pred_exec_success_rate,
                    observation_support_rate=osr,
                    exact_match=answer_scores.get("exact_match"),
                    token_f1=answer_scores.get("token_f1"),
                    gold_tool_count=int(tool_scores.get("gold_tool_count", 0) or 0),
                    pred_tool_count=int(tool_scores.get("pred_tool_count", 0) or 0),
                    successful_pred_tool_count=sum(1 for ok in success_flags if ok),
                    has_answer=bool(answer_scores.get("has_answer", False)),
                )
                run_sample_rows.append(row)
                sample_rows.append(row)

        run_rows.append(RunRow(
            category=category,
            model=run_sample_rows[0].model if run_sample_rows else unified_path.stem.replace("unified.", ""),
            n=len(run_sample_rows),
            planning_score=_mean(r.planning_score for r in run_sample_rows),
            span_node_f1=_mean(r.span_node_f1 for r in run_sample_rows),
            semantic_node_f1=_mean(r.semantic_node_f1 for r in run_sample_rows),
            dw_order_f1=_mean(r.dw_order_f1 for r in run_sample_rows),
            edge_f1=_mean(r.edge_f1 for r in run_sample_rows),
            semantic_edge_f1=_mean(r.semantic_edge_f1 for r in run_sample_rows),
            tool_usage_score=_mean(r.tool_usage_score for r in run_sample_rows if r.gold_tool_count > 0),
            gt_aligned_tool_success_rate=_mean(r.gt_aligned_tool_success_rate for r in run_sample_rows if r.gold_tool_count > 0),
            pred_exec_success_rate=_mean(r.pred_exec_success_rate for r in run_sample_rows if r.pred_tool_count > 0),
            observation_support_rate=_mean(r.observation_support_rate for r in run_sample_rows if r.has_answer),
            exact_match=_mean(r.exact_match for r in run_sample_rows if r.has_answer),
            token_f1=_mean(r.token_f1 for r in run_sample_rows if r.has_answer),
        ))

    weighted_rows = _weighted_model_rows(run_rows)

    tool_required_samples = [
        row for row in sample_rows
        if row.has_answer and row.gold_tool_count > 0
    ]
    plan_med = float(np.median([row.planning_score for row in tool_required_samples]))
    tool_med = float(np.median([row.gt_aligned_tool_success_rate or 0.0 for row in tool_required_samples]))
    high_high = [
        row.exact_match for row in tool_required_samples
        if row.planning_score >= plan_med and (row.gt_aligned_tool_success_rate or 0.0) >= tool_med
    ]
    others = [
        row.exact_match for row in tool_required_samples
        if not (
            row.planning_score >= plan_med
            and (row.gt_aligned_tool_success_rate or 0.0) >= tool_med
        )
    ]

    run_corr = {
        "planning_vs_tool_grounding": _corr(
            [row.planning_score for row in run_rows],
            [row.tool_usage_score for row in run_rows],
        ),
        "planning_vs_tool_success": _corr(
            [row.planning_score for row in run_rows],
            [row.gt_aligned_tool_success_rate for row in run_rows],
        ),
        "planning_vs_answer_em": _corr(
            [row.planning_score for row in run_rows],
            [row.exact_match for row in run_rows],
        ),
        "tool_success_vs_answer_em": _corr(
            [row.gt_aligned_tool_success_rate for row in run_rows],
            [row.exact_match for row in run_rows],
        ),
        "osr_vs_answer_em": _corr(
            [row.observation_support_rate for row in run_rows],
            [row.exact_match for row in run_rows],
        ),
    }
    sample_corr = {
        "planning_vs_tool_grounding": _corr(
            [row.planning_score for row in tool_required_samples],
            [row.tool_usage_score for row in tool_required_samples],
        ),
        "planning_vs_tool_success": _corr(
            [row.planning_score for row in tool_required_samples],
            [row.gt_aligned_tool_success_rate for row in tool_required_samples],
        ),
        "planning_vs_answer_em": _corr(
            [row.planning_score for row in sample_rows if row.has_answer],
            [row.exact_match for row in sample_rows if row.has_answer],
        ),
        "tool_success_vs_answer_em": _corr(
            [row.gt_aligned_tool_success_rate for row in tool_required_samples],
            [row.exact_match for row in tool_required_samples],
        ),
        "osr_vs_answer_em": _corr(
            [row.observation_support_rate for row in sample_rows if row.has_answer],
            [row.exact_match for row in sample_rows if row.has_answer],
        ),
    }

    diagnostics = {
        "run_level_correlations": run_corr,
        "sample_level_correlations": sample_corr,
        "median_thresholds": {
            "planning_score": plan_med,
            "gt_aligned_tool_success_rate": tool_med,
        },
        "high_high_vs_rest": {
            "n_high_high": len(high_high),
            "n_rest": len(others),
            "em_high_high": _mean(high_high),
            "em_rest": _mean(others),
            "delta": (_mean(high_high) or 0.0) - (_mean(others) or 0.0),
        },
    }

    _write_csv(output_dir / "gaia_stage_samples.csv", [asdict(row) for row in sample_rows])
    _write_csv(output_dir / "gaia_stage_runs.csv", [asdict(row) for row in run_rows])
    _write_csv(output_dir / "gaia_stage_weighted_models.csv", weighted_rows)
    with (output_dir / "gaia_stage_diagnostics.json").open("w") as f:
        json.dump(diagnostics, f, indent=2, ensure_ascii=False)
    _plot_weighted_stages(weighted_rows, output_dir)


def main() -> None:
    parser = argparse.ArgumentParser(description="Compute stage-wise GAIA diagnostics from answer-mode runs.")
    parser.add_argument("--run_dirs", nargs="+", type=Path, required=True, help="Run directories to analyze.")
    parser.add_argument("--output_dir", type=Path, required=True, help="Directory for derived CSV/JSON/figures.")
    args = parser.parse_args()
    analyze_runs(args.run_dirs, args.output_dir)


if __name__ == "__main__":
    main()
