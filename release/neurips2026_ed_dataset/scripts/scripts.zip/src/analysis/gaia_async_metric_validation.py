#!/usr/bin/env python3
"""
GAIA Cat A validation for async-aware planning metrics.

This script supports two storytelling goals:

1. Show that a validated parallel-aware reference DAG is unfairly penalized by
   strict chain Edge F1 when scored against the original GAIA chain GT, while
   DW-Order F1 better preserves dependency semantics.
2. Under tool-clean answer-mode executions, test whether planning quality is
   more positively associated with answer quality when we use an async-aware
   planning score instead of a strict chain-local score.

Outputs:
- reference_level_async_vs_chain.csv
- model_async_metric_rows.csv
- tool_clean_rows.csv
- reference_metric_recovery.png
- multiorder_parallel_recovery.png
- representative_multiorder_cases.png
- controlled_subset_planning_em.png
- summary.json
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import textwrap
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import matplotlib.pyplot as plt
from matplotlib import gridspec

from src.evaluation.dags_analysis import (
    build_parallel_reference_dag,
    build_reference_dag_from_ordering,
)
from src.evaluation.metrics import ASTEvaluationSystem
from src.evaluation.runner import _load_gold_records, evaluate_file
from src.evaluation.utils import load_jsonl

try:
    from scipy.stats import pearsonr, spearmanr
except Exception:  # pragma: no cover - fallback if scipy is unavailable
    pearsonr = None
    spearmanr = None


REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CHAIN_GOLD = REPO_ROOT / "data" / "GAIA" / "cat_A_text" / "gaia.cat_A.json"
DEFAULT_ASYNC_GOLD = REPO_ROOT / "data" / "GAIA" / "DAGs" / "gaia_cat_A_async_plan.json"
DEFAULT_RUNS = [
    REPO_ROOT / "organized_results" / "gaia" / "cat_A" / "20260402_024258.gaia_cat_A.answer" / "Llama-4-Maverick-17B-128E-Instruct-FP8" / "unified.Llama-4-Maverick-17B-128E-Instruct-FP8.jsonl",
    REPO_ROOT / "organized_results" / "gaia" / "cat_A" / "20260401_180922.gaia_cat_A.answer" / "Mistral-Small-3.2-24B-Instruct-2506" / "unified.Mistral-Small-3.2-24B-Instruct-2506.jsonl",
    REPO_ROOT / "organized_results" / "gaia" / "cat_A" / "20260401_192759.gaia_cat_A.answer" / "gpt-oss-120b" / "unified.gpt-oss-120b.jsonl",
    REPO_ROOT / "organized_results" / "gaia" / "cat_A" / "20260401_213251.gaia_cat_A.answer" / "gpt-oss-20b" / "unified.gpt-oss-20b.jsonl",
]

MODEL_COLORS = {
    "Llama-4-Maverick-17B-128E-Instruct-FP8": "#2E5BFF",
    "Mistral-Small-3.2-24B-Instruct-2506": "#7A52CC",
    "gpt-oss-120b": "#1E8E3E",
    "gpt-oss-20b": "#C26400",
}
CONTROLLED_ATS_THRESHOLD = 0.5


@dataclass
class ReferenceRow:
    sample_id: str
    total_orderings: int
    is_multi_order: int
    chain_edge_f1: float
    chain_dw_order_f1: float
    delta_dw_minus_edge: float
    query: str


@dataclass
class ModelRow:
    model: str
    sample_id: str
    total_orderings: int
    is_multi_order: int
    query: str
    node_f1_chain: float
    chain_edge_f1: float
    chain_dw_order_f1: float
    chain_strict_plan: float
    parallel_edge_f1: float
    parallel_dw_order_f1: float
    parallel_plan_score: float
    best_legal_edge_f1: float
    best_legal_dw_order_f1: float
    best_legal_plan_score: float
    best_legal_index_for_edge: int
    best_legal_index_for_dw: int
    tool_usage_score: Optional[float]
    gt_aligned_tool_success_rate: Optional[float]
    pred_exec_success_rate: Optional[float]
    observation_support_rate: Optional[float]
    exact_match: Optional[float]
    token_f1: Optional[float]
    parse_error: int
    gold_tool_count: int
    pred_tool_count: int


def _load_async_records(path: Path) -> List[Dict[str, Any]]:
    with path.open() as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError(f"Expected list in {path}, got {type(data).__name__}")
    return data


def _safe_mean(values: Iterable[Optional[float]]) -> Optional[float]:
    vals = [float(v) for v in values if v is not None and not math.isnan(float(v))]
    if not vals:
        return None
    return sum(vals) / len(vals)


def _corr(xs: List[float], ys: List[float]) -> Dict[str, Optional[float]]:
    if len(xs) < 3 or len(ys) < 3:
        return {"pearson_r": None, "pearson_p": None, "spearman_rho": None, "spearman_p": None}
    out = {"pearson_r": None, "pearson_p": None, "spearman_rho": None, "spearman_p": None}
    if pearsonr is not None:
        r, p = pearsonr(xs, ys)
        out["pearson_r"] = float(r)
        out["pearson_p"] = float(p)
    if spearmanr is not None:
        rho, p = spearmanr(xs, ys)
        out["spearman_rho"] = float(rho)
        out["spearman_p"] = float(p)
    return out


def _plan_only_gold(plan_dag: Dict[str, Any], async_rec: Dict[str, Any]) -> Dict[str, Any]:
    gold = async_rec.get("gold") or {}
    return {
        "plan_dag": plan_dag,
        "tool_calls": gold.get("tool_calls") or [],
        "final_answer": gold.get("final_answer") or {},
    }


def _plan_only_pred(plan_dag: Dict[str, Any]) -> Dict[str, Any]:
    return {"plan_dag": plan_dag, "tool_calls": [], "tool_outputs": [], "final_answer": {}}


def build_reference_rows(async_records: List[Dict[str, Any]], evaluator: ASTEvaluationSystem) -> List[ReferenceRow]:
    rows: List[ReferenceRow] = []
    for rec in async_records:
        parallel_gold = build_parallel_reference_dag(rec)
        pred = _plan_only_pred(parallel_gold)
        meta = dict(rec.get("meta", {}) or {})
        scores = evaluator.evaluate_record(rec.get("gold") or {}, pred, meta)
        query = ((rec.get("query") or {}).get("user_query") or "").strip()
        total_orderings = int(rec.get("total_orderings", len(rec.get("possible_orderings") or [])) or 1)
        rows.append(
            ReferenceRow(
                sample_id=str(meta.get("id", "")),
                total_orderings=total_orderings,
                is_multi_order=1 if total_orderings > 1 else 0,
                chain_edge_f1=float(scores["plan"]["edge_f1"]),
                chain_dw_order_f1=float(scores["plan"]["dw_order_f1"]),
                delta_dw_minus_edge=float(scores["plan"]["dw_order_f1"] - scores["plan"]["edge_f1"]),
                query=query,
            )
        )
    return rows


def build_model_rows(
    async_records: List[Dict[str, Any]],
    chain_gold_path: Path,
    run_paths: List[Path],
    evaluator: ASTEvaluationSystem,
) -> List[ModelRow]:
    async_by_id = {str(rec.get("meta", {}).get("id", "")): rec for rec in async_records}
    gold_records_by_id = _load_gold_records(chain_gold_path)
    rows: List[ModelRow] = []

    for run_path in run_paths:
        per_sample_results, _summary = evaluate_file(
            run_path,
            use_embeddings=False,
            gold_records_by_id=gold_records_by_id,
            verifier_model=None,
        )
        result_by_id = {r.sample_id: r for r in per_sample_results}

        for rec in load_jsonl(run_path):
            meta = dict(rec.get("meta", {}) or {})
            sample_id = str(meta.get("id", ""))
            async_rec = async_by_id.get(sample_id)
            pred = rec.get("pred") or {}
            pred_plan = pred.get("plan_dag") or {}
            if async_rec is None or not pred_plan:
                continue

            query = ((rec.get("query") or {}).get("user_query") or "").strip()
            chain_scores = evaluator.evaluate_record(async_rec.get("gold") or {}, pred, meta, query=rec.get("query"))

            parallel_gold = _plan_only_gold(build_parallel_reference_dag(async_rec), async_rec)
            parallel_scores = evaluator.evaluate_record(parallel_gold, pred, meta, query=rec.get("query"))

            legal_orderings = async_rec.get("possible_orderings") or []
            if not legal_orderings:
                legal_orderings = [list(range(len(async_rec.get("executable_steps") or [])))]

            best_legal_edge_f1 = -1.0
            best_legal_dw_order_f1 = -1.0
            best_legal_plan_score = -1.0
            best_edge_idx = -1
            best_dw_idx = -1
            for idx, ordering in enumerate(legal_orderings):
                ordering_gold = _plan_only_gold(build_reference_dag_from_ordering(async_rec, ordering), async_rec)
                ordering_scores = evaluator.evaluate_record(ordering_gold, pred, meta, query=rec.get("query"))
                edge_f1 = float(ordering_scores["plan"]["edge_f1"])
                dw_order_f1 = float(ordering_scores["plan"]["dw_order_f1"])
                plan_score = float(ordering_scores["plan"]["planning_score"])
                if edge_f1 > best_legal_edge_f1:
                    best_legal_edge_f1 = edge_f1
                    best_edge_idx = idx
                if dw_order_f1 > best_legal_dw_order_f1:
                    best_legal_dw_order_f1 = dw_order_f1
                    best_dw_idx = idx
                if plan_score > best_legal_plan_score:
                    best_legal_plan_score = plan_score

            ps = result_by_id.get(sample_id)
            total_orderings = int(async_rec.get("total_orderings", len(legal_orderings)) or 1)
            rows.append(
                ModelRow(
                    model=str(meta.get("model_name", run_path.stem)),
                    sample_id=sample_id,
                    total_orderings=total_orderings,
                    is_multi_order=1 if total_orderings > 1 else 0,
                    query=query,
                    node_f1_chain=float(chain_scores["plan"]["node_f1"]),
                    chain_edge_f1=float(chain_scores["plan"]["edge_f1"]),
                    chain_dw_order_f1=float(chain_scores["plan"]["dw_order_f1"]),
                    chain_strict_plan=float(
                        (
                            chain_scores["plan"].get("strict_node_f1", chain_scores["plan"]["node_f1"])
                            + chain_scores["plan"]["edge_f1"]
                        )
                        / 2.0
                    ),
                    parallel_edge_f1=float(parallel_scores["plan"]["edge_f1"]),
                    parallel_dw_order_f1=float(parallel_scores["plan"]["dw_order_f1"]),
                    parallel_plan_score=float(parallel_scores["plan"]["planning_score"]),
                    best_legal_edge_f1=float(best_legal_edge_f1),
                    best_legal_dw_order_f1=float(best_legal_dw_order_f1),
                    best_legal_plan_score=float(best_legal_plan_score),
                    best_legal_index_for_edge=best_edge_idx,
                    best_legal_index_for_dw=best_dw_idx,
                    tool_usage_score=ps.tool_usage_score if ps else None,
                    gt_aligned_tool_success_rate=ps.gt_aligned_tool_success_rate if ps else None,
                    pred_exec_success_rate=ps.pred_exec_success_rate if ps else None,
                    observation_support_rate=ps.observation_support_rate if ps else None,
                    exact_match=ps.exact_match if ps else None,
                    token_f1=ps.token_f1 if ps else None,
                    parse_error=int(ps.parse_error) if ps else 0,
                    gold_tool_count=int(ps.gold_tool_count) if ps else 0,
                    pred_tool_count=int(ps.pred_tool_count) if ps else 0,
                )
            )

    return rows


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def plot_reference_metric_recovery(rows: List[ReferenceRow], output_path: Path) -> None:
    all_edge = [r.chain_edge_f1 for r in rows]
    all_dw = [r.chain_dw_order_f1 for r in rows]
    multi = [r for r in rows if r.is_multi_order]
    multi_edge = [r.chain_edge_f1 for r in multi]
    multi_dw = [r.chain_dw_order_f1 for r in multi]
    cohorts = [
        ("All 127", _safe_mean(all_edge) or 0.0, _safe_mean(all_dw) or 0.0),
        ("Multi-order 40", _safe_mean(multi_edge) or 0.0, _safe_mean(multi_dw) or 0.0),
    ]

    fig, ax = plt.subplots(figsize=(8.8, 3.6))
    y_positions = [1, 0]
    strict_color = "#C8C8C8"
    dw_color = "#2CA02C"

    for y, (label, strict_score, dw_score) in zip(y_positions, cohorts):
        ax.plot([strict_score, dw_score], [y, y], color="#7A7A7A", linewidth=2.3, zorder=1)
        ax.scatter(strict_score, y, s=120, color=strict_color, edgecolor="white", linewidth=0.9, zorder=2)
        ax.scatter(dw_score, y, s=120, color=dw_color, edgecolor="white", linewidth=0.9, zorder=3)
        ax.text(strict_score - 0.012, y - 0.18, f"{strict_score:.3f}", ha="right", va="center", fontsize=9.5, color="#444444")
        ax.text(dw_score + 0.012, y - 0.18, f"{dw_score:.3f}", ha="left", va="center", fontsize=9.5, color=dw_color)
        ax.text(max(strict_score, dw_score) + 0.05, y, f"+{dw_score - strict_score:.3f}", va="center", fontsize=10, color="#2E5BFF", weight="bold")

    ax.set_yticks(y_positions)
    ax.set_yticklabels([c[0] for c in cohorts], fontsize=11)
    ax.set_xlim(0.70, 0.98)
    ax.set_xlabel("Score")
    ax.set_title("Async Reference Scored Against Native Chain GT", fontsize=13)
    ax.grid(axis="x", alpha=0.22)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    ax.scatter([], [], s=90, color=strict_color, edgecolor="white", linewidth=0.9, label="Strict Edge F1")
    ax.scatter([], [], s=90, color=dw_color, edgecolor="white", linewidth=0.9, label="DW-Order F1")
    ax.legend(loc="lower right", frameon=False, fontsize=10)

    fig.suptitle("Reference-Level Validation of Strict Edge F1 vs DW-Order F1", fontsize=15, y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.93])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def select_representative_cases(rows: List[ModelRow], top_k: int = 4) -> List[ModelRow]:
    candidates = [
        r for r in rows
        if r.is_multi_order
        and r.parallel_dw_order_f1 > r.chain_edge_f1
    ]
    candidates.sort(
        key=lambda r: (
            -(r.parallel_dw_order_f1 - r.chain_edge_f1),
            -r.total_orderings,
            -r.node_f1_chain,
            r.model,
            r.sample_id,
        )
    )
    picked: List[ModelRow] = []
    used = set()
    for row in candidates:
        key = (row.model, row.sample_id)
        if key in used:
            continue
        picked.append(row)
        used.add(key)
        if len(picked) >= top_k:
            break
    return picked


def plot_representative_cases(rows: List[ModelRow], output_path: Path) -> None:
    if not rows:
        return

    fig = plt.figure(figsize=(13.2, 11.3))
    gs = gridspec.GridSpec(3, 2, height_ratios=[1.05, 1.0, 1.0], hspace=0.90, wspace=0.42)

    ax_table = fig.add_subplot(gs[0, :])
    ax_table.axis("off")

    table_rows = []
    for r in rows:
        table_rows.append(
            [
                r.model.replace("-Maverick-17B-128E-Instruct-FP8", "").replace("-Instruct", ""),
                r.sample_id[:8],
                str(r.total_orderings),
                textwrap.shorten(r.query, width=52, placeholder="..."),
                f"{r.chain_edge_f1:.3f}",
                f"{r.parallel_edge_f1:.3f}",
                f"{r.parallel_dw_order_f1:.3f}",
            ]
        )
    col_labels = [
        "Model",
        "Sample ID",
        "Orderings",
        "Query Summary",
        "Strict\n(Chain Edge)",
        "Parallel-GT\n(Edge)",
        "Parallel-GT\n(DW)",
    ]
    col_widths = [0.15, 0.11, 0.09, 0.39, 0.09, 0.09, 0.08]
    tbl = ax_table.table(
        cellText=table_rows,
        colLabels=col_labels,
        colWidths=col_widths,
        loc="center",
        cellLoc="left",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(9.5)
    tbl.scale(1, 1.45)
    for (row, col), cell in tbl.get_celld().items():
        cell.set_linewidth(0.0)
        if row == 0:
            cell.set_text_props(weight="bold")
            cell.set_facecolor("#F2F2F2")

    bar_specs = [
        ("Strict", lambda r: r.chain_edge_f1, "#C8C8C8"),
        ("Parallel-E", lambda r: r.parallel_edge_f1, "#36A2EB"),
        ("Parallel-DW", lambda r: r.parallel_dw_order_f1, "#2CA02C"),
    ]
    axes = [
        fig.add_subplot(gs[1, 0]),
        fig.add_subplot(gs[1, 1]),
        fig.add_subplot(gs[2, 0]),
        fig.add_subplot(gs[2, 1]),
    ]

    for ax, row in zip(axes, rows):
        values = [getter(row) for _, getter, _ in bar_specs]
        labels = [label for label, _, _ in bar_specs]
        colors = [color for _, _, color in bar_specs]
        ypos = [2, 1, 0]
        ax.barh(ypos, values, color=colors, edgecolor="white", height=0.5)
        ax.set_yticks(ypos)
        ax.set_yticklabels(labels)
        ax.set_xlim(0, 1.0)
        clean_model = row.model.replace("-Maverick-17B-128E-Instruct-FP8", "").replace("-Instruct", "")
        ax.set_title(f"{clean_model} / {row.sample_id[:8]}", fontsize=11, weight="bold", loc="left")
        for y, value in zip(ypos, values):
            ax.text(min(value + 0.015, 0.98), y, f"{value:.3f}", va="center", fontsize=9)
        ax.grid(axis="x", alpha=0.2)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["left"].set_visible(False)

    fig.suptitle(
        "Representative Multi-Order Cases: Strict Chain Score vs Parallel-Aware Scores",
        fontsize=14,
        y=0.97,
    )
    plt.tight_layout(rect=[0, 0, 1, 0.955])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def plot_multiorder_parallel_recovery(rows: List[ModelRow], output_path: Path) -> None:
    multi = [r for r in rows if r.is_multi_order]
    if not multi:
        return

    strict = [r.chain_edge_f1 for r in multi]
    parallel_dw = [r.parallel_dw_order_f1 for r in multi]
    gains = [r.parallel_dw_order_f1 - r.chain_edge_f1 for r in multi]
    recovered = sum(1 for g in gains if g > 0)

    fig = plt.figure(figsize=(12.8, 4.4))
    gs = gridspec.GridSpec(1, 3, width_ratios=[1.15, 0.9, 0.95], wspace=0.32)
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[0, 2])

    for row in multi:
        color = MODEL_COLORS.get(row.model, "#444444")
        ax0.scatter(
            row.chain_edge_f1,
            row.parallel_dw_order_f1,
            color=color,
            s=42,
            alpha=0.78,
            edgecolor="white",
            linewidth=0.4,
        )
    ax0.plot([0, 1], [0, 1], linestyle="--", color="gray", linewidth=1.0)
    ax0.set_xlim(0, 1.0)
    ax0.set_ylim(0, 1.0)
    ax0.set_xlabel("Strict Edge F1 (Chain GT)")
    ax0.set_ylabel("DW-Order F1 (Parallel GT)")
    ax0.set_title("Multi-Order Sample-Level Contrast")
    ax0.grid(alpha=0.25)
    ax0.text(
        0.03,
        0.97,
        f"Recovered cases: {recovered}/{len(multi)}",
        transform=ax0.transAxes,
        va="top",
        fontsize=9.5,
        bbox=dict(facecolor="white", alpha=0.8, edgecolor="none"),
    )

    parts = ax1.violinplot([strict, parallel_dw], showmeans=True, showextrema=False, widths=0.8)
    for body, color in zip(parts["bodies"], ["#C8C8C8", "#2CA02C"]):
        body.set_facecolor(color)
        body.set_edgecolor(color)
        body.set_alpha(0.45)
    parts["cmeans"].set_color("black")
    ax1.set_xticks([1, 2])
    ax1.set_xticklabels(["Strict\nChain Edge", "Parallel-GT\nDW-Order"])
    ax1.set_ylim(0, 1.0)
    ax1.set_ylabel("Score")
    ax1.set_title("Distribution Shift on Multi-Order Samples")
    ax1.grid(axis="y", alpha=0.25)

    ax2.hist(gains, bins=16, color="#2E5BFF", alpha=0.78, edgecolor="white")
    ax2.axvline(0.0, linestyle="--", color="gray", linewidth=1.0)
    ax2.set_xlabel(r"$\Delta$ (Parallel DW - Chain Strict)")
    ax2.set_ylabel("Sample-model rows")
    ax2.set_title("Recovery Is Concentrated in a Subset")
    ax2.grid(axis="y", alpha=0.25)

    fig.suptitle(
        "Where Parallel-Aware Scoring Recovers Planning Credit",
        fontsize=13,
    )
    plt.tight_layout()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)


def plot_tool_clean_analysis(rows: List[ModelRow], output_path: Path, ats_threshold: float) -> Dict[str, Any]:
    controlled_subset = [
        r for r in rows
        if r.parse_error == 0
        and r.gold_tool_count > 0
        and r.pred_tool_count > 0
        and r.pred_exec_success_rate is not None
        and abs(r.pred_exec_success_rate - 1.0) < 1e-9
        and r.gt_aligned_tool_success_rate is not None
        and float(r.gt_aligned_tool_success_rate) >= ats_threshold
        and r.token_f1 is not None
        and r.exact_match is not None
    ]

    planning_x = [r.best_legal_plan_score for r in controlled_subset]
    token_y = [float(r.token_f1 or 0.0) for r in controlled_subset]
    em_y = [float(r.exact_match or 0.0) for r in controlled_subset]
    plan_token_corr = _corr(planning_x, token_y)
    plan_em_corr = _corr(planning_x, em_y)

    correct = [r.best_legal_plan_score for r in controlled_subset if (r.exact_match or 0.0) >= 1.0]
    wrong = [r.best_legal_plan_score for r in controlled_subset if (r.exact_match or 0.0) < 1.0]

    sorted_rows = sorted(controlled_subset, key=lambda r: r.best_legal_plan_score)
    mid = len(sorted_rows) // 2
    low_half = sorted_rows[:mid]
    high_half = sorted_rows[mid:]

    low_solve = _safe_mean(float(r.exact_match or 0.0) for r in low_half) or 0.0
    high_solve = _safe_mean(float(r.exact_match or 0.0) for r in high_half) or 0.0
    low_token = _safe_mean(float(r.token_f1 or 0.0) for r in low_half) or 0.0
    high_token = _safe_mean(float(r.token_f1 or 0.0) for r in high_half) or 0.0

    fig = plt.figure(figsize=(10.8, 4.6))
    gs = gridspec.GridSpec(1, 2, width_ratios=[1.05, 0.95], wspace=0.28)
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])

    bp = ax0.boxplot(
        [wrong, correct],
        tick_labels=[f"EM = 0\n(n={len(wrong)})", f"EM = 1\n(n={len(correct)})"],
        patch_artist=True,
        widths=0.58,
        boxprops=dict(facecolor="#DDE8FF", edgecolor="#4A5C7A", linewidth=1.2),
        medianprops=dict(color="#1D3C91", linewidth=1.8),
        whiskerprops=dict(color="#4A5C7A", linewidth=1.1),
        capprops=dict(color="#4A5C7A", linewidth=1.1),
    )
    for patch, color in zip(bp["boxes"], ["#E6E6E6", "#CFE3FF"]):
        patch.set_facecolor(color)

    ax0.set_ylim(0, 1.0)
    ax0.set_ylabel("Async-Aware Planning Score")
    ax0.set_title("Planning-Score Distribution by Final Outcome")
    ax0.grid(axis="y", alpha=0.22)
    ax0.text(
        0.03,
        0.97,
        f"Controlled subset:\nparse = 0\nexec success = 1.0\nATS ≥ {ats_threshold:.1f}",
        transform=ax0.transAxes,
        va="top",
        fontsize=9,
        bbox=dict(facecolor="white", alpha=0.85, edgecolor="none"),
    )

    bars = ax1.bar(
        [0, 1],
        [low_solve, high_solve],
        color=["#C8C8C8", "#2CA02C"],
        edgecolor="white",
        width=0.58,
    )
    ax1.set_xticks([0, 1])
    ax1.set_xticklabels([f"Lower Half\n(n={len(low_half)})", f"Upper Half\n(n={len(high_half)})"])
    ax1.set_ylim(0, max(0.35, high_solve * 1.4))
    ax1.set_ylabel("Solve Rate (EM)")
    ax1.set_title("Solve Rate by Planning-Score Half")
    ax1.grid(axis="y", alpha=0.22)
    for bar, value in zip(bars, [low_solve, high_solve]):
        ax1.text(bar.get_x() + bar.get_width() / 2, value + 0.008, f"{value:.3f}", ha="center", va="bottom", fontsize=10)
    ax1.text(
        0.03,
        0.97,
        "\n".join(
            [
                f"EM Pearson r = {plan_em_corr['pearson_r']:.3f}" if plan_em_corr["pearson_r"] is not None else "EM Pearson r = n/a",
                f"EM Spearman ρ = {plan_em_corr['spearman_rho']:.3f}" if plan_em_corr["spearman_rho"] is not None else "EM Spearman ρ = n/a",
                f"Token F1 Pearson r = {plan_token_corr['pearson_r']:.3f}" if plan_token_corr["pearson_r"] is not None else "Token F1 Pearson r = n/a",
            ]
        ),
        transform=ax1.transAxes,
        va="top",
        fontsize=9,
        bbox=dict(facecolor="white", alpha=0.85, edgecolor="none"),
    )

    fig.suptitle(
        "Controlled-Subset View: Higher Planning Quality Tends To Improve Solve Rate",
        fontsize=13,
    )
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=220, bbox_inches="tight")
    plt.close(fig)

    return {
        "controlled_subset_count": len(controlled_subset),
        "ats_threshold": ats_threshold,
        "planning_vs_token_f1": plan_token_corr,
        "planning_vs_exact_match": plan_em_corr,
        "mean_async_plan_em0": _safe_mean(wrong),
        "mean_async_plan_em1": _safe_mean(correct),
        "low_half_solve_rate": low_solve,
        "high_half_solve_rate": high_solve,
        "low_half_token_f1": low_token,
        "high_half_token_f1": high_token,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate async-aware GAIA Cat A planning metrics.")
    parser.add_argument("--chain-gold", type=Path, default=DEFAULT_CHAIN_GOLD)
    parser.add_argument("--async-gold", type=Path, default=DEFAULT_ASYNC_GOLD)
    parser.add_argument("--runs", nargs="*", type=Path, default=DEFAULT_RUNS)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REPO_ROOT / "organized_results" / "analysis" / "gaia_cat_A_async_metric_validation_20260418_type_aware",
    )
    parser.add_argument("--controlled-ats-threshold", type=float, default=CONTROLLED_ATS_THRESHOLD)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)

    async_records = _load_async_records(args.async_gold)
    evaluator = ASTEvaluationSystem(use_embeddings=False)

    reference_rows = build_reference_rows(async_records, evaluator)
    model_rows = build_model_rows(async_records, args.chain_gold, args.runs, evaluator)

    _write_csv(args.output_dir / "reference_level_async_vs_chain.csv", [asdict(r) for r in reference_rows])
    _write_csv(args.output_dir / "model_async_metric_rows.csv", [asdict(r) for r in model_rows])

    tool_clean_rows = [
        asdict(r) for r in model_rows
        if r.parse_error == 0
        and r.gold_tool_count > 0
        and r.pred_tool_count > 0
        and r.pred_exec_success_rate is not None
        and abs(r.pred_exec_success_rate - 1.0) < 1e-9
    ]
    _write_csv(args.output_dir / "tool_clean_rows.csv", tool_clean_rows)

    plot_reference_metric_recovery(reference_rows, args.output_dir / "reference_metric_recovery.png")
    plot_multiorder_parallel_recovery(model_rows, args.output_dir / "multiorder_parallel_recovery.png")
    plot_representative_cases(select_representative_cases(model_rows), args.output_dir / "representative_multiorder_cases.png")
    corr_summary = plot_tool_clean_analysis(
        model_rows,
        args.output_dir / "controlled_subset_planning_em.png",
        ats_threshold=float(args.controlled_ats_threshold),
    )

    multi_order_model_rows = [r for r in model_rows if r.is_multi_order]
    parallel_gain_multi = [r.parallel_dw_order_f1 - r.chain_edge_f1 for r in multi_order_model_rows]
    summary = {
        "reference_level": {
            "all_count": len(reference_rows),
            "multi_order_count": sum(r.is_multi_order for r in reference_rows),
            "mean_chain_edge_f1": _safe_mean(r.chain_edge_f1 for r in reference_rows),
            "mean_chain_dw_order_f1": _safe_mean(r.chain_dw_order_f1 for r in reference_rows),
            "mean_multi_chain_edge_f1": _safe_mean(r.chain_edge_f1 for r in reference_rows if r.is_multi_order),
            "mean_multi_chain_dw_order_f1": _safe_mean(r.chain_dw_order_f1 for r in reference_rows if r.is_multi_order),
        },
        "model_level": {
            "row_count": len(model_rows),
            "multi_order_row_count": len(multi_order_model_rows),
            "mean_chain_edge_f1_multi": _safe_mean(r.chain_edge_f1 for r in multi_order_model_rows),
            "mean_parallel_edge_f1_multi": _safe_mean(r.parallel_edge_f1 for r in multi_order_model_rows),
            "mean_parallel_dw_order_f1_multi": _safe_mean(r.parallel_dw_order_f1 for r in multi_order_model_rows),
            "mean_best_legal_edge_f1_multi": _safe_mean(r.best_legal_edge_f1 for r in multi_order_model_rows),
            "mean_best_legal_dw_order_f1_multi": _safe_mean(r.best_legal_dw_order_f1 for r in multi_order_model_rows),
            "parallel_dw_gt_chain_edge_positive_count": sum(1 for g in parallel_gain_multi if g > 0),
            "parallel_dw_gt_chain_edge_positive_rate": _safe_mean(1.0 if g > 0 else 0.0 for g in parallel_gain_multi),
        },
        "controlled_subset_analysis": corr_summary,
    }
    with (args.output_dir / "summary.json").open("w") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    print(f"[INFO] Wrote outputs to: {args.output_dir}")
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
