#!/usr/bin/env python3
"""
Generate final two figures:
1. fig_final_answer_comparison.png - EM vs Judge for each model
2. fig_final_answer_by_level.png - Performance by level with separate EM/Judge bars

Usage:
    python -m src.analysis.generate_final_figures --results_dir ./organized_results/gaia/cat_B/xxx
"""

import json
import argparse
from pathlib import Path
from typing import Dict, List, Tuple
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from collections import defaultdict


def load_llm_judge_summary(results_dir: Path) -> pd.DataFrame:
    """Load LLM judge summary CSV."""
    judge_file = results_dir / "llm_judge" / "llm_judge_summary.csv"
    if not judge_file.exists():
        raise FileNotFoundError(f"LLM judge summary not found: {judge_file}")

    df = pd.read_csv(judge_file)
    return df


def load_level_data(results_dir: Path) -> Dict[str, Dict[str, Dict[str, Tuple[int, int]]]]:
    """
    Load per-level performance data.

    Returns:
        {
            model_name: {
                'Level 1': {'em': (correct, total), 'judge': (correct, total)},
                'Level 2': {...},
                'Level 3': {...}
            }
        }
    """
    level_data = {}

    for model_dir in sorted(results_dir.iterdir()):
        if not model_dir.is_dir():
            continue

        model_name = model_dir.name
        unified_file = list(model_dir.glob("unified.*.jsonl"))

        if not unified_file:
            continue

        unified_file = unified_file[0]

        # Load LLM judge sample results
        judge_sample_file = results_dir / "llm_judge" / f"samples_{model_name}.csv"
        if not judge_sample_file.exists():
            continue

        df_samples = pd.read_csv(judge_sample_file)

        # Initialize level counters
        level_stats = defaultdict(lambda: {'em_correct': 0, 'em_total': 0, 'judge_correct': 0, 'judge_total': 0})

        # Read unified file to get level info
        with open(unified_file, 'r') as f:
            for i, line in enumerate(f):
                data = json.loads(line)
                subset = data['meta']['subset']

                # Extract level number (e.g., "level_2_B" -> "Level 2")
                level_parts = subset.split('_')
                if len(level_parts) >= 2 and level_parts[0] == 'level':
                    level_num = level_parts[1]
                    level_name = f"Level {level_num}"
                else:
                    continue

                # Get scores from judge CSV
                if i < len(df_samples):
                    em_score = df_samples.iloc[i]['exact_match']
                    judge_score = df_samples.iloc[i]['llm_judge_score']

                    level_stats[level_name]['em_correct'] += em_score
                    level_stats[level_name]['em_total'] += 1
                    level_stats[level_name]['judge_correct'] += judge_score
                    level_stats[level_name]['judge_total'] += 1

        # Convert to desired format
        model_level_data = {}
        for level_name, stats in level_stats.items():
            model_level_data[level_name] = {
                'em': (stats['em_correct'], stats['em_total']),
                'judge': (stats['judge_correct'], stats['judge_total'])
            }

        level_data[model_name] = model_level_data

    return level_data


def plot_comparison(df_judge: pd.DataFrame, output_path: Path):
    """
    Generate fig_final_answer_comparison.png with EM vs Judge bars.
    """
    fig, ax = plt.subplots(figsize=(14, 8))

    models = df_judge['Model'].tolist()
    em_accuracy = df_judge['EM_Accuracy'].tolist()
    judge_accuracy = df_judge['Judge_Accuracy'].tolist()

    x = np.arange(len(models))
    width = 0.35

    # Plot bars
    bars1 = ax.bar(x - width/2, em_accuracy, width,
                   label='Exact Match', color='#3498db', alpha=0.85,
                   edgecolor='black', linewidth=1.2)
    bars2 = ax.bar(x + width/2, judge_accuracy, width,
                   label='LLM-as-a-Judge', color='#e74c3c', alpha=0.85,
                   edgecolor='black', linewidth=1.2)

    # Add value labels
    for bars in [bars1, bars2]:
        for bar in bars:
            height = bar.get_height()
            if height > 0:
                ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                       f'{height:.1%}',
                       ha='center', va='bottom', fontsize=10, fontweight='bold')

    ax.set_xlabel('Model', fontsize=13, fontweight='bold')
    ax.set_ylabel('Answer Accuracy', fontsize=13, fontweight='bold')
    ax.set_title('Final Answer Accuracy: Exact Match vs LLM-as-a-Judge',
                 fontsize=16, fontweight='bold', pad=20)
    ax.set_xticks(x)
    ax.set_xticklabels(models, rotation=45, ha='right', fontsize=11)
    ax.legend(loc='upper left', fontsize=12, framealpha=0.95, edgecolor='black')
    ax.set_ylim(0, max(max(em_accuracy), max(judge_accuracy)) * 1.15)
    ax.grid(axis='y', alpha=0.3, linestyle='--', linewidth=1)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.savefig(output_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close()

    print(f"[SAVED] {output_path}")


def plot_by_level(level_data: Dict, output_path: Path):
    """
    Generate fig_final_answer_by_level.png with separate EM/Judge bars per model.
    Each model has different color, bars don't overlap, show correct/total on top.
    """
    # Prepare data
    models = sorted(level_data.keys())
    levels = sorted(set(level for model_data in level_data.values() for level in model_data.keys()))

    if not levels:
        print("[WARN] No level data available")
        return

    # Define colors for each model
    colors = [
        '#e74c3c',  # Red
        '#3498db',  # Blue
        '#2ecc71',  # Green
        '#f39c12',  # Orange
        '#9b59b6',  # Purple
        '#1abc9c',  # Teal
    ]

    fig, ax = plt.subplots(figsize=(16, 9))

    n_models = len(models)
    n_levels = len(levels)

    # Calculate bar width and positions
    # For each level, we have n_models * 2 bars (EM + Judge for each model)
    bar_width = 0.8 / (n_models * 2)  # Total width is 0.8 per level

    x_positions = np.arange(n_levels)

    # Plot bars for each model
    for model_idx, model in enumerate(models):
        model_data = level_data[model]
        color = colors[model_idx % len(colors)]

        # Darker shade for EM, lighter for Judge
        em_color = color
        judge_color = matplotlib.colors.to_rgba(color, alpha=0.6)

        em_accuracies = []
        judge_accuracies = []
        em_labels = []
        judge_labels = []

        for level in levels:
            if level in model_data:
                em_correct, em_total = model_data[level]['em']
                judge_correct, judge_total = model_data[level]['judge']

                em_acc = em_correct / em_total if em_total > 0 else 0
                judge_acc = judge_correct / judge_total if judge_total > 0 else 0

                em_accuracies.append(em_acc)
                judge_accuracies.append(judge_acc)
                em_labels.append(f"{em_correct}/{em_total}")
                judge_labels.append(f"{judge_correct}/{judge_total}")
            else:
                em_accuracies.append(0)
                judge_accuracies.append(0)
                em_labels.append("")
                judge_labels.append("")

        # Calculate positions for this model's bars
        # Each model gets 2 bars (EM + Judge) side by side
        offset = (model_idx * 2 - n_models) * bar_width

        # EM bars
        bars_em = ax.bar(x_positions + offset, em_accuracies, bar_width * 0.95,
                        label=f'{model} (EM)' if model_idx == 0 else '',
                        color=em_color, edgecolor='black', linewidth=1.0)

        # Judge bars (right next to EM bars)
        bars_judge = ax.bar(x_positions + offset + bar_width, judge_accuracies, bar_width * 0.95,
                           label=f'{model} (Judge)' if model_idx == 0 else '',
                           color=judge_color, edgecolor='black', linewidth=1.0, hatch='//')

        # Add labels showing correct/total
        for i, (bar_em, bar_judge, em_label, judge_label) in enumerate(zip(bars_em, bars_judge, em_labels, judge_labels)):
            # EM label
            if em_label:
                height_em = bar_em.get_height()
                ax.text(bar_em.get_x() + bar_em.get_width()/2., height_em,
                       em_label,
                       ha='center', va='bottom', fontsize=7, fontweight='bold', rotation=90)

            # Judge label
            if judge_label:
                height_judge = bar_judge.get_height()
                ax.text(bar_judge.get_x() + bar_judge.get_width()/2., height_judge,
                       judge_label,
                       ha='center', va='bottom', fontsize=7, fontweight='bold', rotation=90)

    ax.set_xlabel('Difficulty Level', fontsize=13, fontweight='bold')
    ax.set_ylabel('Answer Accuracy', fontsize=13, fontweight='bold')
    ax.set_title('Final Answer Accuracy by Difficulty Level (EM vs LLM-as-a-Judge)',
                 fontsize=16, fontweight='bold', pad=20)
    ax.set_xticks(x_positions)
    ax.set_xticklabels(levels, fontsize=12)
    ax.set_ylim(0, 1.1)
    ax.grid(axis='y', alpha=0.3, linestyle='--', linewidth=1)

    # Create custom legend with model colors
    from matplotlib.patches import Patch
    legend_elements = []
    for model_idx, model in enumerate(models):
        color = colors[model_idx % len(colors)]
        legend_elements.append(Patch(facecolor=color, edgecolor='black', label=model))

    # Add explanation for EM vs Judge
    legend_elements.append(Patch(facecolor='gray', edgecolor='black', label=''))
    legend_elements.append(Patch(facecolor='gray', edgecolor='black', label='Solid = EM'))
    legend_elements.append(Patch(facecolor='gray', edgecolor='black', label='Hatched = Judge', hatch='//'))

    ax.legend(handles=legend_elements, loc='upper right', fontsize=9, ncol=2,
              framealpha=0.95, edgecolor='black', fancybox=True)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.savefig(output_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close()

    print(f"[SAVED] {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Generate final two figures with corrected logic"
    )
    parser.add_argument(
        "--results_dir",
        type=str,
        required=True,
        help="Directory containing model results and llm_judge subdirectory"
    )
    args = parser.parse_args()

    results_dir = Path(args.results_dir)

    if not results_dir.exists():
        print(f"[ERROR] Results directory not found: {results_dir}")
        sys.exit(1)

    figures_dir = results_dir / "figures"
    figures_dir.mkdir(exist_ok=True)

    print("=" * 80)
    print("Generating Final Figures")
    print("=" * 80)
    print(f"Results directory: {results_dir}")
    print(f"Figures directory: {figures_dir}")
    print()

    # Load data
    print("Loading data...")
    df_judge = load_llm_judge_summary(results_dir)
    level_data = load_level_data(results_dir)

    print(f"Loaded {len(df_judge)} models")
    print(f"Loaded level data for {len(level_data)} models")
    print()

    # Generate figures
    print("Generating figures...")

    # 1. Comparison figure
    plot_comparison(df_judge, figures_dir / "fig_final_answer_comparison.png")

    # 2. By-level figure
    plot_by_level(level_data, figures_dir / "fig_final_answer_by_level.png")

    print()
    print("=" * 80)
    print("Figures Generated Successfully!")
    print("=" * 80)
    print()


if __name__ == "__main__":
    main()
