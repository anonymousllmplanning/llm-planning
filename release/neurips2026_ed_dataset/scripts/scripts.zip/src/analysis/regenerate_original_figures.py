#!/usr/bin/env python3
"""
Regenerate original figures (fig_final_answer_comparison.png and fig_final_answer_by_level.png)
to include LLM-as-a-Judge scores alongside Exact Match.
"""

import json
import argparse
from pathlib import Path
from typing import Dict
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


def load_data(results_dir: Path):
    """Load both exact match and LLM judge data."""

    # Load LLM judge summary
    judge_file = results_dir / "llm_judge" / "llm_judge_summary.csv"
    if not judge_file.exists():
        raise FileNotFoundError(f"LLM judge summary not found: {judge_file}")

    df_judge = pd.read_csv(judge_file)

    # Load exact match data from summary.*.json files
    em_data = {}
    for summary_file in results_dir.glob("summary.*.json"):
        model_name = summary_file.stem.replace("summary.", "")

        with open(summary_file, 'r') as f:
            data = json.load(f)

        if '_overall' in data:
            overall = data['_overall']
            answer_metrics = overall.get('answer', {})
            em_data[model_name] = answer_metrics.get('exact_match', 0.0)

    return df_judge, em_data


def regenerate_comparison_figure(df_judge: pd.DataFrame, em_data: Dict, output_path: Path):
    """
    Regenerate fig_final_answer_comparison.png with BOTH EM and Judge scores.
    """
    fig, ax = plt.subplots(figsize=(14, 8))

    models = df_judge['Model'].tolist()
    judge_scores = df_judge['Judge_Accuracy'].tolist()

    # Get EM scores in same order
    em_scores = [em_data.get(model, 0.0) for model in models]

    x = np.arange(len(models))
    width = 0.35

    # Plot bars
    bars1 = ax.bar(x - width/2, em_scores, width,
                   label='Exact Match (Blue)', color='#3498db', alpha=0.85, edgecolor='black', linewidth=1.2)
    bars2 = ax.bar(x + width/2, judge_scores, width,
                   label='LLM-as-a-Judge (Red)', color='#e74c3c', alpha=0.85, edgecolor='black', linewidth=1.2)

    # Add value labels on bars
    for bars in [bars1, bars2]:
        for bar in bars:
            height = bar.get_height()
            if height > 0:
                ax.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                       f'{height:.1%}',
                       ha='center', va='bottom', fontsize=10, fontweight='bold')

    ax.set_xlabel('Model', fontsize=13, fontweight='bold')
    ax.set_ylabel('Answer Accuracy', fontsize=13, fontweight='bold')
    ax.set_title('Final Answer Accuracy: Exact Match vs LLM-as-a-Judge',
                 fontsize=16, fontweight='bold', pad=20)
    ax.set_xticks(x)
    ax.set_xticklabels(models, rotation=45, ha='right', fontsize=11)
    ax.legend(loc='upper left', fontsize=12, framealpha=0.95, edgecolor='black', fancybox=True)
    ax.set_ylim(0, max(max(em_scores), max(judge_scores)) * 1.15)
    ax.grid(axis='y', alpha=0.3, linestyle='--', linewidth=1)

    # Add note about improvement
    avg_improvement = df_judge['Improvement'].mean() * 100
    ax.text(0.99, 0.02, f'Avg Improvement: +{avg_improvement:.1f}%',
           transform=ax.transAxes, ha='right', va='bottom',
           fontsize=10, style='italic',
           bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.savefig(output_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close()

    print(f"[UPDATED] {output_path}")


def regenerate_by_level_figure(df_judge: pd.DataFrame, results_dir: Path, output_path: Path):
    """
    Regenerate fig_final_answer_by_level.png with BOTH EM and Judge scores by level.
    """
    # Load per-sample data to get level information
    level_data_em = {}
    level_data_judge = {}

    for model_dir in results_dir.iterdir():
        if not model_dir.is_dir():
            continue

        model_name = model_dir.name
        unified_file = list(model_dir.glob("unified.*.jsonl"))

        if not unified_file:
            continue

        unified_file = unified_file[0]

        # Initialize level dictionaries
        level_em = {'Level 1': [], 'Level 2': [], 'Level 3': []}
        level_judge = {'Level 1': [], 'Level 2': [], 'Level 3': []}

        # Load LLM judge sample results
        judge_sample_file = results_dir / "llm_judge" / f"samples_{model_name}.csv"
        if not judge_sample_file.exists():
            continue

        df_samples = pd.read_csv(judge_sample_file)

        # Read unified file to get level info and EM scores
        with open(unified_file, 'r') as f:
            for i, line in enumerate(f):
                data = json.loads(line)
                subset = data['meta']['subset']

                # Extract level number (e.g., "level_2_B" -> "Level 2")
                level_match = subset.split('_')
                if len(level_match) >= 2:
                    level_num = level_match[1]
                    level_name = f"Level {level_num}"
                else:
                    continue

                # Get EM score
                gold_text = str(data['gold']['final_answer'].get('answer', ''))
                pred_text = str(data['pred']['final_answer'].get('answer', ''))
                em_score = 1 if gold_text.lower().strip() == pred_text.lower().strip() else 0

                # Get judge score
                if i < len(df_samples):
                    judge_score = df_samples.iloc[i]['llm_judge_score']
                else:
                    judge_score = 0

                if level_name in level_em:
                    level_em[level_name].append(em_score)
                    level_judge[level_name].append(judge_score)

        # Calculate average per level
        level_data_em[model_name] = {
            level: np.mean(scores) if scores else 0.0
            for level, scores in level_em.items()
        }
        level_data_judge[model_name] = {
            level: np.mean(scores) if scores else 0.0
            for level, scores in level_judge.items()
        }

    if not level_data_em or not level_data_judge:
        print("[WARN] No level data available for by-level plot")
        return

    # Prepare plot data
    models = sorted(level_data_em.keys())
    levels = ['Level 1', 'Level 2', 'Level 3']

    fig, ax = plt.subplots(figsize=(14, 8))

    x = np.arange(len(levels))
    width = 0.12  # Narrower bars for 6 models × 2 metrics

    colors_em = plt.cm.Blues(np.linspace(0.5, 0.9, len(models)))
    colors_judge = plt.cm.Reds(np.linspace(0.5, 0.9, len(models)))

    for i, model in enumerate(models):
        em_scores = [level_data_em[model].get(level, 0.0) for level in levels]
        judge_scores = [level_data_judge[model].get(level, 0.0) for level in levels]

        # Plot EM bars (left side)
        bars_em = ax.bar(x + (i - len(models)/2) * width, em_scores, width * 0.9,
                         label=f'{model} (EM)' if i == 0 else '',
                         color=colors_em[i], alpha=0.85, edgecolor='black', linewidth=0.8)

        # Plot Judge bars (right side, slightly offset)
        bars_judge = ax.bar(x + (i - len(models)/2 + 0.15) * width, judge_scores, width * 0.9,
                           label=f'{model} (Judge)' if i == 0 else '',
                           color=colors_judge[i], alpha=0.85, edgecolor='black', linewidth=0.8)

        # Add value labels (only for judge scores to avoid clutter)
        for bar in bars_judge:
            height = bar.get_height()
            if height > 0.05:  # Only show if significant
                ax.text(bar.get_x() + bar.get_width()/2., height,
                       f'{height:.0%}',
                       ha='center', va='bottom', fontsize=7, rotation=90)

    ax.set_xlabel('Difficulty Level', fontsize=13, fontweight='bold')
    ax.set_ylabel('Answer Accuracy', fontsize=13, fontweight='bold')
    ax.set_title('Final Answer Accuracy by Difficulty Level (EM vs LLM-as-a-Judge)',
                 fontsize=16, fontweight='bold', pad=20)
    ax.set_xticks(x)
    ax.set_xticklabels(levels, fontsize=12)

    # Create custom legend
    from matplotlib.patches import Patch
    legend_elements = []
    for model in models:
        legend_elements.append(Patch(facecolor='#3498db', edgecolor='black', label=model))
    legend_elements.append(Patch(facecolor='none', edgecolor='none', label=''))
    legend_elements.append(Patch(facecolor='#3498db', edgecolor='black', label='□ = Exact Match'))
    legend_elements.append(Patch(facecolor='#e74c3c', edgecolor='black', label='□ = LLM-as-a-Judge'))

    ax.legend(handles=legend_elements, loc='best', fontsize=9, ncol=2,
              framealpha=0.95, edgecolor='black', fancybox=True)

    ax.set_ylim(0, 1.0)
    ax.grid(axis='y', alpha=0.3, linestyle='--', linewidth=1)

    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.savefig(output_path.with_suffix('.pdf'), bbox_inches='tight')
    plt.close()

    print(f"[UPDATED] {output_path}")


def main():
    parser = argparse.ArgumentParser(
        description="Regenerate original figures with LLM-as-a-Judge scores"
    )
    parser.add_argument(
        "--results_dir",
        type=str,
        required=True,
        help="Directory containing model results"
    )
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    figures_dir = results_dir / "figures"

    print("=" * 80)
    print("Regenerating Original Figures with LLM-as-a-Judge")
    print("=" * 80)
    print(f"Results directory: {results_dir}")
    print(f"Figures directory: {figures_dir}")
    print()

    # Load data
    print("Loading data...")
    df_judge, em_data = load_data(results_dir)
    print(f"Loaded data for {len(df_judge)} models")
    print()

    # Regenerate figures
    print("Regenerating figures...")

    regenerate_comparison_figure(
        df_judge, em_data,
        figures_dir / "fig_final_answer_comparison.png"
    )

    regenerate_by_level_figure(
        df_judge, results_dir,
        figures_dir / "fig_final_answer_by_level.png"
    )

    print()
    print("=" * 80)
    print("Figures Updated Successfully!")
    print("=" * 80)
    print()


if __name__ == "__main__":
    main()
