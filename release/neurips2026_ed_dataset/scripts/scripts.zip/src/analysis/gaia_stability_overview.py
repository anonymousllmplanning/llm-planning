#!/usr/bin/env python3
"""
Compact stability overview for GAIA multi-run experiments.

Goals:
- emphasize planning/tool stability with mean +- std proxy
- keep Cat A visible even when only partial data is available
- avoid touching inference/evaluation pipeline code
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path
from statistics import mean, median
from typing import Any, Dict, List, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[2]
THREE_RUN_ROOT = ROOT / "organized_results" / "gaia" / "3run"
CAT_A_ROOT = ROOT / "organized_results" / "gaia" / "cat_A"
OUTPUT_DIR = THREE_RUN_ROOT / "stability_overview"

MODEL_ORDER = [
    "gpt-oss-20b",
    "gpt-oss-120b",
    "Llama-3.1-405B-Instruct-FP8",
    "Llama-3.3-70B-Instruct",
    "Llama-4-Maverick-17B-128E-Instruct-FP8",
    "Mistral-Small-3.2-24B-Instruct-2506",
]

MODEL_LABELS = {
    "gpt-oss-20b": "gpt-oss-20b",
    "gpt-oss-120b": "gpt-oss-120b",
    "Llama-3.1-405B-Instruct-FP8": "Llama-3.1-405B",
    "Llama-3.3-70B-Instruct": "Llama-3.3-70B",
    "Llama-4-Maverick-17B-128E-Instruct-FP8": "Llama-4-Maverick",
    "Mistral-Small-3.2-24B-Instruct-2506": "Mistral-Small-3.2-24B",
}

MODEL_COLORS = {
    "gpt-oss-20b": "#4E79A7",
    "gpt-oss-120b": "#E15759",
    "Llama-3.1-405B-Instruct-FP8": "#59A14F",
    "Llama-3.3-70B-Instruct": "#F28E2B",
    "Llama-4-Maverick-17B-128E-Instruct-FP8": "#76B7B2",
    "Mistral-Small-3.2-24B-Instruct-2506": "#B07AA1",
}

CAT_ORDER = ["A", "B", "C", "D"]
CAT_LABELS = {
    "A": "Text only",
    "B": "Documents analysis",
    "C": "Vision",
    "D": "Audio",
}
CAT_TOTALS = {
    "A": 127,
    "B": 25,
    "C": 10,
    "D": 3,
}

PLAN_METRICS = ["node_f1", "edge_f1", "node_label_similarity", "ssi"]
TOOL_METRICS = ["tool_name_f1", "param_name_f1", "type_aware_value_f1"]

SUMMARY_OVERRIDE_PATHS = {
    ("gpt-oss-20b", "A"): ROOT / "organized_results" / "gaia" / "cat_A" / "20260401_213251.gaia_cat_A.answer" / "summary.gpt-oss-20b.json",
    ("gpt-oss-20b", "B"): ROOT / "organized_results" / "gaia" / "cat_B" / "20260401_235329.gaia_cat_B.answer" / "summary.gpt-oss-20b.json",
    ("gpt-oss-20b", "C"): ROOT / "organized_results" / "gaia" / "cat_C" / "20260402_001456.gaia_cat_C.answer" / "summary.gpt-oss-20b.json",
    ("gpt-oss-20b", "D"): ROOT / "organized_results" / "gaia" / "cat_D" / "20260402_003958.gaia_cat_D.answer" / "summary.gpt-oss-20b.json",
    ("gpt-oss-120b", "A"): ROOT / "organized_results" / "gaia" / "cat_A" / "20260401_192759.gaia_cat_A.answer" / "summary.gpt-oss-120b.json",
    ("gpt-oss-120b", "B"): ROOT / "organized_results" / "gaia" / "3run" / "B" / "20260401_205039.gaia_cat_B.answer" / "summary.gpt-oss-120b.json",
    ("gpt-oss-120b", "C"): ROOT / "organized_results" / "gaia" / "3run" / "C" / "aggregated_3runs_20260320_223451" / "20260401_210524.gaia_cat_C.answer" / "summary.gpt-oss-120b.json",
    ("gpt-oss-120b", "D"): ROOT / "organized_results" / "gaia" / "3run" / "D" / "aggregated_3runs_20260320_200151" / "20260401_212849.gaia_cat_D.answer" / "summary.gpt-oss-120b.json",
    ("Llama-3.1-405B-Instruct-FP8", "A"): ROOT / "organized_results" / "gaia" / "cat_A" / "20260401_175737.gaia_cat_A.answer" / "summary.Llama-3.1-405B-Instruct-FP8.json",
    ("Llama-3.1-405B-Instruct-FP8", "B"): ROOT / "organized_results" / "gaia" / "cat_B" / "20260401_234545.gaia_cat_B.answer" / "summary.Llama-3.1-405B-Instruct-FP8.json",
    ("Llama-3.1-405B-Instruct-FP8", "C"): ROOT / "organized_results" / "gaia" / "3run" / "C" / "aggregated_3runs_20260320_223451" / "20260402_013919.gaia_cat_C.answer" / "summary.Llama-3.1-405B-Instruct-FP8.json",
    ("Llama-3.1-405B-Instruct-FP8", "D"): ROOT / "organized_results" / "gaia" / "cat_D" / "20260402_004456.gaia_cat_D.answer" / "summary.Llama-3.1-405B-Instruct-FP8.json",
    ("Llama-3.3-70B-Instruct", "A"): ROOT / "organized_results" / "gaia" / "cat_A" / "20260401_215021.gaia_cat_A.answer" / "summary.Llama-3.3-70B-Instruct.json",
    ("Llama-3.3-70B-Instruct", "B"): ROOT / "organized_results" / "gaia" / "cat_B" / "20260401_195651.gaia_cat_B.answer" / "summary.Llama-3.3-70B-Instruct-Gaudi3.json",
    ("Llama-3.3-70B-Instruct", "C"): ROOT / "organized_results" / "gaia" / "cat_C" / "20260401_202615.gaia_cat_C.answer" / "summary.Llama-3.3-70B-Instruct-Gaudi3.json",
    ("Llama-3.3-70B-Instruct", "D"): ROOT / "organized_results" / "gaia" / "cat_D" / "20260401_205339.gaia_cat_D.answer" / "summary.Llama-3.3-70B-Instruct-Gaudi3.json",
    ("Llama-4-Maverick-17B-128E-Instruct-FP8", "A"): ROOT / "organized_results" / "gaia" / "cat_A" / "20260402_024258.gaia_cat_A.answer" / "summary.Llama-4-Maverick-17B-128E-Instruct-FP8.json",
    ("Llama-4-Maverick-17B-128E-Instruct-FP8", "B"): ROOT / "organized_results" / "gaia" / "cat_B" / "20260402_010205.gaia_cat_B.answer" / "summary.Llama-4-Maverick-17B-128E-Instruct-FP8.json",
    ("Llama-4-Maverick-17B-128E-Instruct-FP8", "C"): ROOT / "organized_results" / "gaia" / "cat_C" / "20260402_012221.gaia_cat_C.answer" / "summary.Llama-4-Maverick-17B-128E-Instruct-FP8.json",
    ("Llama-4-Maverick-17B-128E-Instruct-FP8", "D"): ROOT / "organized_results" / "gaia" / "cat_D" / "20260402_024040.gaia_cat_D.answer" / "summary.Llama-4-Maverick-17B-128E-Instruct-FP8.json",
}


def _safe_mean(values: List[Optional[float]]) -> Optional[float]:
    valid = [v for v in values if v is not None]
    return mean(valid) if valid else None


def _safe_median(values: List[Optional[float]]) -> Optional[float]:
    valid = [v for v in values if v is not None]
    return median(valid) if valid else None


def _cat_median_std(rows: List[Dict[str, Any]], cat: str, key: str) -> Optional[float]:
    cat_rows = [row for row in rows if row["cat"] == cat and row.get(key) is not None]
    return _safe_median([row[key] for row in cat_rows])


def _parse_model_name(path: Path) -> str:
    stem = path.stem
    model = stem.split("aggregated.", 1)[1] if stem.startswith("aggregated.") else stem
    if model == "Llama-3.3-70B-Instruct-Gaudi3":
        return "Llama-3.3-70B-Instruct"
    return model


def _find_latest_aggregated(cat: str, model: str) -> Optional[Path]:
    cat_dir = THREE_RUN_ROOT / cat
    if not cat_dir.exists():
        return None

    candidate_names = [model]
    if model == "Llama-3.3-70B-Instruct":
        candidate_names = [
            "Llama-3.3-70B-Instruct",
            "Llama-3.3-70B-Instruct-Gaudi3",
        ]

    candidates: List[Path] = []
    for name in candidate_names:
        candidates.extend(cat_dir.glob(f"aggregated_*/aggregated.{name}.json"))
    if not candidates:
        return None
    return sorted(candidates)[-1]


def _load_aggregated(path: Path, cat: str, model: str) -> Dict[str, Any]:
    data = json.load(path.open(encoding="utf-8"))
    rows = [section for key, section in data.items() if key.startswith("gaia/")]

    def weighted_metric(domain: str, metric: str) -> Tuple[Optional[float], Optional[float]]:
        means: List[float] = []
        weights: List[float] = []
        stds: List[float] = []
        std_weights: List[float] = []
        for row in rows:
            metric_info = ((row.get(domain) or {}).get(metric) or {})
            mean_val = metric_info.get("mean")
            std_val = metric_info.get("std")
            num_samples = row.get("num_samples", 0)
            if isinstance(num_samples, dict):
                weight = float(num_samples.get("mean", 0) or 0)
            else:
                weight = float(num_samples or 0)
            if mean_val is not None:
                means.append(float(mean_val))
                weights.append(weight if weight > 0 else 1.0)
            if std_val is not None:
                stds.append(float(std_val))
                std_weights.append(weight if weight > 0 else 1.0)
        if not means:
            return None, None
        total_weight = sum(weights) or float(len(weights))
        weighted_mean = sum(w * m for w, m in zip(weights, means)) / total_weight
        weighted_std = None
        if stds:
            total_std_weight = sum(std_weights) or float(len(std_weights))
            weighted_std = sum(w * s for w, s in zip(std_weights, stds)) / total_std_weight
        return weighted_mean, weighted_std

    plan_mean_components = []
    plan_std_components = []
    tool_mean_components = []
    tool_std_components = []
    flat: Dict[str, Any] = {}

    for metric in PLAN_METRICS:
        m, s = weighted_metric("plan", metric)
        flat[f"plan_{metric}_mean"] = m
        flat[f"plan_{metric}_std"] = s
        plan_mean_components.append(m)
        plan_std_components.append(s)
    for metric in TOOL_METRICS:
        m, s = weighted_metric("tool", metric)
        flat[f"tool_{metric}_mean"] = m
        flat[f"tool_{metric}_std"] = s
        tool_mean_components.append(m)
        tool_std_components.append(s)

    answer_em_mean, answer_em_std = weighted_metric("answer", "exact_match")
    flat["answer_exact_match_mean"] = answer_em_mean
    flat["answer_exact_match_std"] = answer_em_std
    flat["answer_token_f1_mean"], _ = weighted_metric("answer", "token_f1")
    flat["planning_composite_mean"] = _safe_mean(plan_mean_components)
    flat["planning_std_proxy"] = _safe_mean(plan_std_components)
    flat["tool_composite_mean"] = _safe_mean(tool_mean_components)
    flat["tool_std_proxy"] = _safe_mean(tool_std_components)
    flat["answer_std_proxy"] = answer_em_std
    flat["total_count"] = CAT_TOTALS[cat]
    flat["solved_count"] = round((answer_em_mean or 0.0) * CAT_TOTALS[cat])
    flat["cat"] = cat
    flat["model"] = model
    flat["source_type"] = "aggregate"
    flat["source_path"] = str(path)
    # num_runs can differ by subset in partially aggregated folders; report max as visible provenance
    flat["num_runs"] = max(int((row.get("num_runs") or 0)) for row in rows) if rows else 0
    return flat


def _find_cat_a_summary(model: str) -> Optional[Path]:
    preferred = {
        "Llama-3.1-405B-Instruct-FP8": CAT_A_ROOT / "20260325_161023.gaia_cat_A.answer.run1" / "summary.Llama-3.1-405B-Instruct-FP8.json",
        "Llama-3.3-70B-Instruct": CAT_A_ROOT / "20260401_215021.gaia_cat_A.answer" / "summary.Llama-3.3-70B-Instruct.json",
        "Mistral-Small-3.2-24B-Instruct-2506": CAT_A_ROOT / "20260304_181410.gaia_cat_A.answer" / "summary.Mistral-Small-3.2-24B-Instruct-2506.json",
    }
    path = preferred.get(model)
    if path and path.exists():
        return path
    candidates = sorted(CAT_A_ROOT.glob(f"*/summary.{model}.json"))
    return candidates[-1] if candidates else None


def _estimate_proxy_std(model: str, rows: List[Dict[str, Any]], key: str) -> Optional[float]:
    model_rows = [row for row in rows if row["model"] == model and row["source_type"] == "aggregate" and row.get(key) is not None]
    return _safe_median([row[key] for row in model_rows])


def _load_summary_proxy(path: Path, cat: str, model: str, existing_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    overall = json.load(path.open(encoding="utf-8"))["_overall"]

    flat: Dict[str, Any] = {}
    for metric in PLAN_METRICS:
        flat[f"plan_{metric}_mean"] = float(overall["plan"][metric])
        flat[f"plan_{metric}_std"] = None
    for metric in TOOL_METRICS:
        value = overall["tool"][metric]
        flat[f"tool_{metric}_mean"] = None if value is None else float(value)
        flat[f"tool_{metric}_std"] = None

    flat["answer_exact_match_mean"] = float(overall["answer"]["exact_match"])
    flat["answer_token_f1_mean"] = float(overall["answer"]["token_f1"])
    flat["planning_composite_mean"] = _safe_mean([flat[f"plan_{m}_mean"] for m in PLAN_METRICS])
    flat["tool_composite_mean"] = _safe_mean([flat[f"tool_{m}_mean"] for m in TOOL_METRICS])
    flat["planning_std_proxy"] = _estimate_proxy_std(model, existing_rows, "planning_std_proxy")
    flat["tool_std_proxy"] = _estimate_proxy_std(model, existing_rows, "tool_std_proxy")
    flat["answer_exact_match_std"] = None
    flat["answer_std_proxy"] = _estimate_proxy_std(model, existing_rows, "answer_std_proxy")
    flat["total_count"] = CAT_TOTALS[cat]
    flat["solved_count"] = round(flat["answer_exact_match_mean"] * CAT_TOTALS[cat])
    flat["cat"] = cat
    flat["model"] = model
    flat["source_type"] = "proxy_single_run"
    flat["source_path"] = str(path)
    flat["num_runs"] = 1
    return flat


def _load_summary_override(
    path: Path,
    cat: str,
    model: str,
    aggregate_row: Optional[Dict[str, Any]],
    existing_rows: List[Dict[str, Any]],
) -> Dict[str, Any]:
    overall = json.load(path.open(encoding="utf-8"))["_overall"]

    flat: Dict[str, Any] = {}
    for metric in PLAN_METRICS:
        flat[f"plan_{metric}_mean"] = float(overall["plan"][metric])
        flat[f"plan_{metric}_std"] = aggregate_row.get(f"plan_{metric}_std") if aggregate_row else None
    for metric in TOOL_METRICS:
        value = overall["tool"][metric]
        flat[f"tool_{metric}_mean"] = None if value is None else float(value)
        flat[f"tool_{metric}_std"] = aggregate_row.get(f"tool_{metric}_std") if aggregate_row else None

    flat["answer_exact_match_mean"] = float(overall["answer"]["exact_match"])
    flat["answer_exact_match_std"] = aggregate_row.get("answer_exact_match_std") if aggregate_row else None
    flat["answer_token_f1_mean"] = float(overall["answer"]["token_f1"])
    flat["planning_composite_mean"] = _safe_mean([flat[f"plan_{m}_mean"] for m in PLAN_METRICS])
    flat["tool_composite_mean"] = _safe_mean([flat[f"tool_{m}_mean"] for m in TOOL_METRICS])
    flat["planning_std_proxy"] = (
        aggregate_row.get("planning_std_proxy")
        if aggregate_row and aggregate_row.get("planning_std_proxy") is not None
        else _cat_median_std(existing_rows, cat, "planning_std_proxy")
    )
    flat["tool_std_proxy"] = (
        aggregate_row.get("tool_std_proxy")
        if aggregate_row and aggregate_row.get("tool_std_proxy") is not None
        else _cat_median_std(existing_rows, cat, "tool_std_proxy")
    )
    flat["answer_std_proxy"] = (
        aggregate_row.get("answer_std_proxy")
        if aggregate_row and aggregate_row.get("answer_std_proxy") is not None
        else _cat_median_std(existing_rows, cat, "answer_std_proxy")
    )
    flat["total_count"] = CAT_TOTALS[cat]
    flat["solved_count"] = round(flat["answer_exact_match_mean"] * CAT_TOTALS[cat])
    flat["cat"] = cat
    flat["model"] = model
    flat["source_type"] = "summary_override"
    flat["source_path"] = str(path)
    flat["num_runs"] = aggregate_row.get("num_runs", 3) if aggregate_row else 3
    return flat


def collect_rows() -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []

    # Load actual multi-run aggregates first.
    for cat in CAT_ORDER:
        for model in MODEL_ORDER:
            aggregated = _find_latest_aggregated(cat, model)
            if aggregated is None:
                continue
            rows.append(_load_aggregated(aggregated, cat, model))

    aggregate_index = {(row["cat"], row["model"]): row for row in rows}

    # Override selected rows with the latest answer-side summaries while preserving
    # any available multi-run std evidence.
    for (model, cat), path in SUMMARY_OVERRIDE_PATHS.items():
        if not path.exists():
            continue
        rows = [row for row in rows if not (row["cat"] == cat and row["model"] == model)]
        rows.append(_load_summary_override(path, cat, model, aggregate_index.get((cat, model)), rows))

    # Fill Cat A partial rows with single-run proxies when multi-run aggregate is missing.
    for model in MODEL_ORDER:
        if any(row["cat"] == "A" and row["model"] == model for row in rows):
            continue
        summary_path = _find_cat_a_summary(model)
        if summary_path is None:
            continue
        rows.append(_load_summary_proxy(summary_path, "A", model, rows))

    return rows


def write_csv(rows: List[Dict[str, Any]], output_path: Path) -> None:
    if not rows:
        return
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def plot(rows: List[Dict[str, Any]], output_path: Path) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(3, 4, figsize=(20, 12), sharey="row")
    x = np.arange(len(MODEL_ORDER))

    for col, cat in enumerate(CAT_ORDER):
        cat_rows = {row["model"]: row for row in rows if row["cat"] == cat}
        title = CAT_LABELS[cat]

        for row_idx, (metric_key, ylabel) in enumerate([
            ("planning", "Planning Composite"),
            ("tool", "Tool-Aware Composite"),
            ("answer", "Answer Acc (EM)"),
        ]):
            ax = axes[row_idx, col]
            for idx, model in enumerate(MODEL_ORDER):
                row = cat_rows.get(model)
                if row is None:
                    continue
                mean_key = "answer_exact_match_mean" if metric_key == "answer" else f"{metric_key}_composite_mean"
                std_key = "answer_std_proxy" if metric_key == "answer" else f"{metric_key}_std_proxy"
                y = row.get(mean_key)
                yerr = row.get(std_key)
                if y is None:
                    continue

                marker = "o"
                facecolor = MODEL_COLORS[model]
                edgecolor = MODEL_COLORS[model]
                alpha = 0.95
                linestyle = "-"

                if yerr is not None:
                    ax.errorbar(
                        idx,
                        y,
                        yerr=yerr,
                        fmt=marker,
                        color=edgecolor,
                        markerfacecolor=facecolor,
                        markeredgecolor=edgecolor,
                        elinewidth=1.6,
                        capsize=3,
                        markersize=8,
                        linestyle=linestyle,
                        alpha=alpha,
                    )
                else:
                    ax.scatter(
                        idx,
                        y,
                        s=70,
                        marker=marker,
                        facecolors=facecolor,
                        edgecolors=edgecolor,
                        linewidths=1.7,
                        alpha=alpha,
                    )

                if metric_key == "answer":
                    solved = row.get("solved_count")
                    total = row.get("total_count")
                    if solved is not None and total is not None:
                        ax.annotate(
                            f"{int(solved)}/{int(total)}",
                            (idx, y),
                            textcoords="offset points",
                            xytext=(0, 8),
                            ha="center",
                            fontsize=7,
                            color=edgecolor,
                        )

            ax.set_title(title if row_idx == 0 else "")
            ax.set_xticks(x)
            ax.set_xticklabels([MODEL_LABELS[m] for m in MODEL_ORDER], rotation=28, ha="right")
            ax.set_ylim(0, 1.02)
            ax.grid(axis="y", alpha=0.25)
            if col == 0:
                ax.set_ylabel(ylabel)

    fig.suptitle(
        "GAIA Stability Overview: Planning, Tool-Aware, and Answer Accuracy\n"
        "Error bars = std / std-proxy from available multi-run evidence; answer row annotations = solved / total",
        fontsize=15,
        fontweight="bold",
    )
    fig.text(0.24, 0.02, "Text-Centric Tasks", ha="center", fontsize=11, fontweight="bold")
    fig.text(0.74, 0.02, "Multimodal Perception Tasks", ha="center", fontsize=11, fontweight="bold")
    fig.tight_layout(rect=[0, 0.05, 1, 0.94])
    fig.savefig(output_path, dpi=200, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    rows = collect_rows()
    rows.sort(key=lambda row: (CAT_ORDER.index(row["cat"]), MODEL_ORDER.index(row["model"])))
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = OUTPUT_DIR / "gaia_stability_overview.csv"
    fig_path = OUTPUT_DIR / "gaia_planning_tool_stability.png"
    write_csv(rows, csv_path)
    plot(rows, fig_path)
    print(f"Saved CSV: {csv_path}")
    print(f"Saved figure: {fig_path}")


if __name__ == "__main__":
    main()
