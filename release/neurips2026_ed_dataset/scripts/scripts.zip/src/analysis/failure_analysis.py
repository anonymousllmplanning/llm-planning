#!/usr/bin/env python3
"""
Failure Analysis Framework
==========================

Implements a Funnel Attribution Analysis to categorize failure causes into:
1. Planning Failure: (Node F1 < 1.0)
2. Alignment Failure: (Plan Correct but Tool/Args Mismatch)
3. Execution Failure: (Tool Error/Timeout)
4. Reasoning Failure: (All layers OK but Final Answer Wrong)

Usage:
    python -m src.analysis.failure_analysis --input_file path/to/unified.jsonl
"""

import json
import os
import argparse
from pathlib import Path
from typing import Dict, Any, List, Optional
from collections import defaultdict
import glob

# Reuse existing evaluation logic to ensure consistency
from src.evaluation.metrics import ASTEvaluationSystem, _normalize_string

class FailureAnalyzer:
    def __init__(self):
        self.evaluator = ASTEvaluationSystem(use_embeddings=False) # Speed up, no need for embeddings for this analysis
        self.stats = defaultdict(int)
        self.details = []

    def load_execution_trace(self, output_dir: str, sample_id: str) -> List[Dict[str, Any]]:
        """Load execution trace from separate JSON file."""
        trace_pattern = os.path.join(output_dir, f"execution_trace_{sample_id}.json")
        matches = glob.glob(trace_pattern)
        if matches:
            try:
                with open(matches[0], "r") as f:
                    return json.load(f)
            except Exception as e:
                print(f"[WARN] Failed to load trace {matches[0]}: {e}")
        return []

    def evaluate_planning_layer(self, gold_plan: Dict[str, Any], pred_plan: Dict[str, Any]) -> bool:
        """
        Check if the predicted plan structure matches the gold plan.
        Returns True if Plan is considered "Correct" (Node F1 == 1.0).
        """
        # If gold has no tool calls/steps, we can't evaluate planning meaningfully
        # But for GAIA, nearly all have steps.
        # Use existing metric logic
        scores = self.evaluator.evaluate_plan_dag(gold_plan, pred_plan)
        # Use configurable threshold
        threshold = getattr(self, 'plan_threshold', 0.99)
        return scores.node_f1 >= threshold

    def evaluate_alignment_layer(self, pred_plan: Dict[str, Any], execution_trace: List[Dict[str, Any]]) -> Dict[str, bool]:
        """
        Check if Actual Execution matches the Plan.
        Returns {
            "name_match": bool,
            "args_match": bool,
            "hallucination": bool
        }
        """
        if not execution_trace:
             return {"name_match": False, "args_match": False, "hallucination": False, "reason": "No Trace"}

        # Extract planned tools (linear sequence from nodes)
        planned_tools = []
        if pred_plan and "nodes" in pred_plan:
            # Sort by step index if available
            nodes = sorted(pred_plan["nodes"], key=lambda x: x.get("step_index", 0))
            for n in nodes:
                t = n.get("tool_id")
                if t: planned_tools.append(t)

        # Extract executed tools
        executed_tools = [t.get("tool_id") for t in execution_trace]

        # 1. Alignment: Did we execute what we planned? (Set overlap or Sequence match?)
        # For simplicity in this analysis, we check if the *Set* of executed tools covers the Planned tools
        # But a better "Alignment" check is: For the tools that ARE in both, do args match?

        # Let's look for "Hallucination": Calling a tool not in the allowed list?
        # Or "Function Name Error": The plan said "GetImage" but code called "DownloadImage"

        # Simplification:
        # Alignment Failure if:
        # 1. Executed tool count != Planned tool count (roughly)
        # 2. Executed tool list has items NOT in Plan (Deviation)

        # Refined Alignment Metric for Slides:
        # "Plan said X, Robot did Y"

        planned_set = set(planned_tools)
        executed_set = set(executed_tools)

        # If execution is completely empty but plan wasn't -> Alignment completely failed
        if planned_set and not executed_set:
            return {"name_match": False, "args_match": False, "hallucination": False, "reason": "No Execution"}

        # Name Mismatch: Executed something not in plan (or missed something)
        # We allow *extra* steps (like scroll/read), but we shouldn't miss critical plan steps.
        # Actually, if Plan F1 is high, it means Plan ~= Gold.
        # So we really care if Execution ~= Plan.

        intersection = planned_set.intersection(executed_set)
        name_match = (len(intersection) / len(planned_set)) >= 0.8 if planned_set else True

        # Argument Mismatch:
        # Harder to check without a "Gold Execution Trace".
        # But we can check if the model "corrected" itself (Refinement).
        # In the runner log, we see "Asking model to refine...".
        # If trace shows multiple attempts for same tool -> Arg Error.

        arg_error = False
        for step in execution_trace:
            # Heuristic: If output says "Error" or "Invalid argument", it's likely an arg error
            output = str(step.get("output", ""))
            if "[ERROR]" in output or "argument" in output.lower():
                 # Differentiate Arg error vs Runtime error
                 # "TypeError", "ValueError" -> Arg Error
                 if "TypeError" in output or "ValueError" in output or "Missing" in output:
                     arg_error = True

        return {
            "name_match": name_match,
            "args_match": not arg_error,
            "hallucination": False # TODO: check against valid tool list
        }

    def evaluate_execution_layer(self, execution_trace: List[Dict[str, Any]]) -> Dict[str, bool]:
        """
        Check for Runtime failures.
        """
        has_error = False
        has_timeout = False

        for step in execution_trace:
            output = str(step.get("output", ""))
            if "Timeout" in output or "timed out" in output:
                has_timeout = True
            elif "[ERROR]" in output or "Exception" in output:
                # Exclude simple arg errors if possible, but generally detailed exceptions are execution failures
                # unless caught by Alignment Layer
                if "404" in output or "Network" in output or "Connection" in output:
                     has_error = True
                elif "KeyError" in output or "IndexError" in output: # Internal logic/runtime error
                     has_error = True

        return {
            "has_error": has_error,
            "has_timeout": has_timeout
        }

    def run(self, input_file: str):
        print(f"Analyzing {input_file}...")

        input_path = Path(input_file)
        if not input_path.exists():
            print(f"File not found: {input_file}")
            return

        with input_path.open("r") as f:
            lines = f.readlines()

        total_samples = 0
        total_failures = 0

        # Layers
        plan_failures = 0
        alignment_failures = 0
        execution_failures = 0
        reasoning_failures = 0 # Final answer wrong but everything else OK

        output_dir = input_path.parent

        for line in lines:
            if not line.strip(): continue
            try:
                rec = json.loads(line)
            except: continue

            total_samples += 1

            # 1. Determine Success/Fail (Exact Match)
            # Simplified Pass/Fail check
            gold = rec.get("gold", {})
            gold_ans = _normalize_string(gold.get("final_answer", {}).get("answer", ""))

            pred = rec.get("pred", {})
            pred_ans_obj = pred.get("final_answer", {})
            if isinstance(pred_ans_obj, dict):
                 pred_ans = _normalize_string(pred_ans_obj.get("answer", ""))
            else:
                 pred_ans = _normalize_string(str(pred_ans_obj))

            # Loose contains check for failure analysis scope
            is_correct = (gold_ans in pred_ans) if gold_ans else False

            sample_id = rec.get("task_id") or rec.get("id") or rec.get("meta", {}).get("id")

            # --- Plan Evaluation (For both Success and Fail) ---
            gold_tool_calls = gold.get("tool_calls", [])
            gold_plan_dag = {
                "nodes": [
                    {"step_index": i, "tool_id": c.get("tool_id"), "label": c.get("tool_id")}
                    for i, c in enumerate(gold_tool_calls)
                ],
                "edges": []
            }
            pred_plan_dag = pred.get("plan_dag", {})

            # Calculate raw score
            scores = self.evaluator.evaluate_plan_dag(gold_plan_dag, pred_plan_dag)
            node_f1 = scores.node_f1

            if is_correct:
                self.stats["success_count"] += 1
                self.stats["success_f1_sum"] += node_f1
                self.details.append({"id": sample_id, "type": "Success", "f1": node_f1})
                continue

            # --- Failure Analysis (Only for failures) ---
            total_failures += 1
            self.stats["failure_f1_sum"] += node_f1

            # Check Planning Failure with current threshold
            threshold = getattr(self, 'plan_threshold', 0.99)
            plan_ok = node_f1 >= threshold

            if not plan_ok:
                plan_failures += 1
                self.details.append({"id": sample_id, "type": "Planning", "reason": f"Node F1 {node_f1:.2f} < {threshold}"})
                continue

            # 2. Alignment Layer (Plan was OK)
            trace = self.load_execution_trace(str(output_dir), str(sample_id))
            alignment_res = self.evaluate_alignment_layer(pred_plan_dag, trace)

            if not alignment_res["name_match"] or not alignment_res["args_match"]:
                alignment_failures += 1
                reason = "Name Mismatch" if not alignment_res["name_match"] else "Args Mismatch"
                self.details.append({"id": sample_id, "type": "Alignment", "reason": reason})
                continue

            # 3. Execution Layer (Alignment was OK)
            exec_res = self.evaluate_execution_layer(trace)
            if exec_res["has_error"] or exec_res["has_timeout"]:
                execution_failures += 1
                reason = "Timeout" if exec_res["has_timeout"] else "Runtime Error"
                self.details.append({"id": sample_id, "type": "Execution", "reason": reason})
                continue

            # 4. Reasoning Layer (Everything executed fine, but answer is wrong)
            reasoning_failures += 1
            self.details.append({"id": sample_id, "type": "Reasoning", "reason": "Logic/Inference Error"})

        # Report Generation
        print("\n" + "="*50)
        print("FAILURE ANALYSIS REPORT (Control Group View)")
        print("="*50)
        print(f"Total Samples: {total_samples}")

        success_count = self.stats["success_count"]
        success_f1_avg = self.stats["success_f1_sum"] / success_count if success_count else 0.0

        fail_count = total_failures
        fail_f1_avg = self.stats["failure_f1_sum"] / fail_count if fail_count else 0.0

        print(f"\n[Hypothesis Check]")
        print(f"Success Cases ({success_count}): Avg Plan Node F1 = {success_f1_avg:.3f}")
        print(f"Failure Cases ({fail_count}): Avg Plan Node F1 = {fail_f1_avg:.3f}")

        print("\n[Funnel Analysis (Threshold: {:.2f})]".format(getattr(self, 'plan_threshold', 0.99)))
        print(f"Total Failures: {total_failures} ({(total_failures/total_samples)*100:.1f}%)")
        print("-" * 30)

        if total_failures > 0:
            print(f"1. Planning Failures:   {plan_failures} ({plan_failures/total_failures*100:.1f}%)")
            print(f"   -> 'The plan was wrong from the start.'")
            print("-" * 30)
            print(f"2. Alignment Failures:  {alignment_failures} ({alignment_failures/total_failures*100:.1f}%)")
            print(f"   -> 'Plan OK, but used wrong tools/args.' (The Gap)")
            print("-" * 30)
            print(f"3. Execution Failures:  {execution_failures} ({execution_failures/total_failures*100:.1f}%)")
            print(f"   -> 'Tool crashed or timed out.'")
            print("-" * 30)
            print(f"4. Reasoning Failures:  {reasoning_failures} ({reasoning_failures/total_failures*100:.1f}%)")
            print(f"   -> 'Everything worked, but the final answer is wrong.'")
        else:
            print("No failures found to analyze.")

        print("="*50)

        # Save details
        out_file = input_path.parent / "failure_analysis_report.json"
        with open(out_file, "w") as f:
            json.dump({
                "summary": {
                    "total": total_samples,
                    "failures": total_failures,
                    "planning": plan_failures,
                    "alignment": alignment_failures,
                    "execution": execution_failures,
                    "reasoning": reasoning_failures
                },
                "cases": self.details
            }, f, indent=2)
        print(f"Detailed report saved to {out_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_file", type=str, required=True, help="Path to unified.jsonl")
    parser.add_argument("--plan_threshold", type=float, default=0.6, help="Node F1 threshold for Planning Success (default: 0.6)")
    args = parser.parse_args()

    analyzer = FailureAnalyzer()
    # Pass threshold but we need to modify init or run to accept it.
    # Actually, let's just modify the run method to accept it or set it on the instance.
    analyzer.plan_threshold = args.plan_threshold
    analyzer.run(args.input_file)
