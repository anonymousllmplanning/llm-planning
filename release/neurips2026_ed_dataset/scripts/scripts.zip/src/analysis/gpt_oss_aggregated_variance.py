#!/usr/bin/env python3
"""
Targeted variance visualization for GAIA aggregated multi-run results.

Focus:
- gpt-oss-20b
- gpt-oss-120b
- cat_A / cat_B / cat_C / cat_D

Outputs:
1. Level-wise metric CSV
2. Cat-level weighted summary CSV
3. Mean±std comparison figure
4. Level-wise std heatmap
5. Cat-level variance heatmap
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


METRIC_SPECS: List[Tuple[str, str, str]] = [
    ("plan", "node_f1", "Node F1"),
    ("plan", "edge_f1", "Edge F1"),
    ("plan", "node_label_similarity", "Node Label Sim"),
    ("plan", "ssi", "SSI"),
    ("tool", "tool_name_f1", "Tool F1"),
    ("tool", "param_name_f1", "Param F1"),
    ("tool", "type_aware_value_f1", "Value F1"),
    ("answer", "exact_match", "Exact Match"),
    ("answer", "token_f1", "Token F1"),
]

MODEL_ORDER = ["gpt-oss-20b", "gpt-oss-120b"]
CAT_ORDER = ["cat_A", "cat_B", "cat_C", "cat_D"]
CAT_LABELS = {
    "cat_A": "Text only",
    "cat_B": "Documents analysis",
    "cat_C": "Vision",
    "cat_D": "Audio",
}
TASK_GROUPS = [
    ("Text-Centric Tasks", ["cat_A", "cat_B"]),
    ("Multimodal Perception Tasks", ["cat_C", "cat_D"]),
]
LEVEL_ORDER = {"level_1": 1, "level_2": 2, "level_3": 3}
MODEL_COLORS = {"gpt-oss-20b": "#4E79A7", "gpt-oss-120b": "#E15759"}


def parse_model_name(path: Path) -> str:
    stem = path.stem
    if stem.startswith("aggregated."):
        return stem.split("aggregated.", 1)[1]
    return stem


def parse_cat_name(path: Path) -> str:
    for part in path.parts:
        if part in CAT_ORDER:
            return part
    raise ValueError(f"Could not infer cat name from path: {path}")


def parse_level_name(section_key: str) -> str:
    _, level = section_key.split("/", 1)
    return level


def write_csv(rows: List[Dict[str, Any]], output_path: Path) -> None:
    if not rows:
        return
    with output_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def collect_rows(paths: List[Path]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    level_rows: List[Dict[str, Any]] = []
    grouped: Dict[Tuple[str, str, str], List[Dict[str, Any]]] = defaultdict(list)

    for path in paths:
        data = json.load(path.open(encoding="utf-8"))
        cat = parse_cat_name(path)
        model = parse_model_name(path)

        for section_key, section in data.items():
            level = parse_level_name(section_key)
            sample_weight = float(section.get("num_samples", {}).get("mean", 0.0) or 0.0)
            num_runs = int(section.get("num_runs", 0) or 0)
            parse_error_rate = section.get("parse_error_rate", {})

            for domain, metric_key, metric_label in METRIC_SPECS:
                metric_info = ((section.get(domain) or {}).get(metric_key) or {})
                mean = metric_info.get("mean")
                std = metric_info.get("std")
                stderr = metric_info.get("stderr")
                row = {
                    "cat": cat,
                    "level": level,
                    "model": model,
                    "metric_domain": domain,
                    "metric_key": metric_key,
                    "metric_label": metric_label,
                    "mean": mean,
                    "std": std,
                    "variance": (std ** 2) if std is not None else None,
                    "stderr": stderr,
                    "sample_weight": sample_weight,
                    "num_runs": num_runs,
                    "parse_error_rate_mean": parse_error_rate.get("mean"),
                    "parse_error_rate_std": parse_error_rate.get("std"),
                    "source_file": str(path),
                }
                level_rows.append(row)
                grouped[(cat, model, metric_key)].append(row)

    cat_rows: List[Dict[str, Any]] = []
    for (cat, model, metric_key), rows in grouped.items():
        valid_rows = [row for row in rows if row["mean"] is not None]
        if not valid_rows:
            continue
        total_weight = sum((row["sample_weight"] or 0.0) for row in valid_rows)
        if total_weight <= 0:
            total_weight = float(len(valid_rows))
            weights = [1.0] * len(valid_rows)
        else:
            weights = [row["sample_weight"] or 0.0 for row in valid_rows]

        weighted_mean = sum(w * float(row["mean"]) for w, row in zip(weights, valid_rows)) / total_weight

        valid_std_rows = [row for row in valid_rows if row["std"] is not None]
        if valid_std_rows:
            std_weights = [row["sample_weight"] or 0.0 for row in valid_std_rows]
            std_total_weight = sum(std_weights) or float(len(valid_std_rows))
            if sum(std_weights) == 0:
                std_weights = [1.0] * len(valid_std_rows)
            weighted_std_proxy = sum(w * float(row["std"]) for w, row in zip(std_weights, valid_std_rows)) / std_total_weight
            weighted_variance_proxy = sum(w * float(row["std"]) ** 2 for w, row in zip(std_weights, valid_std_rows)) / std_total_weight
        else:
            weighted_std_proxy = None
            weighted_variance_proxy = None

        metric_label = next(row["metric_label"] for row in valid_rows)
        cat_rows.append({
            "cat": cat,
            "model": model,
            "metric_key": metric_key,
            "metric_label": metric_label,
            "weighted_mean": weighted_mean,
            "weighted_std_proxy": weighted_std_proxy,
            "weighted_variance_proxy": weighted_variance_proxy,
            "levels_covered": len(valid_rows),
            "total_weight": total_weight,
        })

    return level_rows, cat_rows


def metric_lookup(rows: List[Dict[str, Any]], value_key: str) -> Dict[Tuple[str, str, str], float]:
    result = {}
    for row in rows:
        value = row.get(value_key)
        if value is None:
            continue
        result[(row["cat"], row["model"], row["metric_key"])] = float(value)
    return result


GROUP_SEPARATOR_X = CAT_ORDER.index("cat_C") - 0.5


def plot_cat_mean_std(cat_rows: List[Dict[str, Any]], output_path: Path) -> None:
    mean_lookup = metric_lookup(cat_rows, "weighted_mean")
    std_lookup = metric_lookup(cat_rows, "weighted_std_proxy")

    fig, axes = plt.subplots(3, 3, figsize=(18, 13), sharey=True)
    axes = axes.flatten()
    x = np.arange(len(CAT_ORDER))
    width = 0.36

    for idx, (_, metric_key, metric_label) in enumerate(METRIC_SPECS):
        ax = axes[idx]
        for model_idx, model in enumerate(MODEL_ORDER):
            means = [mean_lookup.get((cat, model, metric_key), 0.0) for cat in CAT_ORDER]
            stds = [std_lookup.get((cat, model, metric_key), 0.0) for cat in CAT_ORDER]
            xpos = x + (model_idx - 0.5) * width
            ax.bar(
                xpos,
                means,
                width=width,
                yerr=stds,
                capsize=3,
                color=MODEL_COLORS[model],
                alpha=0.85,
                edgecolor="black",
                linewidth=0.6,
                label=model if idx == 0 else None,
            )
        ax.set_title(metric_label)
        ax.set_xticks(x)
        ax.set_xticklabels([CAT_LABELS[cat] for cat in CAT_ORDER], rotation=0)
        ax.set_ylim(0, 1.05)
        ax.grid(axis="y", alpha=0.25)
        ax.axvline(GROUP_SEPARATOR_X, color="gray", linestyle="--", linewidth=0.8, alpha=0.5)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=2, frameon=False)
    fig.suptitle("GPT-OSS on GAIA: Cat-Level Weighted Mean ± Std Proxy", fontsize=16, fontweight="bold")
    fig.text(0.27, 0.018, "Text-Centric Tasks", ha="center", va="center", fontsize=11, fontweight="bold")
    fig.text(0.74, 0.018, "Multimodal Perception Tasks", ha="center", va="center", fontsize=11, fontweight="bold")
    fig.tight_layout(rect=[0, 0.035, 1, 0.95])
    fig.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_level_std_heatmap(level_rows: List[Dict[str, Any]], output_path: Path) -> None:
    metric_keys = [metric_key for _, metric_key, _ in METRIC_SPECS]
    metric_labels = [metric_label for _, _, metric_label in METRIC_SPECS]

    ordered_levels = []
    for cat in CAT_ORDER:
        cat_levels = sorted(
            {row["level"] for row in level_rows if row["cat"] == cat},
            key=lambda level: LEVEL_ORDER.get(level.split("_", 2)[0] + "_" + level.split("_", 2)[1], 99)
        )
        for level in cat_levels:
            ordered_levels.append((cat, level))

    fig, axes = plt.subplots(1, 2, figsize=(16, max(6, len(ordered_levels) * 0.45)), sharey=True)
    if len(MODEL_ORDER) == 1:
        axes = [axes]

    for ax, model in zip(axes, MODEL_ORDER):
        matrix = np.full((len(ordered_levels), len(metric_keys)), np.nan)
        for i, (cat, level) in enumerate(ordered_levels):
            for j, metric_key in enumerate(metric_keys):
                values = [
                    row["std"] for row in level_rows
                    if row["cat"] == cat and row["level"] == level and row["model"] == model and row["metric_key"] == metric_key
                ]
                if values and values[0] is not None:
                    matrix[i, j] = values[0]

        im = ax.imshow(matrix, aspect="auto", cmap="YlOrRd", vmin=0, vmax=np.nanmax(matrix) if not np.isnan(matrix).all() else 1)
        ax.set_title(f"{model} level-wise std")
        ax.set_xticks(np.arange(len(metric_labels)))
        ax.set_xticklabels(metric_labels, rotation=45, ha="right")
        ax.set_yticks(np.arange(len(ordered_levels)))
        ax.set_yticklabels([f"{CAT_LABELS[cat]} {level.split('_')[1]}" for cat, level in ordered_levels])
        group_boundaries = []
        seen_cats = []
        for cat, _ in ordered_levels:
            if not seen_cats or seen_cats[-1] != cat:
                seen_cats.append(cat)
        running_index = 0
        cat_to_start_end = {}
        for cat in seen_cats:
            count = sum(1 for row_cat, _ in ordered_levels if row_cat == cat)
            cat_to_start_end[cat] = (running_index, running_index + count - 1)
            running_index += count
        for _, cats in TASK_GROUPS:
            last_cat = cats[-1]
            if last_cat in cat_to_start_end and last_cat != CAT_ORDER[-1]:
                group_boundaries.append(cat_to_start_end[last_cat][1] + 0.5)
        for boundary in group_boundaries:
            ax.axhline(boundary, color="gray", linestyle="--", linewidth=0.8, alpha=0.6)

        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                if not math.isnan(matrix[i, j]):
                    ax.text(j, i, f"{matrix[i, j]:.02f}", ha="center", va="center", fontsize=7)

        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    if ordered_levels:
        spans = {}
        for group_name, cats in TASK_GROUPS:
            indices = [i for i, (cat, _) in enumerate(ordered_levels) if cat in cats]
            if indices:
                spans[group_name] = (min(indices), max(indices))
        left_ax = axes[0]
        total_rows = len(ordered_levels)
        for group_name, (start_idx, end_idx) in spans.items():
            center_frac = 1 - (((start_idx + end_idx) / 2.0) + 0.5) / total_rows
            left_ax.text(
                -0.33,
                center_frac,
                group_name,
                transform=left_ax.transAxes,
                rotation=0,
                va="center",
                ha="right",
                fontsize=10,
                fontweight="bold",
                clip_on=False,
            )

    fig.suptitle("GPT-OSS on GAIA: Level-Wise Std Heatmap", fontsize=16, fontweight="bold")
    fig.tight_layout(rect=[0.12, 0, 1, 0.95])
    fig.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_cat_variance_heatmap(cat_rows: List[Dict[str, Any]], output_path: Path) -> None:
    metric_keys = [metric_key for _, metric_key, _ in METRIC_SPECS]
    metric_labels = [metric_label for _, _, metric_label in METRIC_SPECS]

    fig, axes = plt.subplots(1, 2, figsize=(16, 6), sharey=True)
    if len(MODEL_ORDER) == 1:
        axes = [axes]

    for ax, model in zip(axes, MODEL_ORDER):
        matrix = np.full((len(CAT_ORDER), len(metric_keys)), np.nan)
        for i, cat in enumerate(CAT_ORDER):
            for j, metric_key in enumerate(metric_keys):
                values = [
                    row["weighted_variance_proxy"] for row in cat_rows
                    if row["cat"] == cat and row["model"] == model and row["metric_key"] == metric_key
                ]
                if values and values[0] is not None:
                    matrix[i, j] = values[0]

        im = ax.imshow(matrix, aspect="auto", cmap="Blues", vmin=0, vmax=np.nanmax(matrix) if not np.isnan(matrix).all() else 1)
        ax.set_title(f"{model} cat-level variance proxy")
        ax.set_xticks(np.arange(len(metric_labels)))
        ax.set_xticklabels(metric_labels, rotation=45, ha="right")
        ax.set_yticks(np.arange(len(CAT_ORDER)))
        ax.set_yticklabels([CAT_LABELS[cat] for cat in CAT_ORDER])
        ax.axhline(GROUP_SEPARATOR_X, color="gray", linestyle="--", linewidth=0.8, alpha=0.6)

        for i in range(matrix.shape[0]):
            for j in range(matrix.shape[1]):
                if not math.isnan(matrix[i, j]):
                    ax.text(j, i, f"{matrix[i, j]:.03f}", ha="center", va="center", fontsize=7)

        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    left_ax = axes[0]
    left_ax.text(
        -0.23,
        0.75,
        "Text-Centric Tasks",
        transform=left_ax.transAxes,
        rotation=0,
        va="center",
        ha="right",
        fontsize=10,
        fontweight="bold",
        clip_on=False,
    )
    left_ax.text(
        -0.23,
        0.25,
        "Multimodal Perception Tasks",
        transform=left_ax.transAxes,
        rotation=0,
        va="center",
        ha="right",
        fontsize=10,
        fontweight="bold",
        clip_on=False,
    )

    fig.suptitle("GPT-OSS on GAIA: Cat-Level Variance Proxy Heatmap", fontsize=16, fontweight="bold")
    fig.tight_layout(rect=[0.10, 0, 1, 0.95])
    fig.savefig(output_path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser(description="Visualize std/variance for gpt-oss aggregated GAIA results.")
    parser.add_argument(
        "--aggregated",
        type=Path,
        action="append",
        required=True,
        help="Path to aggregated.<model>.json (repeatable).",
    )
    parser.add_argument(
        "--output_dir",
        type=Path,
        required=True,
        help="Directory to save CSV summaries and figures.",
    )
    args = parser.parse_args()

    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    level_rows, cat_rows = collect_rows(args.aggregated)

    level_csv = output_dir / "gpt_oss_level_metrics.csv"
    cat_csv = output_dir / "gpt_oss_cat_weighted_summary.csv"
    write_csv(level_rows, level_csv)
    write_csv(cat_rows, cat_csv)

    plot_cat_mean_std(cat_rows, output_dir / "gpt_oss_cat_weighted_mean_std.png")
    plot_level_std_heatmap(level_rows, output_dir / "gpt_oss_level_std_heatmap.png")
    plot_cat_variance_heatmap(cat_rows, output_dir / "gpt_oss_cat_variance_heatmap.png")

    print(f"[INFO] Saved: {level_csv}")
    print(f"[INFO] Saved: {cat_csv}")
    print(f"[INFO] Saved: {output_dir / 'gpt_oss_cat_weighted_mean_std.png'}")
    print(f"[INFO] Saved: {output_dir / 'gpt_oss_level_std_heatmap.png'}")
    print(f"[INFO] Saved: {output_dir / 'gpt_oss_cat_variance_heatmap.png'}")


if __name__ == "__main__":
    main()
