#!/usr/bin/env python3
"""
Tool-layer execution-based filter for GAIA async orderings.

Validation protocol:
1. Align chain/async records by sample_id.
2. Replay chain GT tool_calls using tools.execute_tool (3 retries).
3. Replay each async ordering by reordering tool_calls from sampled_orderings
   (fallback to possible_orderings) and execute with retries.
4. Binary decision:
   - VALID: chain is stably executable AND ordering is executable.
   - INVALID: all other cases (filtered out).

Outputs:
- rows.csv / rows.jsonl with per-ordering decisions
- chain_baseline.jsonl with chain replay diagnostics
- summary.json
- filtered async files per category in output_dir/filtered_async
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import sys
import signal
from collections import Counter, defaultdict
from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Ensure project root is importable when running as a script.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.inference.gaia_utils import resolve_attachment_path
from src.inference.tools import execute_tool, normalize_submitted_answer


CATEGORY_DIRS = {
    "A": "cat_A_text",
    "B": "cat_B_document",
    "C": "cat_C_vision",
    "D": "cat_D_audio",
}

ORDER_DEP_MARKERS = (
    "<n",
    "variable",
    "not found in store",
    "no such file or directory",
    "file not found",
    "does not exist",
    "cannot find",
    "missing file",
    "missing argument",
    "keyerror",
    "indexerror",
    "nameerror",
)

NOISE_MARKERS = (
    "timeout",
    "timed out",
    "403",
    "404",
    "forbidden",
    "connection",
    "network",
    "ssl",
    "temporarily unavailable",
    "rate limit",
    "ddgs",
    "duckduckgo",
    "failed to download",
    "api unavailable",
)


@dataclass
class AttemptResult:
    passed: bool
    failure_bucket: Optional[str]
    failed_tool_id: Optional[str]
    failed_output: str
    successful_calls: int
    total_calls: int
    answer_match: Optional[bool]


def load_json(path: Path) -> List[Dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    return [data]


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(text: Any) -> str:
    text = "" if text is None else str(text)
    text = text.strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text


def extract_answer_string(answer_obj: Any) -> str:
    if isinstance(answer_obj, dict):
        for key in ("answer", "final_answer", "response", "output", "result"):
            if key in answer_obj:
                return extract_answer_string(answer_obj.get(key))
        try:
            return json.dumps(answer_obj, ensure_ascii=False)
        except Exception:
            return str(answer_obj)
    if isinstance(answer_obj, list):
        try:
            return json.dumps(answer_obj, ensure_ascii=False)
        except Exception:
            return str(answer_obj)
    if answer_obj is None:
        return ""
    return str(answer_obj)


def is_success_output(output: Any) -> bool:
    text = str(output or "")
    if "Output:\n" in text:
        text = text.split("Output:\n", 1)[1]
    norm = text.strip().lower()
    return not (
        norm.startswith("[error]")
        or norm.startswith("error:")
        or norm.startswith("execution failed:")
    )


def classify_failure_bucket(output: Any) -> str:
    norm = normalize_text(output)
    if any(marker in norm for marker in ORDER_DEP_MARKERS):
        return "order_dependency"
    if any(marker in norm for marker in NOISE_MARKERS):
        return "environment_noise"
    return "other_failure"


def resolve_variables(value: Any, var_store: Dict[str, str]) -> Any:
    if isinstance(value, str):
        pattern = r"<n\d+>"
        matches = re.findall(pattern, value)
        if not matches:
            return value
        if len(matches) == 1 and value.strip() == matches[0]:
            return var_store.get(matches[0], value)
        result = value
        for var_name in matches:
            if var_name in var_store:
                result = result.replace(var_name, str(var_store[var_name]))
        return result
    if isinstance(value, dict):
        return {k: resolve_variables(v, var_store) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_variables(item, var_store) for item in value]
    return value


def execute_tool_with_timeout(
    tool_id: str,
    resolved_args: Dict[str, Any],
    attachments_dir: str,
    output_dir: str,
    timeout_sec: int,
) -> str:
    if timeout_sec <= 0:
        return execute_tool(
            tool_id,
            resolved_args,
            attachments_dir=attachments_dir,
            output_dir=output_dir,
        )

    def _handle_timeout(_signum, _frame):
        raise TimeoutError(f"tool call timed out after {timeout_sec}s")

    old_handler = signal.getsignal(signal.SIGALRM)
    signal.signal(signal.SIGALRM, _handle_timeout)
    signal.setitimer(signal.ITIMER_REAL, float(timeout_sec))
    try:
        return execute_tool(
            tool_id,
            resolved_args,
            attachments_dir=attachments_dir,
            output_dir=output_dir,
        )
    except TimeoutError as exc:
        return f"[ERROR] {exc}"
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.0)
        signal.signal(signal.SIGALRM, old_handler)


def args_to_dict(arguments: Any) -> Dict[str, Any]:
    if isinstance(arguments, dict):
        return dict(arguments)
    if isinstance(arguments, list):
        out: Dict[str, Any] = {}
        for item in arguments:
            if not isinstance(item, dict):
                continue
            name = item.get("name")
            if not name:
                continue
            out[str(name)] = item.get("value")
        return out
    return {}


def infer_attachments_dir(record: Dict[str, Any]) -> str:
    attachments = ((record.get("query") or {}).get("attachments") or [])
    if not attachments:
        return ""
    first = attachments[0]
    resolved = resolve_attachment_path(
        first.get("file_path"),
        first.get("file_name"),
        record=record,
    )
    if not resolved:
        return ""
    return str(Path(resolved).parent)


def build_node_maps(record: Dict[str, Any]) -> Tuple[Dict[str, int], Dict[str, List[str]]]:
    node_to_step: Dict[str, int] = {}
    node_to_output_vars: Dict[str, List[str]] = {}
    nodes = (((record.get("gold") or {}).get("plan_dag") or {}).get("nodes") or [])
    for node in nodes:
        node_id = str(node.get("node_id", "")).strip()
        if not node_id:
            continue
        raw_step = node.get("step_index")
        if isinstance(raw_step, int):
            node_to_step[node_id] = raw_step
        elif isinstance(raw_step, str) and raw_step.isdigit():
            node_to_step[node_id] = int(raw_step)
        vars_list = node.get("output_vars") or []
        if isinstance(vars_list, list):
            node_to_output_vars[node_id] = [str(v) for v in vars_list if isinstance(v, str) and v]
    return node_to_step, node_to_output_vars


def parse_node_step_index(node_id: str) -> Optional[int]:
    m = re.fullmatch(r"n(\d+)", node_id.strip())
    if not m:
        return None
    return int(m.group(1))


def get_orderings(async_rec: Dict[str, Any]) -> Tuple[List[List[int]], str]:
    sampled = async_rec.get("sampled_orderings")
    if isinstance(sampled, list) and sampled:
        return sampled, "sampled_orderings"
    possible = async_rec.get("possible_orderings")
    if isinstance(possible, list) and possible:
        return possible, "possible_orderings"
    n = len(async_rec.get("executable_steps") or [])
    return [list(range(n))], "fallback_chain_order"


def reorder_tool_calls_for_ordering(async_rec: Dict[str, Any], ordering: List[int]) -> List[Dict[str, Any]]:
    gold = async_rec.get("gold") or {}
    calls = list(gold.get("tool_calls") or [])
    if not calls:
        return []
    node_to_step, _ = build_node_maps(async_rec)

    step_mapping: Dict[int, Optional[int]] = {}
    raw_map = async_rec.get("step_mapping") or {}
    if isinstance(raw_map, dict):
        for k, v in raw_map.items():
            try:
                ki = int(k)
            except Exception:
                continue
            if v is None:
                step_mapping[ki] = None
                continue
            try:
                vi = int(v)
            except Exception:
                step_mapping[ki] = None
                continue
            step_mapping[ki] = vi

    pos = {int(step): idx for idx, step in enumerate(ordering)}
    fallback_rank = len(ordering) + 10_000

    def call_key(call: Dict[str, Any]) -> Tuple[int, int]:
        node_id = str(call.get("node_id", "")).strip()
        orig_step: Optional[int] = None
        if node_id in node_to_step:
            orig_step = node_to_step[node_id]
        elif node_id:
            orig_step = parse_node_step_index(node_id)

        if orig_step is None:
            rank = fallback_rank
        else:
            exec_step = step_mapping.get(orig_step, orig_step)
            if exec_step is None:
                rank = fallback_rank
            else:
                rank = pos.get(int(exec_step), fallback_rank + int(exec_step))
        call_index = call.get("call_index")
        if not isinstance(call_index, int):
            call_index = 0
        return (rank, call_index)

    return sorted(calls, key=call_key)


def tool_call_sequence_signature(ordered_calls: List[Dict[str, Any]]) -> Tuple[str, ...]:
    sig: List[str] = []
    for i, call in enumerate(ordered_calls):
        call_index = call.get("call_index")
        if isinstance(call_index, int):
            sig.append(f"ci:{call_index}")
            continue
        node_id = str(call.get("node_id", ""))
        tool_id = str(call.get("tool_id", ""))
        sig.append(f"{i}:{node_id}:{tool_id}")
    return tuple(sig)


def replay_once(
    record: Dict[str, Any],
    tool_calls: List[Dict[str, Any]],
    output_dir: Path,
    attempt_tag: str,
    tool_timeout_sec: int,
) -> AttemptResult:
    attempt_dir = output_dir / "runtime_artifacts" / attempt_tag
    attempt_dir.mkdir(parents=True, exist_ok=True)
    attachments_dir = infer_attachments_dir(record)

    node_to_step, node_to_output_vars = build_node_maps(record)
    _ = node_to_step  # kept for future diagnostics
    var_store: Dict[str, str] = {}

    failed_tool_id: Optional[str] = None
    failed_output = ""
    failure_bucket: Optional[str] = None
    successful_calls = 0
    submit_seen = False
    submit_answer: Any = None

    for call in tool_calls:
        tool_id = str(call.get("tool_id", "")).strip()
        call_args = args_to_dict(call.get("arguments"))
        resolved_args = resolve_variables(call_args, var_store)
        output = execute_tool_with_timeout(
            tool_id=tool_id,
            resolved_args=resolved_args,
            attachments_dir=attachments_dir,
            output_dir=str(attempt_dir),
            timeout_sec=tool_timeout_sec,
        )
        ok = is_success_output(output)
        if ok:
            successful_calls += 1
        else:
            if failed_tool_id is None:
                failed_tool_id = tool_id
                failed_output = str(output or "")
                failure_bucket = classify_failure_bucket(output)

        node_id = str(call.get("node_id", "")).strip()
        if node_id:
            var_store[f"<{node_id}>"] = str(output or "")
            for var_name in node_to_output_vars.get(node_id, []):
                var_store[var_name] = str(output or "")

        if tool_id == "submit_final_answer":
            submit_seen = True
            submit_answer = resolved_args.get("answer")

    passed = failed_tool_id is None
    answer_match: Optional[bool] = None
    if submit_seen:
        normalized_submit, _note = normalize_submitted_answer(submit_answer)
        gold_answer = extract_answer_string(((record.get("gold") or {}).get("final_answer") or {}))
        answer_match = normalize_text(extract_answer_string(normalized_submit)) == normalize_text(gold_answer)
        passed = passed and bool(answer_match)

    return AttemptResult(
        passed=passed,
        failure_bucket=failure_bucket,
        failed_tool_id=failed_tool_id,
        failed_output=failed_output[:1000],
        successful_calls=successful_calls,
        total_calls=len(tool_calls),
        answer_match=answer_match,
    )


def evaluate_chain(
    record: Dict[str, Any],
    retries: int,
    chain_threshold: int,
    output_dir: Path,
    attempt_prefix: str,
    tool_timeout_sec: int,
) -> Tuple[int, List[AttemptResult]]:
    tool_calls = list(((record.get("gold") or {}).get("tool_calls") or []))
    attempts: List[AttemptResult] = []
    pass_count = 0
    for i in range(retries):
        result = replay_once(
            record=record,
            tool_calls=tool_calls,
            output_dir=output_dir,
            attempt_tag=f"{attempt_prefix}.chain.try{i+1}",
            tool_timeout_sec=tool_timeout_sec,
        )
        attempts.append(result)
        if result.passed:
            pass_count += 1
        remaining = retries - (i + 1)
        if pass_count >= chain_threshold:
            break
        if pass_count + remaining < chain_threshold:
            break
    return pass_count, attempts


def evaluate_ordering(
    record: Dict[str, Any],
    ordered_calls: List[Dict[str, Any]],
    retries: int,
    require_full_failure_confirmation: bool,
    output_dir: Path,
    attempt_prefix: str,
    tool_timeout_sec: int,
) -> Tuple[int, List[AttemptResult]]:
    attempts: List[AttemptResult] = []
    pass_count = 0
    for i in range(retries):
        result = replay_once(
            record=record,
            tool_calls=ordered_calls,
            output_dir=output_dir,
            attempt_tag=f"{attempt_prefix}.ordering.try{i+1}",
            tool_timeout_sec=tool_timeout_sec,
        )
        attempts.append(result)
        if result.passed:
            pass_count += 1
            break
        if not require_full_failure_confirmation:
            break
    return pass_count, attempts


def ensure_list_of_int_lists(orderings: List[Any]) -> List[List[int]]:
    clean: List[List[int]] = []
    for ordering in orderings:
        if not isinstance(ordering, list):
            continue
        curr: List[int] = []
        valid = True
        for x in ordering:
            try:
                curr.append(int(x))
            except Exception:
                valid = False
                break
        if valid:
            clean.append(curr)
    return clean


def run_category(
    base_dir: Path,
    category: str,
    retries: int,
    chain_threshold: int,
    output_dir: Path,
    max_samples: Optional[int],
    sample_offset: int,
    max_orderings_per_sample: Optional[int],
    tool_timeout_sec: int,
    force_retries_all_signatures: bool,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    chain_path = base_dir / "data.hg" / "GAIA" / CATEGORY_DIRS[category] / f"gaia.cat_{category}.json"
    async_path = base_dir / "Asynchronous" / f"gaia_cat_{category}_async_plan.jsonl"
    if not chain_path.exists():
        raise FileNotFoundError(f"Missing chain file: {chain_path}")
    if not async_path.exists():
        raise FileNotFoundError(f"Missing async file: {async_path}")

    chain_records = load_json(chain_path)
    async_records = load_jsonl(async_path)
    chain_by_id = {str((rec.get("meta") or {}).get("id", "")): rec for rec in chain_records}
    async_by_id = {str((rec.get("meta") or {}).get("id", "")): rec for rec in async_records}
    sample_ids = [sid for sid in chain_by_id.keys() if sid in async_by_id]
    sample_ids.sort()
    sample_offset = max(0, sample_offset)
    sample_ids = sample_ids[sample_offset:]
    if max_samples is not None:
        sample_ids = sample_ids[:max_samples]

    ordering_rows: List[Dict[str, Any]] = []
    chain_rows: List[Dict[str, Any]] = []
    filtered_async_rows: List[Dict[str, Any]] = []
    decisions_by_sample: Dict[str, Dict[int, str]] = defaultdict(dict)
    source_by_sample: Dict[str, str] = {}

    for idx, sample_id in enumerate(sample_ids, start=1):
        chain_rec = chain_by_id[sample_id]
        async_rec = async_by_id[sample_id]

        prefix = f"{category}.{idx:04d}.{sample_id}"
        orderings, ordering_source = get_orderings(async_rec)
        orderings = ensure_list_of_int_lists(orderings)
        if max_orderings_per_sample is not None:
            orderings = orderings[:max_orderings_per_sample]
        source_by_sample[sample_id] = ordering_source

        ordered_calls_by_index: Dict[int, List[Dict[str, Any]]] = {}
        signature_groups: Dict[Tuple[str, ...], List[int]] = defaultdict(list)
        for ordering_index, ordering in enumerate(orderings):
            ordered_calls = reorder_tool_calls_for_ordering(async_rec, ordering)
            ordered_calls_by_index[ordering_index] = ordered_calls
            signature = tool_call_sequence_signature(ordered_calls)
            signature_groups[signature].append(ordering_index)

        single_signature_mode = len(signature_groups) <= 1
        if force_retries_all_signatures:
            sample_retries = retries
            sample_chain_threshold = chain_threshold
        else:
            sample_retries = 1 if single_signature_mode else retries
            sample_chain_threshold = 1 if single_signature_mode else chain_threshold

        chain_pass_count, chain_attempts = evaluate_chain(
            record=chain_rec,
            retries=sample_retries,
            chain_threshold=sample_chain_threshold,
            output_dir=output_dir,
            attempt_prefix=prefix,
            tool_timeout_sec=tool_timeout_sec,
        )
        chain_stable = chain_pass_count >= sample_chain_threshold
        chain_rows.append(
            {
                "category": category,
                "sample_id": sample_id,
                "chain_pass_count": chain_pass_count,
                "chain_retries": sample_retries,
                "chain_stable_pass": chain_stable,
                "single_signature_mode": single_signature_mode,
                "unique_signature_count": len(signature_groups),
                "chain_failure_buckets": [a.failure_bucket for a in chain_attempts if not a.passed],
                "chain_attempts": [asdict(a) for a in chain_attempts],
            }
        )

        ordering_cache: Dict[Tuple[str, ...], Tuple[int, List[AttemptResult]]] = {}

        for ordering_index, ordering in enumerate(orderings):
            ordered_calls = ordered_calls_by_index[ordering_index]
            signature = tool_call_sequence_signature(ordered_calls)
            if signature in ordering_cache:
                ordering_pass_count, ordering_attempts = ordering_cache[signature]
            else:
                ordering_pass_count, ordering_attempts = evaluate_ordering(
                    record=chain_rec,
                    ordered_calls=ordered_calls,
                    retries=sample_retries,
                    require_full_failure_confirmation=(chain_stable and not single_signature_mode),
                    output_dir=output_dir,
                    attempt_prefix=f"{prefix}.ord{ordering_index:03d}",
                    tool_timeout_sec=tool_timeout_sec,
                )
                ordering_cache[signature] = (ordering_pass_count, ordering_attempts)

            failure_buckets = [a.failure_bucket for a in ordering_attempts if not a.passed]
            all_failures_order_dep = (
                ordering_pass_count == 0
                and len(ordering_attempts) == sample_retries
                and len(failure_buckets) == sample_retries
                and all(bucket == "order_dependency" for bucket in failure_buckets)
            )

            _ = all_failures_order_dep  # kept for diagnostics only
            decision = "VALID" if (chain_stable and ordering_pass_count >= 1) else "INVALID"

            decisions_by_sample[sample_id][ordering_index] = decision

            ordering_rows.append(
                {
                    "category": category,
                    "sample_id": sample_id,
                    "ordering_source": ordering_source,
                    "ordering_index": ordering_index,
                    "ordering": json.dumps(ordering, ensure_ascii=False),
                    "chain_pass_count": chain_pass_count,
                    "chain_retries": sample_retries,
                    "chain_stable_pass": chain_stable,
                    "single_signature_mode": single_signature_mode,
                    "unique_signature_count": len(signature_groups),
                    "ordering_pass_count": ordering_pass_count,
                    "ordering_attempts_executed": len(ordering_attempts),
                    "decision": decision,
                    "failure_buckets": json.dumps(failure_buckets, ensure_ascii=False),
                    "first_failed_tool": (
                        next((a.failed_tool_id for a in ordering_attempts if not a.passed), None)
                    ),
                    "first_failed_output": (
                        next((a.failed_output for a in ordering_attempts if not a.passed), "")[:300]
                    ),
                }
            )

    for rec in async_records:
        sid = str((rec.get("meta") or {}).get("id", ""))
        if sid not in decisions_by_sample:
            filtered_async_rows.append(rec)
            continue
        rec_out = deepcopy(rec)
        source = source_by_sample.get(sid, "fallback_chain_order")
        if source == "sampled_orderings":
            original = ensure_list_of_int_lists(rec.get("sampled_orderings") or [])
            key = "sampled_orderings"
        elif source == "possible_orderings":
            original = ensure_list_of_int_lists(rec.get("possible_orderings") or [])
            key = "possible_orderings"
        else:
            original = [list(range(len(rec.get("executable_steps") or [])))]
            key = "sampled_orderings"
            rec_out.setdefault("sampled_orderings", original)

        decision_map = decisions_by_sample[sid]
        keep_indices = [i for i in range(len(original)) if decision_map.get(i) != "INVALID"]
        filtered = [original[i] for i in keep_indices]
        rec_out[key] = filtered
        if key == "sampled_orderings":
            rec_out["num_sampled_orderings"] = len(filtered)

        validations = rec_out.setdefault("validation", {})
        counts = Counter(decision_map.values())
        validations["tool_layer_execution_filter"] = {
            "version": "v2_binary",
            "retries": retries,
            "chain_stable_threshold": chain_threshold,
            "ordering_source": source,
            "original_ordering_count": len(original),
            "kept_ordering_count": len(filtered),
            "decision_counts": dict(counts),
            "invalid_indices": [i for i, d in decision_map.items() if d == "INVALID"],
            "validated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
        filtered_async_rows.append(rec_out)

    return ordering_rows, chain_rows, filtered_async_rows


def write_rows_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Execution-based async ordering filter.")
    parser.add_argument(
        "--base-dir",
        type=Path,
        default=PROJECT_ROOT,
        help="Project base dir.",
    )
    parser.add_argument(
        "--categories",
        nargs="+",
        default=["A", "B", "C", "D"],
        choices=["A", "B", "C", "D"],
        help="GAIA categories to process.",
    )
    parser.add_argument("--retries", type=int, default=3, help="Retries per chain/ordering.")
    parser.add_argument(
        "--chain-stable-threshold",
        type=int,
        default=2,
        help="Stable pass threshold for chain (e.g., 2 for >=2/3).",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory. Default: Asynchronous/tool_layer_validation/<timestamp>",
    )
    parser.add_argument(
        "--max-samples-per-category",
        type=int,
        default=None,
        help="Debug cap for samples per category.",
    )
    parser.add_argument(
        "--sample-offset",
        type=int,
        default=0,
        help="Offset into sorted sample_id list (for batch runs).",
    )
    parser.add_argument(
        "--max-orderings-per-sample",
        type=int,
        default=None,
        help="Debug cap for orderings per sample.",
    )
    parser.add_argument(
        "--tool-timeout-sec",
        type=int,
        default=45,
        help="Hard timeout per tool call in seconds.",
    )
    parser.add_argument(
        "--force-retries-all-signatures",
        action="store_true",
        help=(
            "Disable the single-signature fast path and apply --retries / "
            "--chain-stable-threshold to every sample. Use this for strict "
            "2-of-3 task-level tool-stability analyses."
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    base_dir = args.base_dir.resolve()
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    output_dir = args.output_dir or (base_dir / "Asynchronous" / "tool_layer_validation" / timestamp)
    output_dir.mkdir(parents=True, exist_ok=True)

    all_ordering_rows: List[Dict[str, Any]] = []
    all_chain_rows: List[Dict[str, Any]] = []
    per_category_filtered: Dict[str, List[Dict[str, Any]]] = {}

    for cat in args.categories:
        ordering_rows, chain_rows, filtered_rows = run_category(
            base_dir=base_dir,
            category=cat,
            retries=args.retries,
            chain_threshold=args.chain_stable_threshold,
            output_dir=output_dir,
            max_samples=args.max_samples_per_category,
            sample_offset=args.sample_offset,
            max_orderings_per_sample=args.max_orderings_per_sample,
            tool_timeout_sec=args.tool_timeout_sec,
            force_retries_all_signatures=args.force_retries_all_signatures,
        )
        all_ordering_rows.extend(ordering_rows)
        all_chain_rows.extend(chain_rows)
        per_category_filtered[cat] = filtered_rows

    write_rows_csv(output_dir / "rows.csv", all_ordering_rows)
    write_jsonl(output_dir / "rows.jsonl", all_ordering_rows)
    write_jsonl(output_dir / "chain_baseline.jsonl", all_chain_rows)

    filtered_dir = output_dir / "filtered_async"
    filtered_dir.mkdir(parents=True, exist_ok=True)
    for cat in args.categories:
        rows = per_category_filtered.get(cat, [])
        write_jsonl(filtered_dir / f"gaia_cat_{cat}_async_plan.filtered.jsonl", rows)

    decision_counts = Counter(row["decision"] for row in all_ordering_rows)
    per_category_counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for row in all_ordering_rows:
        per_category_counts[row["category"]][row["decision"]] += 1

    chain_stable_count = sum(1 for row in all_chain_rows if row["chain_stable_pass"])
    summary = {
        "output_dir": str(output_dir),
        "categories": args.categories,
        "retries": args.retries,
        "chain_stable_threshold": args.chain_stable_threshold,
        "sample_offset": args.sample_offset,
        "max_samples_per_category": args.max_samples_per_category,
        "force_retries_all_signatures": args.force_retries_all_signatures,
        "total_chain_samples": len(all_chain_rows),
        "chain_stable_samples": chain_stable_count,
        "total_ordering_rows": len(all_ordering_rows),
        "decision_counts": dict(decision_counts),
        "per_category_decision_counts": {
            cat: dict(counter) for cat, counter in per_category_counts.items()
        },
        "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
