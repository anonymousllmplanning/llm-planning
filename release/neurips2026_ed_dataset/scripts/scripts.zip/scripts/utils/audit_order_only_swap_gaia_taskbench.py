#!/usr/bin/env python3
"""Audit the effect of replacing EdgeF1 with OrderF1 while keeping NodeF1 fixed.

This script separates two questions that can otherwise get mixed together:

1. Does the proposed order metric add value if the node component remains the
   prior-style one-to-one NodeF1?
2. How different is that from the full SpanNodeF1 + OrderF1 score?

It reports three planning families:

* node_edge:        (strict_node_f1 + semantic_edge_f1) / 2
* node_order:       (strict_node_f1 + strict_node_anchored_order_f1) / 2
* span_order:       (span_node_f1 + span_reanchored_order_f1) / 2

The middle score is the clean "only replace EdgeF1 with OrderF1" ablation.
"""

from __future__ import annotations

import argparse
import copy
import glob
import json
import sys
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.evaluation.metrics import (  # noqa: E402
    ASTEvaluationSystem,
    _f1_from_prec_recall,
    _semantic_node_alignment,
)
from scripts.utils.compare_gaia_augmented_prior_span_order import (  # noqa: E402
    CATEGORY_META,
    category_from_subset,
    dependency_dag_from_async_record,
    iter_jsonl,
    load_gold_references,
    record_id,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=REPO_ROOT)
    parser.add_argument(
        "--gaia-results-root",
        type=Path,
        default=REPO_ROOT / "organized_results/gaia/0427",
    )
    parser.add_argument(
        "--taskbench-dir",
        type=Path,
        default=REPO_ROOT / "organized_results/taskbench_balanced_600",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REPO_ROOT / "runtime_artifacts/order_only_swap_audit_20260428",
    )
    return parser.parse_args()


def _edge_pairs_by_node_index(nodes: Sequence[Dict[str, Any]], edges: Sequence[Dict[str, Any]]) -> Set[Tuple[int, int]]:
    id_to_idx = {n.get("node_id", ""): i for i, n in enumerate(nodes)}
    pairs: Set[Tuple[int, int]] = set()
    for e in edges or []:
        source = e.get("source")
        target = e.get("target")
        sources = source if isinstance(source, list) else ([source] if source else [])
        targets = target if isinstance(target, list) else ([target] if target else [])
        for src in sources:
            s = id_to_idx.get(src)
            if s is None:
                continue
            for tgt in targets:
                t = id_to_idx.get(tgt)
                if t is not None and s != t:
                    pairs.add((s, t))
    return pairs


def _transitive_pairs_with_dist(num_nodes: int, edge_pairs: Set[Tuple[int, int]]) -> Tuple[Set[Tuple[int, int]], Dict[Tuple[int, int], int]]:
    adjacency: Dict[int, Set[int]] = {i: set() for i in range(num_nodes)}
    for s, t in edge_pairs:
        if 0 <= s < num_nodes and 0 <= t < num_nodes and s != t:
            adjacency[s].add(t)

    closure: Set[Tuple[int, int]] = set()
    shortest: Dict[Tuple[int, int], int] = {}
    for start in range(num_nodes):
        queue: List[Tuple[int, int]] = [(start, 0)]
        seen = {start}
        head = 0
        while head < len(queue):
            node, dist = queue[head]
            head += 1
            for nxt in adjacency.get(node, set()):
                if nxt in seen:
                    continue
                seen.add(nxt)
                queue.append((nxt, dist + 1))
                pair = (start, nxt)
                closure.add(pair)
                shortest[pair] = min(shortest.get(pair, dist + 1), dist + 1)
    return closure, shortest


def strict_node_anchored_order_f1(gold_dag: Dict[str, Any], pred_dag: Dict[str, Any]) -> float:
    """Distance-weighted OrderF1 anchored by prior-style one-to-one NodeF1 matching."""
    gold_nodes = gold_dag.get("nodes") or []
    pred_nodes = pred_dag.get("nodes") or []
    gold_edges = gold_dag.get("edges") or []
    pred_edges = pred_dag.get("edges") or []
    if not gold_nodes and not pred_nodes:
        return 1.0
    if not gold_nodes or not pred_nodes:
        return 0.0

    _, _, pred_to_gold = _semantic_node_alignment(gold_nodes, pred_nodes)
    gold_edge_pairs = _edge_pairs_by_node_index(gold_nodes, gold_edges)
    pred_edge_pairs = _edge_pairs_by_node_index(pred_nodes, pred_edges)
    gold_order, gold_dist = _transitive_pairs_with_dist(len(gold_nodes), gold_edge_pairs)
    pred_order, pred_dist = _transitive_pairs_with_dist(len(pred_nodes), pred_edge_pairs)

    if not gold_order and not pred_order:
        return 1.0
    if not gold_order:
        return 0.0
    if not pred_order:
        return 0.0

    pred_weight_denom = sum(1.0 / max(pred_dist[pair], 1) for pair in pred_order)
    pred_weight_num = 0.0
    covered_gold: Set[Tuple[int, int]] = set()

    for s_pred, t_pred in pred_order:
        s_gold = pred_to_gold.get(s_pred)
        t_gold = pred_to_gold.get(t_pred)
        if s_gold is None or t_gold is None or s_gold == t_gold:
            continue
        reanchored = (s_gold, t_gold)
        if reanchored in gold_order:
            pred_weight_num += 1.0 / max(pred_dist[(s_pred, t_pred)], 1)
            covered_gold.add(reanchored)

    gold_weight_denom = sum(1.0 / max(gold_dist[pair], 1) for pair in gold_order)
    gold_weight_num = sum(1.0 / max(gold_dist[pair], 1) for pair in covered_gold)

    precision = pred_weight_num / pred_weight_denom if pred_weight_denom else 0.0
    recall = gold_weight_num / gold_weight_denom if gold_weight_denom else 0.0
    return _f1_from_prec_recall(precision, recall)


def score_plan(evaluator: ASTEvaluationSystem, gold_dag: Dict[str, Any], pred_dag: Dict[str, Any]) -> Dict[str, float]:
    scores = evaluator.evaluate_plan_dag(gold_dag, pred_dag)
    strict_order = strict_node_anchored_order_f1(gold_dag, pred_dag)
    node_edge = (scores.strict_node_f1 + scores.semantic_edge_f1) / 2.0
    node_order = (scores.strict_node_f1 + strict_order) / 2.0
    span_order = (scores.span_node_f1 + scores.dw_order_f1) / 2.0
    return {
        "strict_node_f1": scores.strict_node_f1,
        "span_node_f1": scores.span_node_f1,
        "semantic_edge_f1": scores.semantic_edge_f1,
        "strict_node_order_f1": strict_order,
        "span_order_f1": scores.dw_order_f1,
        "node_edge_score": node_edge,
        "node_order_score": node_order,
        "span_order_score": span_order,
        "node_order_minus_node_edge": node_order - node_edge,
        "span_order_minus_node_edge": span_order - node_edge,
    }


def choose_best(scored_refs: List[Tuple[str, Dict[str, float]]], metric_key: str) -> Tuple[str, Dict[str, float]]:
    preference = {"chain": 0, "dag": 1}
    return max(scored_refs, key=lambda item: (item[1][metric_key], -preference.get(item[0], 99)))


def collect_gaia(args: argparse.Namespace, evaluator: ASTEvaluationSystem) -> pd.DataFrame:
    chain_gold, async_gold = load_gold_references(args.repo_root)
    rows: List[Dict[str, Any]] = []
    unified_paths = sorted(
        path
        for path in glob.glob(str(args.gaia_results_root / "**/unified.*.jsonl"), recursive=True)
        if "/tool_creation_log." not in path
    )
    for path_string in unified_paths:
        path = Path(path_string)
        for record in iter_jsonl(path):
            meta = record.get("meta") or {}
            sample_id = meta.get("id")
            pred_dag = (record.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []}
            subset = meta.get("subset", "")
            category_code = category_from_subset(subset)
            category = CATEGORY_META.get(category_code, {}).get("name", "")
            model = meta.get("model_name")

            gaia_chain = copy.deepcopy(chain_gold[sample_id]["gold"]["plan_dag"])
            aug_chain = copy.deepcopy(async_gold[sample_id]["gold"]["plan_dag"])
            aug_dag = dependency_dag_from_async_record(async_gold[sample_id])

            gaia_scores = score_plan(evaluator, gaia_chain, pred_dag)
            aug_candidates = [
                ("chain", score_plan(evaluator, aug_chain, pred_dag)),
                ("dag", score_plan(evaluator, aug_dag, pred_dag)),
            ]
            _, aug_node_edge = choose_best(aug_candidates, "node_edge_score")
            node_order_ref, aug_node_order = choose_best(aug_candidates, "node_order_score")
            span_order_ref, aug_span_order = choose_best(aug_candidates, "span_order_score")

            row = {
                "dataset": "gaia",
                "sample_id": sample_id,
                "model": model,
                "category": category,
                "subset": subset,
                "gaia_node_edge_score": gaia_scores["node_edge_score"],
                "gaia_node_order_score": gaia_scores["node_order_score"],
                "gaia_span_order_score": gaia_scores["span_order_score"],
                "aug_node_edge_score": aug_node_edge["node_edge_score"],
                "aug_node_order_score": aug_node_order["node_order_score"],
                "aug_span_order_score": aug_span_order["span_order_score"],
                "aug_node_order_best_ref": node_order_ref,
                "aug_span_order_best_ref": span_order_ref,
            }
            for prefix, scores in [
                ("gaia", gaia_scores),
                ("aug_node_edge", aug_node_edge),
                ("aug_node_order", aug_node_order),
                ("aug_span_order", aug_span_order),
            ]:
                for key, value in scores.items():
                    row[f"{prefix}_{key}"] = value
            rows.append(row)
    return pd.DataFrame(rows)


def collect_taskbench(args: argparse.Namespace, evaluator: ASTEvaluationSystem) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for unified_path in sorted(args.taskbench_dir.glob("unified.*.jsonl")):
        model = unified_path.stem.replace("unified.", "")
        for line in unified_path.open():
            record = json.loads(line)
            meta = record.get("meta") or {}
            gold_dag = (record.get("gold") or {}).get("plan_dag") or {"nodes": [], "edges": []}
            pred_dag = (record.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []}
            scores = score_plan(evaluator, gold_dag, pred_dag)
            row = {
                "dataset": "taskbench",
                "sample_id": meta.get("id"),
                "model": model,
                "subset": meta.get("subset"),
                "plan_type": meta.get("plan_type"),
            }
            row.update(scores)
            rows.append(row)
    return pd.DataFrame(rows)


def summarize(df: pd.DataFrame, group_cols: List[str], prefix: str = "") -> pd.DataFrame:
    metric_cols = [
        col
        for col in df.columns
        if col.endswith("_score")
        or col.endswith("_f1")
        or col.endswith("_minus_node_edge")
    ]
    grouped = df.groupby(group_cols, as_index=False).agg(
        n=("sample_id", "count"),
        **{col: (col, "mean") for col in metric_cols},
    )
    if prefix:
        grouped.insert(0, "slice", prefix)
    return grouped


def main() -> None:
    args = parse_args()
    out_dir = args.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    evaluator = ASTEvaluationSystem(use_embeddings=True)

    gaia = collect_gaia(args, evaluator)
    taskbench = collect_taskbench(args, evaluator)
    gaia.to_csv(out_dir / "gaia_order_only_swap_per_sample.csv", index=False)
    taskbench.to_csv(out_dir / "taskbench_order_only_swap_per_sample.csv", index=False)

    gaia_model = summarize(gaia, ["model"])
    gaia_category = summarize(gaia, ["category"])
    gaia_overall = summarize(gaia.assign(all="all"), ["all"])
    task_model = summarize(taskbench, ["model"])
    task_plan_type = summarize(taskbench, ["plan_type"])
    task_overall = summarize(taskbench.assign(all="all"), ["all"])

    gaia_model.to_csv(out_dir / "gaia_order_only_swap_by_model.csv", index=False)
    gaia_category.to_csv(out_dir / "gaia_order_only_swap_by_category.csv", index=False)
    gaia_overall.to_csv(out_dir / "gaia_order_only_swap_overall.csv", index=False)
    task_model.to_csv(out_dir / "taskbench_order_only_swap_by_model.csv", index=False)
    task_plan_type.to_csv(out_dir / "taskbench_order_only_swap_by_plan_type.csv", index=False)
    task_overall.to_csv(out_dir / "taskbench_order_only_swap_overall.csv", index=False)

    print("[GAIA OVERALL]")
    print(
        gaia_overall[
            [
                "n",
                "gaia_node_edge_score",
                "gaia_node_order_score",
                "gaia_span_order_score",
                "aug_node_edge_score",
                "aug_node_order_score",
                "aug_span_order_score",
            ]
        ].round(4).to_string(index=False)
    )
    print("\n[GAIA MODEL]")
    print(
        gaia_model[
            ["model", "n", "aug_node_edge_score", "aug_node_order_score", "aug_span_order_score"]
        ].round(4).sort_values("aug_node_order_score", ascending=False).to_string(index=False)
    )
    print("\n[TASKBENCH OVERALL]")
    print(
        task_overall[["n", "node_edge_score", "node_order_score", "span_order_score"]]
        .round(4)
        .to_string(index=False)
    )
    print("\n[TASKBENCH PLAN TYPE]")
    print(
        task_plan_type[["plan_type", "n", "node_edge_score", "node_order_score", "span_order_score"]]
        .round(4)
        .to_string(index=False)
    )
    print(f"\n[WROTE] {out_dir}")


if __name__ == "__main__":
    main()
