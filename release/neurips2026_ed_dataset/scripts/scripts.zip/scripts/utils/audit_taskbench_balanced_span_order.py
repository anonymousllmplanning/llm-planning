#!/usr/bin/env python3
"""Audit TaskBench balanced runs with prior-style and proposed planning scores.

This script is intentionally narrow: it reads unified TaskBench result files,
re-evaluates their gold/predicted plan DAGs with the current evaluator, and
writes per-sample plus grouped comparisons between:

    NodeF1 + EdgeF1 baseline = (strict_node_f1 + semantic_edge_f1) / 2
    Proposed planning score = (span_node_f1 + dw_order_f1) / 2

The input expected by default is organized_results/taskbench_balanced_600,
which contains 300 chain and 300 DAG examples per model.
"""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean
from typing import Any, Dict, Iterable, List, Sequence

from src.evaluation.metrics import ASTEvaluationSystem


PER_SAMPLE_FIELDS = [
    "model",
    "sample_id",
    "subset",
    "plan_type",
    "gold_node_count",
    "pred_node_count",
    "gold_edge_count",
    "pred_edge_count",
    "strict_node_f1",
    "span_node_f1",
    "semantic_edge_f1",
    "dw_order_f1",
    "prior_planning_score",
    "proposed_planning_score",
    "delta_planning_score",
    "edge_f1",
    "index_dw_order_f1",
    "order_f1",
    "order_precision",
    "order_recall",
]

GROUP_FIELDS = [
    "group",
    "model",
    "n",
    "strict_node_f1",
    "span_node_f1",
    "semantic_edge_f1",
    "dw_order_f1",
    "prior_planning_score",
    "proposed_planning_score",
    "delta_planning_score",
]


def _f(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _mean(rows: Sequence[Dict[str, Any]], key: str) -> float:
    vals = [_f(row.get(key)) for row in rows]
    return mean(vals) if vals else 0.0


def _group_key(row: Dict[str, Any], fields: Iterable[str]) -> str:
    return " / ".join(str(row.get(field, "")) for field in fields)


def _write_csv(path: Path, rows: List[Dict[str, Any]], fields: List[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _summarize_group(group: str, model: str, rows: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    return {
        "group": group,
        "model": model,
        "n": len(rows),
        "strict_node_f1": _mean(rows, "strict_node_f1"),
        "span_node_f1": _mean(rows, "span_node_f1"),
        "semantic_edge_f1": _mean(rows, "semantic_edge_f1"),
        "dw_order_f1": _mean(rows, "dw_order_f1"),
        "prior_planning_score": _mean(rows, "prior_planning_score"),
        "proposed_planning_score": _mean(rows, "proposed_planning_score"),
        "delta_planning_score": _mean(rows, "delta_planning_score"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compare prior-style and proposed planning metrics on TaskBench balanced results."
    )
    parser.add_argument(
        "--taskbench-dir",
        type=Path,
        default=Path("organized_results/taskbench_balanced_600"),
        help="Directory containing unified.<model>.jsonl files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("runtime_artifacts/taskbench_balanced_600_span_order_audit_20260428"),
        help="Directory where audit CSV files are written.",
    )
    parser.add_argument(
        "--use-embeddings",
        action="store_true",
        help="Enable embedding node similarity if sentence-transformers is available in this Python environment.",
    )
    args = parser.parse_args()

    evaluator = ASTEvaluationSystem(use_embeddings=args.use_embeddings, verifier_model=None)
    per_sample_rows: List[Dict[str, Any]] = []

    for unified_path in sorted(args.taskbench_dir.glob("unified.*.jsonl")):
        model = unified_path.stem.replace("unified.", "")
        with unified_path.open() as f:
            for line_no, line in enumerate(f, start=1):
                rec = json.loads(line)
                meta = rec.get("meta") or {}
                gold_dag = (rec.get("gold") or {}).get("plan_dag") or {"nodes": [], "edges": []}
                pred_dag = (rec.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []}
                scores = evaluator.evaluate_plan_dag(gold_dag, pred_dag, dataset="taskbench")
                prior_planning = (scores.strict_node_f1 + scores.semantic_edge_f1) / 2.0
                proposed_planning = (scores.span_node_f1 + scores.dw_order_f1) / 2.0

                per_sample_rows.append({
                    "model": model,
                    "sample_id": meta.get("id") or f"{unified_path.name}:{line_no}",
                    "subset": meta.get("subset") or "",
                    "plan_type": meta.get("plan_type") or "",
                    "gold_node_count": len(gold_dag.get("nodes") or []),
                    "pred_node_count": len(pred_dag.get("nodes") or []),
                    "gold_edge_count": len(gold_dag.get("edges") or []),
                    "pred_edge_count": len(pred_dag.get("edges") or []),
                    "strict_node_f1": scores.strict_node_f1,
                    "span_node_f1": scores.span_node_f1,
                    "semantic_edge_f1": scores.semantic_edge_f1,
                    "dw_order_f1": scores.dw_order_f1,
                    "prior_planning_score": prior_planning,
                    "proposed_planning_score": proposed_planning,
                    "delta_planning_score": proposed_planning - prior_planning,
                    "edge_f1": scores.edge_f1,
                    "index_dw_order_f1": scores.index_dw_order_f1,
                    "order_f1": scores.order_f1,
                    "order_precision": scores.order_precision,
                    "order_recall": scores.order_recall,
                })

    if not per_sample_rows:
        raise SystemExit(f"No unified.*.jsonl files found under {args.taskbench_dir}")

    grouped_rows: List[Dict[str, Any]] = []
    for group_name, fields in [
        ("overall", []),
        ("plan_type", ["plan_type"]),
        ("subset", ["subset"]),
        ("subset_plan_type", ["subset", "plan_type"]),
    ]:
        bucket: Dict[tuple[str, str], List[Dict[str, Any]]] = defaultdict(list)
        for row in per_sample_rows:
            key = "all" if not fields else _group_key(row, fields)
            bucket[(key, row["model"])].append(row)
        for (key, model), rows in sorted(bucket.items()):
            grouped_rows.append(_summarize_group(f"{group_name}:{key}", model, rows))

    aggregate_bucket: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in per_sample_rows:
        aggregate_bucket["overall"].append(row)
        aggregate_bucket[f"plan_type:{row['plan_type']}"].append(row)
        aggregate_bucket[f"subset:{row['subset']}"].append(row)
        aggregate_bucket[f"subset_plan_type:{row['subset']}/{row['plan_type']}"].append(row)

    aggregate_rows = [
        _summarize_group(group, "ALL_MODELS", rows)
        for group, rows in sorted(aggregate_bucket.items())
    ]

    _write_csv(args.output_dir / "taskbench_balanced_per_sample_prior_vs_proposed.csv", per_sample_rows, PER_SAMPLE_FIELDS)
    _write_csv(args.output_dir / "taskbench_balanced_grouped_by_model_prior_vs_proposed.csv", grouped_rows, GROUP_FIELDS)
    _write_csv(args.output_dir / "taskbench_balanced_aggregate_prior_vs_proposed.csv", aggregate_rows, GROUP_FIELDS)

    headline = [row for row in aggregate_rows if row["group"] in {"overall", "plan_type:chain", "plan_type:dag"}]
    print(f"[OK] Wrote audit CSVs to {args.output_dir}")
    print("group,n,prior,proposed,delta")
    for row in headline:
        print(
            f"{row['group']},{row['n']},"
            f"{row['prior_planning_score']:.4f},"
            f"{row['proposed_planning_score']:.4f},"
            f"{row['delta_planning_score']:.4f}"
        )


if __name__ == "__main__":
    main()
