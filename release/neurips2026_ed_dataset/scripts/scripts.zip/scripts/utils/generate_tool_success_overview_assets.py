#!/usr/bin/env python3
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parents[2]
PAPER_DIR = ROOT / "organized_results" / "gaia" / "paper"
FIG_DIR = ROOT / "docs" / "neurips" / "generated" / "custom_figures"
CSV_DIR = ROOT / "docs" / "neurips" / "generated" / "stage_diagnostics"


SCENARIO_LABELS = {
    "cat_A": "Text Reasoning",
    "cat_B": "Document Analysis",
    "cat_C": "Vision",
    "cat_D": "Audio",
}


def _as_float(value: str | None) -> float | None:
    if value in (None, "", "N/A"):
        return None
    try:
        return float(value)
    except ValueError:
        return None


def collect_rows() -> list[dict[str, object]]:
    scenario_rows: dict[str, dict[str, list[float] | int]] = defaultdict(
        lambda: {"ats": [], "tisr": [], "n": 0}
    )

    for path in sorted(PAPER_DIR.glob("*.gaia_*.answer/per_sample.*.csv")):
        parent = path.parent.name
        if ".gaia_cat_" not in parent:
            continue
        scenario_key = parent.split(".gaia_")[1].split(".answer")[0]

        with path.open(newline="") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                scenario_rows[scenario_key]["n"] += 1
                ats = _as_float(row.get("gt_aligned_tool_success_rate"))
                tisr = _as_float(row.get("pred_exec_success_rate"))
                if ats is not None:
                    scenario_rows[scenario_key]["ats"].append(ats)
                if tisr is not None:
                    scenario_rows[scenario_key]["tisr"].append(tisr)

    rows: list[dict[str, object]] = []
    overall_ats: list[float] = []
    overall_tisr: list[float] = []
    overall_n = 0

    for scenario_key in ("cat_A", "cat_B", "cat_C", "cat_D"):
        values = scenario_rows.get(scenario_key)
        if not values:
            continue
        ats_vals = values["ats"]
        tisr_vals = values["tisr"]
        n = int(values["n"])
        overall_ats.extend(ats_vals)
        overall_tisr.extend(tisr_vals)
        overall_n += n
        rows.append(
            {
                "scenario_key": scenario_key,
                "scenario": SCENARIO_LABELS[scenario_key],
                "n_predictions": n,
                "ats_mean": sum(ats_vals) / len(ats_vals) if ats_vals else None,
                "tisr_mean": sum(tisr_vals) / len(tisr_vals) if tisr_vals else None,
            }
        )

    rows.append(
        {
            "scenario_key": "overall",
            "scenario": "Overall",
            "n_predictions": overall_n,
            "ats_mean": sum(overall_ats) / len(overall_ats) if overall_ats else None,
            "tisr_mean": sum(overall_tisr) / len(overall_tisr) if overall_tisr else None,
        }
    )
    return rows


def write_csv(rows: list[dict[str, object]]) -> Path:
    CSV_DIR.mkdir(parents=True, exist_ok=True)
    out = CSV_DIR / "tool_success_overview.csv"
    with out.open("w", newline="") as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=[
                "scenario_key",
                "scenario",
                "n_predictions",
                "ats_mean",
                "tisr_mean",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)
    return out


def make_plot(rows: list[dict[str, object]]) -> Path:
    FIG_DIR.mkdir(parents=True, exist_ok=True)
    labels = [f"{row['scenario']}\n(n={row['n_predictions']})" for row in rows]
    ats = [row["ats_mean"] for row in rows]
    tisr = [row["tisr_mean"] for row in rows]

    x = list(range(len(rows)))
    width = 0.36

    fig, ax = plt.subplots(figsize=(8.6, 4.6))
    ax.bar([i - width / 2 for i in x], ats, width=width, color="#4c78a8", label="ATS")
    ax.bar([i + width / 2 for i in x], tisr, width=width, color="#f28e2b", label="TISR")

    for idx, val in enumerate(ats):
        ax.text(idx - width / 2, val + 0.015, f"{val:.3f}", ha="center", va="bottom", fontsize=8)
    for idx, val in enumerate(tisr):
        ax.text(idx + width / 2, val + 0.015, f"{val:.3f}", ha="center", va="bottom", fontsize=8)

    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Mean score")
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.set_title("Scenario-level ATS and TISR in the current paper pool")
    ax.grid(axis="y", alpha=0.25, linestyle="--")
    ax.legend(frameon=False, ncol=2, loc="upper left")
    fig.tight_layout()

    out_pdf = FIG_DIR / "tool_success_overview_main.pdf"
    out_png = FIG_DIR / "tool_success_overview_main.png"
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=220)
    plt.close(fig)
    return out_pdf


def main() -> None:
    rows = collect_rows()
    csv_path = write_csv(rows)
    fig_path = make_plot(rows)
    print(f"[OK] Wrote {csv_path}")
    print(f"[OK] Wrote {fig_path}")


if __name__ == "__main__":
    main()
