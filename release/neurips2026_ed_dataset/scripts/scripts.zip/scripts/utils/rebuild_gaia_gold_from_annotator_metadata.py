#!/usr/bin/env python3
"""
Rebuild GAIA gold.plan_dag from original Annotator Metadata.

Goals:
1. Preserve the original human-written sub-step descriptions from
   Annotator Metadata['Steps'] as gold.plan_dag.nodes[].label.
2. Keep plan_dag.edges sequential (chain-like).
3. Remove synthetic submit_final_answer from gold plan/tool golds so the
   original GAIA semantics are not polluted.
4. Preserve the existing executable gold.tool_calls (except submit_final_answer)
   so tool/argument evaluation can still fit the repo's framework.
5. Best-effort pair executable tool_ids back onto step nodes when there is a
   reasonably clear match; otherwise leave tool_id as null and step_type as
   thought.
"""

from __future__ import annotations

import ast
import json
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
from urllib.parse import urlparse

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[2]
BACKUP_METADATA = REPO_ROOT / "backup" / "GAIA" / "2023" / "validation" / "metadata.parquet"

GAIA_DATASETS: Sequence[Tuple[Path, Path]] = (
    (
        REPO_ROOT / "data" / "GAIA" / "cat_A_text" / "gaia.cat_A.json",
        REPO_ROOT / "data.hg" / "GAIA" / "cat_A_text" / "gaia.cat_A.json",
    ),
    (
        REPO_ROOT / "data" / "GAIA" / "cat_B_document" / "gaia.cat_B.json",
        REPO_ROOT / "data.hg" / "GAIA" / "cat_B_document" / "gaia.cat_B.json",
    ),
    (
        REPO_ROOT / "data" / "GAIA" / "cat_C_vision" / "gaia.cat_C.json",
        REPO_ROOT / "data.hg" / "GAIA" / "cat_C_vision" / "gaia.cat_C.json",
    ),
    (
        REPO_ROOT / "data" / "GAIA" / "cat_D_audio" / "gaia.cat_D.json",
        REPO_ROOT / "data.hg" / "GAIA" / "cat_D_audio" / "gaia.cat_D.json",
    ),
)


STEP_INLINE_PATTERN = re.compile(r"(?i)\bStep\s+\d+\s*:")
STEP_MARKER_PATTERN = re.compile(r"(?i)\bStep\s+(\d+)\s*:\s*")
LINE_NUMBER_PATTERN = re.compile(r"^\s*(\d+)\.\s*(.*)$")


def _normalize_ws(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _normalize_for_match(text: str) -> str:
    return _normalize_ws(text).casefold()


def _safe_float_string(text: str) -> bool:
    try:
        float(text)
        return True
    except Exception:
        return False


def _strip_trailing_punctuation(text: str) -> str:
    return text.strip().rstrip(".,;:)")


def _quoted_segments(text: str) -> List[str]:
    return [
        _normalize_ws(seg)
        for seg in re.findall(r'[\"“](.*?)[\"”]', text)
        if _normalize_ws(seg)
    ]


def _first_url_like(text: str) -> Optional[str]:
    url_match = re.search(r"https?://[^\s\],)\"“”]+", text)
    if url_match:
        return url_match.group(0)

    domain_match = re.search(
        r"\b(?:[a-z0-9-]+\.)+(?:com|org|net|edu|gov|io|ai|tw)(?:/[^\s\],)\"“”]*)?",
        text,
        flags=re.I,
    )
    if domain_match:
        url = domain_match.group(0)
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        return url
    return None


def canonicalize_query(current: str, step_label: str) -> Optional[str]:
    current = _normalize_ws(str(current))
    step_label = _normalize_ws(step_label)

    if current and "..." not in current:
        return current

    for candidate in _quoted_segments(step_label):
        if candidate:
            return candidate

    lowered = step_label.casefold()
    verb_patterns = [
        r"^(?:search(?: the web)?(?: for)?|searched|googled)\s+",
        r"^(?:search engine to search for)\s+",
        r"^(?:conduct a search,?)\s+",
    ]
    stripped = step_label
    for pat in verb_patterns:
        stripped = re.sub(pat, "", stripped, flags=re.I)
    stripped = re.sub(r"\s+on\s+(?:google|google search|duckduckgo).*$", "", stripped, flags=re.I)
    stripped = re.sub(r"\s+and open.*$", "", stripped, flags=re.I)
    stripped = _strip_trailing_punctuation(stripped)

    if stripped and stripped.casefold() != lowered:
        return stripped

    return None


def canonicalize_url(current: str, step_label: str) -> Optional[str]:
    current = _normalize_ws(str(current))
    if current.startswith(("http://", "https://")):
        return current

    for source in (step_label, current):
        candidate = _first_url_like(source)
        if candidate:
            return candidate
    return None


def _is_python_expression(expr: str) -> bool:
    expr = expr.strip()
    if not expr:
        return False
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError:
        return False

    allowed_nodes = (
        ast.Expression,
        ast.BinOp,
        ast.UnaryOp,
        ast.Call,
        ast.Name,
        ast.Load,
        ast.Constant,
        ast.List,
        ast.Tuple,
        ast.Add,
        ast.Sub,
        ast.Mult,
        ast.Div,
        ast.Pow,
        ast.Mod,
        ast.USub,
        ast.UAdd,
    )
    allowed_names = {"sqrt", "log", "sin", "cos", "pi", "e", "stdev", "pstdev", "mean", "median", "ceil", "floor"}
    for node in ast.walk(tree):
        if not isinstance(node, allowed_nodes):
            return False
        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name) or node.func.id not in allowed_names:
                return False
        if isinstance(node, ast.Name) and node.id not in allowed_names:
            return False
    return True


def _clean_expression(expr: str) -> str:
    expr = expr.strip()
    expr = expr.replace(",", "")
    expr = re.sub(r"(\d+(?:\.\d+)?)\s*%", lambda m: str(float(m.group(1)) / 100), expr)
    expr = re.sub(r"\bof\b", "*", expr, flags=re.I)
    expr = re.sub(r"\s+", " ", expr).strip()
    return expr


def canonicalize_expression(current: str, step_label: str) -> Optional[str]:
    candidates: List[str] = []
    current = _normalize_ws(str(current))
    step_label = _normalize_ws(step_label)

    if current:
        candidates.append(current)
    if step_label and step_label != current:
        candidates.append(step_label)

    derived: List[str] = []
    for text in candidates:
        if re.fullmatch(r"-?\d+(?:,\d{3})*(?:\.\d+)?%?", text):
            derived.append(text)

        paren_matches = re.findall(r"\(([^()]*)\)", text)
        derived.extend(paren_matches)

        if "=" in text:
            derived.append(text.split("=", 1)[0])

        percent_of = re.search(r"(\d+(?:\.\d+)?)\s*%\s+of\s+(\d+(?:,\d{3})*(?:\.\d+)?)", text, flags=re.I)
        if percent_of:
            derived.append(f"({percent_of.group(1)}/100) * {percent_of.group(2).replace(',', '')}")

    candidates.extend(derived)

    for candidate in candidates:
        candidate = _clean_expression(candidate)
        candidate = re.sub(r"^[A-Za-z _-]+:\s*", "", candidate)
        candidate = re.sub(r"[^0-9A-Za-z_\.\+\-\*/%\(\)\[\], ]", "", candidate)
        candidate = _normalize_ws(candidate)
        if not candidate:
            continue
        if _is_python_expression(candidate):
            return candidate

    return None


def normalize_call_arguments(tool_id: str, step_label: str, arguments: List[Dict[str, Any]]) -> Optional[List[Dict[str, Any]]]:
    arg_map = {arg.get("name"): arg.get("value") for arg in arguments}

    if tool_id == "reasoning":
        return [{"name": "problem", "value": step_label}]

    if tool_id == "web_search":
        query = canonicalize_query(str(arg_map.get("query", "")), step_label)
        return [{"name": "query", "value": query}] if query else None

    if tool_id == "web_browser":
        url = canonicalize_url(str(arg_map.get("url", "")), step_label)
        return [{"name": "url", "value": url}] if url else None

    if tool_id == "calculator":
        expr = canonicalize_expression(str(arg_map.get("expression", "")), step_label)
        return [{"name": "expression", "value": expr}] if expr else None

    if tool_id == "audio_transcription":
        file_path = arg_map.get("file_path")
        return [{"name": "file_path", "value": file_path}] if file_path else None

    if tool_id == "image_recognition":
        file_path = arg_map.get("file_path")
        task = arg_map.get("task")
        custom_prompt = arg_map.get("custom_prompt")
        if not file_path or not task:
            return None
        normalized = [
            {"name": "file_path", "value": file_path},
            {"name": "task", "value": task},
        ]
        if custom_prompt:
            normalized.append({"name": "custom_prompt", "value": custom_prompt})
        return normalized

    if tool_id == "python_executor":
        code = arg_map.get("code")
        return [{"name": "code", "value": code}] if code else None

    return arguments


def parse_annotator_metadata(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return {}
    try:
        return ast.literal_eval(str(value))
    except Exception:
        return {}


def parse_steps(text: Any) -> List[str]:
    """
    Parse Annotator Metadata['Steps'] into exact semantic substeps without paraphrase.

    Handles two common formats:
    - multiline numbered lines: "1. ...\\n2. ..."
    - inline "Step 1: ... Step 2: ..."
    """
    if text is None:
        return []
    raw = str(text).strip()
    if not raw:
        return []

    if STEP_INLINE_PATTERN.search(raw):
        matches = list(STEP_MARKER_PATTERN.finditer(raw))
        items: List[str] = []
        for i, match in enumerate(matches):
            start = match.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(raw)
            chunk = _normalize_ws(raw[start:end])
            if chunk:
                items.append(chunk)
        return items

    lines = [line.rstrip() for line in raw.splitlines() if line.strip()]
    items: List[str] = []
    current: Optional[str] = None
    for line in lines:
        match = LINE_NUMBER_PATTERN.match(line)
        if match:
            if current is not None:
                items.append(_normalize_ws(current))
            current = match.group(2)
        else:
            if current is None:
                current = line
            else:
                current += " " + line
    if current is not None:
        items.append(_normalize_ws(current))

    if items:
        return items

    return [_normalize_ws(raw)]


def parse_tools(text: Any) -> List[str]:
    if text is None:
        return []
    raw = str(text).strip()
    if not raw:
        return []

    lines = [line.rstrip() for line in raw.splitlines() if line.strip()]
    items: List[str] = []
    current: Optional[str] = None
    for line in lines:
        match = LINE_NUMBER_PATTERN.match(line)
        if match:
            if current is not None:
                items.append(_normalize_ws(current))
            current = match.group(2)
        else:
            if current is None:
                current = line
            else:
                current += " " + line
    if current is not None:
        items.append(_normalize_ws(current))

    if items:
        return items

    # Fallback for single-line tool strings that still contain simple numbering.
    matches = list(re.finditer(r"(?:^|\s)(\d+)\.\s*", raw))
    if len(matches) > 1:
        parsed: List[str] = []
        for i, match in enumerate(matches):
            start = match.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(raw)
            chunk = _normalize_ws(raw[start:end])
            if chunk:
                parsed.append(chunk)
        return parsed

    return [_normalize_ws(raw)]


def _contains_any(text: str, patterns: Iterable[str]) -> bool:
    lowered = text.casefold()
    return any(p in lowered for p in patterns)


def score_step_for_tool(step_text: str, tool_id: str) -> int:
    text = _normalize_for_match(step_text)
    score = 0

    if tool_id == "audio_transcription":
        if _contains_any(text, ["audio", "transcrib", "speech-to-text", "mp3"]):
            score += 8

    elif tool_id == "image_recognition":
        if _contains_any(text, ["image", "png", "figure", "photo", "ocr", "extract", "red numbers", "green numbers"]):
            score += 8

    elif tool_id == "python_executor":
        if _contains_any(text, ["python", "compiler", "script", "code", "jsonld", "pandas", "dataframe"]):
            score += 8
        if _contains_any(text, ["attached file", "excel", "spreadsheet", "xlsx", "csv", "json file", "open the file"]):
            score += 4

    elif tool_id == "calculator":
        if _contains_any(text, ["calculate", "calculated", "multiply", "multiplied", "divide", "divided", "round", "rounded", "average", "percentage", "convert", "converted", "probability", "mean", "std"]):
            score += 8

    elif tool_id == "web_search":
        if _contains_any(text, ["search", "googled", "google", "duckduckgo", "search engine", "query"]):
            score += 8

    elif tool_id == "web_browser":
        if _contains_any(text, ["open", "opened", "navigate", "go to", "click", "clicked", "scroll", "scrolled", "watch", "watched", "listen", "visited", "visit", "page", "website", "site", "tab", "result", "channel", "pdf"]):
            score += 6

    elif tool_id == "reasoning":
        if _contains_any(text, ["reason", "note", "determine", "identify", "compare", "confirm", "indicating", "thus", "therefore", "this is the answer", "correct answer", "find the title", "find the answer", "store this", "evaluate the page content", "evaluate the transcribed text"]):
            score += 6

    return score


@dataclass
class StepNode:
    node_id: str
    step_index: int
    label: str
    step_type: str
    tool_id: Optional[str]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "step_index": self.step_index,
            "label": self.label,
            "step_type": self.step_type,
            "tool_id": self.tool_id,
        }


def assign_tool_calls_to_steps(
    steps: Sequence[str],
    executable_calls: Sequence[Dict[str, Any]],
) -> Tuple[List[StepNode], List[Dict[str, Any]]]:
    """
    Greedily align executable tool calls back onto original human-written steps.

    The alignment is best-effort and conservative:
    - if no clear step matches a call, the call is attached to the next available step
      to keep node_id references valid
    - nodes without a matched tool remain thought nodes
    """
    nodes = [
        StepNode(
            node_id=f"n{i}",
            step_index=i,
            label=step,
            step_type="thought",
            tool_id=None,
        )
        for i, step in enumerate(steps)
    ]

    used_step_indices: set[int] = set()
    last_index = 0
    rebuilt_calls: List[Dict[str, Any]] = []

    for call_index, original_call in enumerate(executable_calls):
        tool_id = original_call.get("tool_id")
        if not tool_id:
            continue

        best_idx: Optional[int] = None
        best_score = -1

        for idx in range(last_index, len(steps)):
            if idx in used_step_indices:
                continue
            score = score_step_for_tool(steps[idx], tool_id)
            if score > best_score:
                best_score = score
                best_idx = idx

        if best_idx is None:
            continue

        # Conservative fallback: if no semantic signal exists, attach to the next
        # unused step so node_id stays valid without fabricating new labels.
        if best_score <= 0:
            for idx in range(last_index, len(steps)):
                if idx not in used_step_indices:
                    best_idx = idx
                    break
            else:
                for idx in range(len(steps)):
                    if idx not in used_step_indices:
                        best_idx = idx
                        break

        if best_idx is None:
            continue

        used_step_indices.add(best_idx)
        last_index = min(best_idx + 1, len(steps))
        nodes[best_idx].step_type = "tool"
        nodes[best_idx].tool_id = tool_id

        new_call = dict(original_call)
        new_call["call_index"] = len(rebuilt_calls)
        new_call["node_id"] = nodes[best_idx].node_id
        rebuilt_calls.append(new_call)

    return nodes, rebuilt_calls


def build_edges(nodes: Sequence[StepNode]) -> List[Dict[str, Any]]:
    edges: List[Dict[str, Any]] = []
    for i in range(1, len(nodes)):
        edges.append(
            {
                "source": nodes[i - 1].node_id,
                "target": nodes[i].node_id,
                "edge_type": "control_dep",
            }
        )
    return edges


def load_metadata() -> Dict[str, Dict[str, Any]]:
    df = pd.read_parquet(BACKUP_METADATA)
    meta_map: Dict[str, Dict[str, Any]] = {}
    for _, row in df.iterrows():
        annotator = parse_annotator_metadata(row.get("Annotator Metadata"))
        meta_map[str(row["task_id"])] = {
            "steps": parse_steps(annotator.get("Steps", "")),
            "tools": parse_tools(annotator.get("Tools", "")),
            "annotator": annotator,
            "final_answer": row.get("Final answer"),
            "question": row.get("Question"),
            "level": row.get("Level"),
        }
    return meta_map


def rebuild_record(record: Dict[str, Any], metadata_by_id: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    task_id = str(record.get("meta", {}).get("id", ""))
    original = metadata_by_id.get(task_id)
    if original is None:
        raise KeyError(f"Missing original GAIA metadata for task_id={task_id}")

    steps = original["steps"]
    if not steps:
        raise ValueError(f"No Annotator Metadata steps found for task_id={task_id}")

    current_gold = record.get("gold", {})
    current_calls = current_gold.get("tool_calls", [])

    executable_calls = [
        dict(call)
        for call in current_calls
        if call.get("tool_id") != "submit_final_answer"
    ]

    nodes, rebuilt_calls = assign_tool_calls_to_steps(steps, executable_calls)

    normalized_calls: List[Dict[str, Any]] = []
    active_node_ids: set[str] = set()
    for call in rebuilt_calls:
        node_id = call["node_id"]
        node = next(node for node in nodes if node.node_id == node_id)
        normalized_args = normalize_call_arguments(
            call["tool_id"],
            node.label,
            call.get("arguments", []),
        )
        if not normalized_args:
            continue
        new_call = dict(call)
        new_call["call_index"] = len(normalized_calls)
        new_call["arguments"] = normalized_args
        normalized_calls.append(new_call)
        active_node_ids.add(node_id)

    for node in nodes:
        if node.node_id in active_node_ids:
            matched = next(call for call in normalized_calls if call["node_id"] == node.node_id)
            node.step_type = "tool"
            node.tool_id = matched["tool_id"]
        else:
            node.step_type = "thought"
            node.tool_id = None

    edges = build_edges(nodes)

    current_gold["plan_dag"] = {
        "nodes": [node.as_dict() for node in nodes],
        "edges": edges,
    }
    current_gold["tool_calls"] = normalized_calls

    # Preserve final answer as-is, but do not allow submit_final_answer to leak
    # into the structural/tool gold used for planning evaluation.
    record["gold"] = current_gold
    record["meta"]["plan_type"] = "chain"
    record["meta"]["has_arguments"] = bool(rebuilt_calls and any(call.get("arguments") for call in rebuilt_calls))
    record["meta"]["has_answer"] = True
    return record


def rebuild_file(input_path: Path, output_path: Path, metadata_by_id: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    records = json.loads(input_path.read_text())
    rebuilt = [rebuild_record(record, metadata_by_id) for record in records]

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(rebuilt, ensure_ascii=False, indent=2) + "\n")

    total = len(rebuilt)
    total_nodes = sum(len(rec["gold"]["plan_dag"]["nodes"]) for rec in rebuilt)
    total_calls = sum(len(rec["gold"]["tool_calls"]) for rec in rebuilt)
    submit_nodes = sum(
        1
        for rec in rebuilt
        for node in rec["gold"]["plan_dag"]["nodes"]
        if node.get("tool_id") == "submit_final_answer"
    )
    submit_calls = sum(
        1
        for rec in rebuilt
        for call in rec["gold"]["tool_calls"]
        if call.get("tool_id") == "submit_final_answer"
    )
    answer_matches = 0
    for rec in rebuilt:
        task_id = str(rec["meta"]["id"])
        answer = rec["gold"]["final_answer"]["answer"]
        if str(answer) == str(metadata_by_id[task_id]["final_answer"]):
            answer_matches += 1

    return {
        "path": str(output_path),
        "records": total,
        "total_nodes": total_nodes,
        "total_tool_calls": total_calls,
        "submit_nodes": submit_nodes,
        "submit_calls": submit_calls,
        "final_answer_exact_matches": answer_matches,
    }


def main() -> None:
    metadata_by_id = load_metadata()

    # Safety backups for the primary data files before replacement.
    for data_path, _ in GAIA_DATASETS:
        backup_path = data_path.with_suffix(data_path.suffix + ".bak_before_annotator_gt_fix")
        if not backup_path.exists():
            shutil.copy2(data_path, backup_path)

    summaries = []
    for data_path, mirror_path in GAIA_DATASETS:
        summary = rebuild_file(data_path, data_path, metadata_by_id)
        summaries.append(summary)
        rebuild_file(data_path, mirror_path, metadata_by_id)

    print("Rebuilt GAIA files:")
    for summary in summaries:
        print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
