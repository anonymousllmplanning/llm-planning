#!/usr/bin/env python3
"""
Merge gold and prediction files for evaluation.

Usage:
    python merge_gold_pred.py \
        --gold gaia.mini.func/data/gaia_mini.jsonl \
        --pred results_artifacts/qwen2.5-7b.jsonl \
        --output results_artifacts/qwen2.5-7b_merged.jsonl
"""
import json
import argparse
from pathlib import Path
from typing import Dict, Any


def load_jsonl(path: Path):
    """Load JSONL file as a dictionary keyed by task_id."""
    data = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            record = json.loads(line)
            task_id = record.get("task_id")
            if task_id:
                data[task_id] = record
    return data


def convert_gold_format(gold_record: Dict[str, Any]) -> Dict[str, Any]:
    """Convert GAIA gold format to evaluation format."""
    # Extract annotator metadata
    annotator = gold_record.get("Annotator Metadata", {})
    tools = annotator.get("Tools", [])
    if isinstance(tools, str):
        try:
            tools = json.loads(tools)
        except:
            tools = []
    
    tool_args = annotator.get("Tool Arguments", [])
    
    # Build plan_dag from annotator steps
    nodes = []
    edges = []
    
    # Convert tool arguments to nodes
    for i, tool_arg in enumerate(tool_args, 1):
        tool_name = tool_arg.get("tool", "unknown")
        node = {
            "id": f"step_{i}",
            "description": f"Use {tool_name}",
            "tool_used": tool_name,
            "thought": ""
        }
        nodes.append(node)
        
        # Add sequential edges
        if i > 1:
            edges.append({
                "from": f"step_{i-1}",
                "to": f"step_{i}"
            })
    
    # Build tool_calls from tool arguments
    tool_calls = []
    for tool_arg in tool_args:
        tool_name = tool_arg.get("tool", "unknown")
        arguments = tool_arg.get("arguments", [])
        
        # Convert arguments to proper format
        arg_list = []
        for arg in arguments:
            arg_list.append({
                "name": arg.get("name", ""),
                "value": arg.get("value", "")
            })
        
        tool_calls.append({
            "tool_id": tool_name,
            "arguments": arg_list
        })
    
    # Return unified gold format
    return {
        "plan_dag": {
            "nodes": nodes,
            "edges": edges
        },
        "tool_calls": tool_calls,
        "final_answer": {
            "answer_type": "string",
            "answer": gold_record.get("Final answer", "")
        }
    }


def merge_records(gold_path: Path, pred_path: Path, output_path: Path):
    """Merge gold and prediction files."""
    print(f"Loading gold file: {gold_path}")
    gold_data = load_jsonl(gold_path)
    print(f"  Found {len(gold_data)} gold records")
    
    print(f"Loading prediction file: {pred_path}")
    pred_data = load_jsonl(pred_path)
    print(f"  Found {len(pred_data)} prediction records")
    
    # Merge records
    merged_count = 0
    with open(output_path, 'w') as out_f:
        for task_id, pred_record in pred_data.items():
            if task_id not in gold_data:
                print(f"  [WARN] No gold record for task_id: {task_id}")
                continue
            
            gold_record = gold_data[task_id]
            
            # Convert gold to evaluation format
            gold_eval = convert_gold_format(gold_record)
            
            # Extract metadata
            meta = {
                "id": task_id,
                "dataset": "gaia",
                "subset": f"level_{gold_record.get('Level', '1')}",
                "has_arguments": True,  # GAIA has tool arguments
                "question": gold_record.get("Question", ""),
                "file_path": gold_record.get("file_path", "")
            }
            
            # Create merged record
            merged = {
                "gold": gold_eval,
                "pred": {
                    "plan_dag": pred_record.get("plan_dag", {}),
                    "tool_calls": pred_record.get("tool_calls", []),
                    "final_answer": pred_record.get("final_answer", {})
                },
                "meta": meta
            }
            
            out_f.write(json.dumps(merged, ensure_ascii=False) + '\n')
            merged_count += 1
    
    print(f"✅ Merged {merged_count} records to: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Merge gold and prediction files")
    parser.add_argument("--gold", type=Path, required=True, help="Gold JSONL file")
    parser.add_argument("--pred", type=Path, required=True, help="Prediction JSONL file")
    parser.add_argument("--output", type=Path, required=True, help="Output merged JSONL file")
    
    args = parser.parse_args()
    
    merge_records(args.gold, args.pred, args.output)


if __name__ == "__main__":
    main()
