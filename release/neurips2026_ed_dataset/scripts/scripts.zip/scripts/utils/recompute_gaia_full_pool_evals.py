#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.evaluation.runner import PerSampleResult, _load_gold_records, evaluate_file
from src.evaluation.utils import write_csv


OUTPUT_DIR = REPO_ROOT / "organized_results" / "analysis" / "gaia_full_pool_recomputed_20260420"

RUNS: Dict[str, Dict[str, Path]] = {
    "Llama-4-Maverick-17B-128E-Instruct-FP8": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_183013.gaia_cat_A.answer/Llama-4-Maverick-17B-128E-Instruct-FP8/unified.Llama-4-Maverick-17B-128E-Instruct-FP8.jsonl",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_002720.gaia_cat_B.answer/Llama-4-Maverick-17B-128E-Instruct-FP8/unified.Llama-4-Maverick-17B-128E-Instruct-FP8.jsonl",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_005708.gaia_cat_C.answer/Llama-4-Maverick-17B-128E-Instruct-FP8/unified.Llama-4-Maverick-17B-128E-Instruct-FP8.jsonl",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_012447.gaia_cat_D.answer/Llama-4-Maverick-17B-128E-Instruct-FP8/unified.Llama-4-Maverick-17B-128E-Instruct-FP8.jsonl",
    },
    "Llama-3.3-Nemotron-Super-49B-v1": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_185156.gaia_cat_A.answer/Llama-3.3-Nemotron-Super-49B-v1/unified.Llama-3.3-Nemotron-Super-49B-v1.jsonl",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_061147.gaia_cat_B.answer/Llama-3.3-Nemotron-Super-49B-v1/unified.Llama-3.3-Nemotron-Super-49B-v1.jsonl",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_075320.gaia_cat_C.answer/Llama-3.3-Nemotron-Super-49B-v1/unified.Llama-3.3-Nemotron-Super-49B-v1.jsonl",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_084007.gaia_cat_D.answer/Llama-3.3-Nemotron-Super-49B-v1/unified.Llama-3.3-Nemotron-Super-49B-v1.jsonl",
    },
    "Llama-3.3-70B-Instruct": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_184507.gaia_cat_A.answer/Llama-3.3-70B-Instruct/unified.Llama-3.3-70B-Instruct.jsonl",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_005117.gaia_cat_B.answer/Llama-3.3-70B-Instruct/unified.Llama-3.3-70B-Instruct.jsonl",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_012532.gaia_cat_C.answer/Llama-3.3-70B-Instruct/unified.Llama-3.3-70B-Instruct.jsonl",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_015238.gaia_cat_D.answer/Llama-3.3-70B-Instruct/unified.Llama-3.3-70B-Instruct.jsonl",
    },
    "gpt-oss-120b": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_183211.gaia_cat_A.answer/gpt-oss-120b/unified.gpt-oss-120b.jsonl",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260418_194347.gaia_cat_B.answer/gpt-oss-120b/unified.gpt-oss-120b.jsonl",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260418_195611.gaia_cat_C.answer/gpt-oss-120b/unified.gpt-oss-120b.jsonl",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260418_202600.gaia_cat_D.answer/gpt-oss-120b/unified.gpt-oss-120b.jsonl",
    },
    "gpt-oss-20b": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_183318.gaia_cat_A.answer/gpt-oss-20b/unified.gpt-oss-20b.jsonl",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260418_203228.gaia_cat_B.answer/gpt-oss-20b/unified.gpt-oss-20b.jsonl",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260418_205135.gaia_cat_C.answer/gpt-oss-20b/unified.gpt-oss-20b.jsonl",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260418_214230.gaia_cat_D.answer/gpt-oss-20b/unified.gpt-oss-20b.jsonl",
    },
    "Mistral-Small-3.2-24B-Instruct-2506": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_183249.gaia_cat_A.answer/Mistral-Small-3.2-24B-Instruct-2506/unified.Mistral-Small-3.2-24B-Instruct-2506.jsonl",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_093046.gaia_cat_B.answer/Mistral-Small-3.2-24B-Instruct-2506/unified.Mistral-Small-3.2-24B-Instruct-2506.jsonl",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_101302.gaia_cat_C.answer/Mistral-Small-3.2-24B-Instruct-2506/unified.Mistral-Small-3.2-24B-Instruct-2506.jsonl",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_104958.gaia_cat_D.answer/Mistral-Small-3.2-24B-Instruct-2506/unified.Mistral-Small-3.2-24B-Instruct-2506.jsonl",
    },
    "gemma-3-12b-it": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_185120.gaia_cat_A.answer/gemma-3-12b-it/unified.gemma-3-12b-it.jsonl",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_002448.gaia_cat_B.answer/gemma-3-12b-it/unified.gemma-3-12b-it.jsonl",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_005822.gaia_cat_C.answer/gemma-3-12b-it/unified.gemma-3-12b-it.jsonl",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_012210.gaia_cat_D.answer/gemma-3-12b-it/unified.gemma-3-12b-it.jsonl",
    },
}

GOLD_DATASET = {
    "A": REPO_ROOT / "data.hg/GAIA/cat_A_text/gaia.cat_A.json",
    "B": REPO_ROOT / "data.hg/GAIA/cat_B_document/gaia.cat_B.json",
    "C": REPO_ROOT / "data.hg/GAIA/cat_C_vision/gaia.cat_C.json",
    "D": REPO_ROOT / "data.hg/GAIA/cat_D_audio/gaia.cat_D.json",
}


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    manifest: Dict[str, Any] = {"runs": {}}
    gold_cache = {cat: _load_gold_records(path) for cat, path in GOLD_DATASET.items()}

    for model, cats in RUNS.items():
        manifest["runs"][model] = {}
        for cat, input_path in cats.items():
            results, summary = evaluate_file(
                input_path,
                use_embeddings=False,
                gold_records_by_id=gold_cache[cat],
                verifier_model=None,
            )
            out_csv = OUTPUT_DIR / f"per_sample.{model}.{cat}.csv"
            out_json = OUTPUT_DIR / f"summary.{model}.{cat}.json"
            write_csv(results, out_csv, PerSampleResult)
            with out_json.open("w") as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            manifest["runs"][model][cat] = {
                "input": str(input_path),
                "per_sample": str(out_csv),
                "summary": str(out_json),
            }

    with (OUTPUT_DIR / "manifest.json").open("w") as f:
        json.dump(manifest, f, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    main()
