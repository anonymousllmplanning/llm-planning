#!/usr/bin/env python3
"""
Build a balanced TaskBench subset stratified by subset x plan_type.

Example:
    python scripts/utils/build_taskbench_balanced_subset.py \
        --input data.hg/Taskbench/unified_taskbench_all.jsonl \
        --output data.hg/Taskbench/unified_taskbench_order_chain300_dag300.jsonl \
        --per_cell 100
"""

from __future__ import annotations

import argparse
import json
import random
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a balanced TaskBench subset.")
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--per_cell", type=int, default=100, help="Samples per (subset, plan_type) cell.")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    rng = random.Random(args.seed)
    buckets: Dict[Tuple[str, str], List[dict]] = defaultdict(list)

    with args.input.open() as f:
        for line in f:
            rec = json.loads(line)
            meta = rec.get("meta", {}) or {}
            subset = str(meta.get("subset", "unknown"))
            plan_type = str(meta.get("plan_type", "unknown"))
            buckets[(subset, plan_type)].append(rec)

    selected: List[dict] = []
    for key in sorted(buckets.keys()):
        rows = list(buckets[key])
        rng.shuffle(rows)
        if len(rows) < args.per_cell:
            raise ValueError(f"Cell {key} only has {len(rows)} samples, fewer than requested {args.per_cell}")
        selected.extend(rows[:args.per_cell])

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w") as f:
        for rec in selected:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

    print(f"[OK] Wrote {len(selected)} samples to {args.output}")
    for key in sorted(buckets.keys()):
        print(f"  {key}: {args.per_cell}")


if __name__ == "__main__":
    main()
