#!/usr/bin/env python3
"""Compare prior-style graph metrics with SpanNodeF1 + OrderF1 on GAIA.

This script evaluates the same model predictions against two reference layers:

1. GAIA-chain: the original chain reference under data.hg/GAIA.
2. Augmented GAIA: the original chain plus the dependency DAG from
   Asynchronous/gaia_cat_*_async_plan.jsonl.

Metric families:

* prior-style planning = (strict_node_f1 + semantic_edge_f1) / 2
* proposed planning = (span_node_f1 + dw_order_f1) / 2

The augmented score keeps the original chain as one candidate reference and the
dependency DAG as the other candidate reference. Each metric family is allowed
to choose its best reference, and the chosen reference family is reported.
"""

from __future__ import annotations

import argparse
import copy
import glob
import json
import re
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.evaluation.metrics import ASTEvaluationSystem  # noqa: E402


CATEGORY_META = {
    "A": {
        "name": "Text Reasoning",
        "chain_path": "data.hg/GAIA/cat_A_text/gaia.cat_A.json",
        "async_path": "Asynchronous/gaia_cat_A_async_plan.jsonl",
    },
    "B": {
        "name": "Document Analysis",
        "chain_path": "data.hg/GAIA/cat_B_document/gaia.cat_B.json",
        "async_path": "Asynchronous/gaia_cat_B_async_plan.jsonl",
    },
    "C": {
        "name": "Vision",
        "chain_path": "data.hg/GAIA/cat_C_vision/gaia.cat_C.json",
        "async_path": "Asynchronous/gaia_cat_C_async_plan.jsonl",
    },
    "D": {
        "name": "Audio",
        "chain_path": "data.hg/GAIA/cat_D_audio/gaia.cat_D.json",
        "async_path": "Asynchronous/gaia_cat_D_async_plan.jsonl",
    },
}

MODEL_ALIASES = {
    "Gemma-3-27B": "Google-Gemma-3-27B",
    "Llama-3.3-70B": "Llama-3.3-70B-Instruct",
    "Llama-4": "Llama-4-Maverick-17B-128E-Instruct-FP8",
    "Mistral-Large": "Mistral-Large-3-675B-Instruct-2512",
    "Mistral-Small": "Mistral-Small-3.2-24B-Instruct-2506",
    "gemma-4-31B": "gemma-4-31B-it",
    "gpt-oss-120b": "gpt-oss-120b",
    "gpt-oss-20b": "gpt-oss-20b",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--results-root",
        type=Path,
        default=REPO_ROOT / "organized_results/gaia/0427",
        help="Root containing unified.*.jsonl result files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REPO_ROOT / "runtime_artifacts/prior_vs_span_order_gaia_augmented_20260428",
        help="Directory for CSVs and figures.",
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=REPO_ROOT,
        help="Repository root used to resolve gold-reference paths.",
    )
    parser.add_argument(
        "--ats-threshold",
        type=float,
        default=0.5,
        help="ATS threshold for the optional tool-clean correlation slice.",
    )
    parser.add_argument(
        "--tisr-threshold",
        type=float,
        default=0.7,
        help="TISR threshold for the optional tool-clean correlation slice.",
    )
    parser.add_argument(
        "--attachment-dense-threshold",
        type=int,
        default=2,
        help="Gold tool count threshold for the attachment-intensive slice.",
    )
    return parser.parse_args()


def iter_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                yield json.loads(line)


def record_id(record: Dict[str, Any]) -> str:
    return (
        (record.get("meta") or {}).get("id")
        or record.get("id")
        or record.get("sample_id")
        or ""
    )


def category_from_subset(subset: str) -> str:
    suffix = str(subset or "").split("_")[-1]
    return suffix if suffix in CATEGORY_META else ""


def load_gold_references(repo_root: Path) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    chain_gold: Dict[str, Any] = {}
    async_gold: Dict[str, Any] = {}
    for meta in CATEGORY_META.values():
        chain_path = repo_root / meta["chain_path"]
        async_path = repo_root / meta["async_path"]
        with open(chain_path, "r", encoding="utf-8") as handle:
            for record in json.load(handle):
                chain_gold[record_id(record)] = record
        for record in iter_jsonl(async_path):
            async_gold[record_id(record)] = record
    return chain_gold, async_gold


def dependency_dag_from_async_record(record: Dict[str, Any]) -> Dict[str, Any]:
    """Build the augmented dependency DAG while reusing original gold nodes."""
    chain_dag = copy.deepcopy((record.get("gold") or {}).get("plan_dag") or {})
    nodes = chain_dag.get("nodes") or []
    sorted_nodes = sorted(
        enumerate(nodes),
        key=lambda item: (item[1].get("step_index", item[0]), item[0]),
    )
    step_to_node_id = {
        local_idx: node.get("node_id", f"n{local_idx}")
        for local_idx, (_, node) in enumerate(sorted_nodes)
    }
    edges: List[Dict[str, Any]] = []
    for edge in (record.get("dependency_analysis") or {}).get("edges") or []:
        if edge.get("from") is None or edge.get("to") is None:
            continue
        source_step = int(edge["from"])
        target_step = int(edge["to"])
        edge_types = edge.get("types") or []
        edges.append(
            {
                "source": step_to_node_id.get(source_step, f"n{source_step}"),
                "target": step_to_node_id.get(target_step, f"n{target_step}"),
                "edge_type": "+".join(edge_types) if edge_types else "dependency",
            }
        )
    return {"nodes": nodes, "edges": edges}


def pack_plan_scores(scores: Any) -> Dict[str, float]:
    packed = asdict(scores)
    packed["prior_node_f1"] = packed["strict_node_f1"]
    packed["prior_edge_f1"] = packed["semantic_edge_f1"]
    packed["prior_planning_score"] = (
        packed["prior_node_f1"] + packed["prior_edge_f1"]
    ) / 2.0
    packed["proposed_span_node_f1"] = packed["span_node_f1"]
    packed["proposed_order_f1"] = packed["dw_order_f1"]
    packed["proposed_planning_score"] = (
        packed["proposed_span_node_f1"] + packed["proposed_order_f1"]
    ) / 2.0
    return packed


def choose_best_reference(
    scored_refs: List[Tuple[str, Dict[str, float]]],
    metric_key: str,
) -> Tuple[str, Dict[str, float]]:
    # Prefer the original chain in exact ties to keep the original GAIA reference
    # primary unless the augmented dependency DAG actually improves the score.
    ref_preference = {"chain": 0, "dag": 1}
    return max(
        scored_refs,
        key=lambda item: (item[1][metric_key], -ref_preference.get(item[0], 99)),
    )


def collect_prediction_rows(
    results_root: Path,
    chain_gold: Dict[str, Any],
    async_gold: Dict[str, Any],
    evaluator: ASTEvaluationSystem,
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    unified_paths = sorted(
        path
        for path in glob.glob(str(results_root / "**/unified.*.jsonl"), recursive=True)
        if "/tool_creation_log." not in path
    )
    if not unified_paths:
        raise FileNotFoundError(f"No unified.*.jsonl files found under {results_root}")

    for path_string in unified_paths:
        path = Path(path_string)
        for record in iter_jsonl(path):
            meta = record.get("meta") or {}
            sample_id = meta.get("id")
            if sample_id not in chain_gold:
                raise KeyError(f"Missing GAIA-chain gold for sample {sample_id}")
            if sample_id not in async_gold:
                raise KeyError(f"Missing Augmented-GAIA gold for sample {sample_id}")

            model = meta.get("model_name")
            subset = meta.get("subset", "")
            category_code = category_from_subset(subset)
            category_name = CATEGORY_META.get(category_code, {}).get("name", "")
            pred_dag = (record.get("pred") or {}).get("plan_dag") or {
                "nodes": [],
                "edges": [],
            }

            gaia_chain_dag = copy.deepcopy(chain_gold[sample_id]["gold"]["plan_dag"])
            augmented_chain_dag = copy.deepcopy(async_gold[sample_id]["gold"]["plan_dag"])
            augmented_dependency_dag = dependency_dag_from_async_record(async_gold[sample_id])

            gaia_scores = pack_plan_scores(
                evaluator.evaluate_plan_dag(gaia_chain_dag, pred_dag, dataset="gaia")
            )
            augmented_candidates = [
                (
                    "chain",
                    pack_plan_scores(
                        evaluator.evaluate_plan_dag(
                            augmented_chain_dag,
                            pred_dag,
                            dataset="gaia",
                        )
                    ),
                ),
                (
                    "dag",
                    pack_plan_scores(
                        evaluator.evaluate_plan_dag(
                            augmented_dependency_dag,
                            pred_dag,
                            dataset="gaia",
                        )
                    ),
                ),
            ]
            prior_ref, prior_scores = choose_best_reference(
                augmented_candidates,
                "prior_planning_score",
            )
            proposed_ref, proposed_scores = choose_best_reference(
                augmented_candidates,
                "proposed_planning_score",
            )

            rows.append(
                {
                    "sample_id": sample_id,
                    "sample_prefix": str(sample_id)[:8],
                    "model": model,
                    "subset": subset,
                    "category_code": category_code,
                    "category": category_name,
                    "pred_node_count": len(pred_dag.get("nodes") or []),
                    "pred_edge_count": len(pred_dag.get("edges") or []),
                    "chain_edge_count": len(gaia_chain_dag.get("edges") or []),
                    "aug_dag_edge_count": len(
                        augmented_dependency_dag.get("edges") or []
                    ),
                    "gaia_prior_node_f1": gaia_scores["prior_node_f1"],
                    "gaia_prior_edge_f1": gaia_scores["prior_edge_f1"],
                    "gaia_prior_planning_score": gaia_scores["prior_planning_score"],
                    "gaia_span_node_f1": gaia_scores["proposed_span_node_f1"],
                    "gaia_order_f1": gaia_scores["proposed_order_f1"],
                    "gaia_proposed_planning_score": gaia_scores[
                        "proposed_planning_score"
                    ],
                    "aug_prior_node_f1": prior_scores["prior_node_f1"],
                    "aug_prior_edge_f1": prior_scores["prior_edge_f1"],
                    "aug_prior_planning_score": prior_scores[
                        "prior_planning_score"
                    ],
                    "aug_prior_best_ref_family": prior_ref,
                    "aug_span_node_f1": proposed_scores["proposed_span_node_f1"],
                    "aug_order_f1": proposed_scores["proposed_order_f1"],
                    "aug_proposed_planning_score": proposed_scores[
                        "proposed_planning_score"
                    ],
                    "aug_proposed_best_ref_family": proposed_ref,
                }
            )
    return pd.DataFrame(rows)


def attach_human_eval(results_root: Path, per_sample: pd.DataFrame) -> pd.DataFrame:
    labels: List[Dict[str, Any]] = []
    for path_string in glob.glob(str(results_root / "**/answer_review.*.xlsx"), recursive=True):
        path = Path(path_string)
        try:
            review = pd.read_excel(path)
        except Exception as exc:
            print(f"[WARN] Could not read {path}: {exc}")
            continue
        lower_to_col = {str(col).strip().lower(): col for col in review.columns}
        required = {"sample_id", "model_name", "human eval"}
        if not required <= set(lower_to_col):
            continue
        for _, row in review.iterrows():
            sample_prefix = str(row[lower_to_col["sample_id"]]).replace("...", "")[:8]
            raw_model = str(row[lower_to_col["model_name"]])
            model = MODEL_ALIASES.get(raw_model, raw_model)
            verdict = str(row[lower_to_col["human eval"]]).strip().lower()
            if verdict in {"y", "yes", "1", "true", "correct"}:
                solve = 1.0
            elif verdict in {"n", "nn", "no", "0", "false", "wrong"}:
                solve = 0.0
            else:
                solve = float("nan")
            labels.append(
                {
                    "sample_prefix": sample_prefix,
                    "model": model,
                    "human_eval_solve": solve,
                }
            )

    if not labels:
        return per_sample

    label_df = pd.DataFrame(labels).drop_duplicates(["sample_prefix", "model"])
    merged = per_sample.merge(label_df, on=["sample_prefix", "model"], how="left")
    missing = int(merged["human_eval_solve"].isna().sum())
    if missing:
        print(f"[WARN] Missing Human Eval labels for {missing}/{len(merged)} rows")
    return merged


def attach_tool_clean(results_root: Path, per_sample: pd.DataFrame) -> pd.DataFrame:
    tool_rows: List[pd.DataFrame] = []
    for path_string in glob.glob(str(results_root / "**/per_sample.*.csv"), recursive=True):
        path = Path(path_string)
        model = path.name[len("per_sample.") : -len(".csv")]
        df = pd.read_csv(path)
        cols = [
            "sample_id",
            "gt_aligned_tool_success_rate",
            "pred_exec_success_rate",
            "tool_usage_score",
            "parse_error",
            "gold_tool_count",
            "pred_tool_count",
        ]
        keep = [col for col in cols if col in df.columns]
        if "sample_id" not in keep:
            continue
        part = df[keep].copy()
        part["model"] = model
        tool_rows.append(part)
    if not tool_rows:
        return per_sample
    tool_df = pd.concat(tool_rows, ignore_index=True).drop_duplicates(
        ["sample_id", "model"]
    )
    return per_sample.merge(tool_df, on=["sample_id", "model"], how="left")


def summarize_metrics(df: pd.DataFrame, group_cols: List[str]) -> pd.DataFrame:
    metric_cols = [
        "gaia_prior_planning_score",
        "gaia_prior_node_f1",
        "gaia_prior_edge_f1",
        "gaia_proposed_planning_score",
        "gaia_span_node_f1",
        "gaia_order_f1",
        "aug_prior_planning_score",
        "aug_prior_node_f1",
        "aug_prior_edge_f1",
        "aug_proposed_planning_score",
        "aug_span_node_f1",
        "aug_order_f1",
        "gaia_proposed_minus_prior",
        "aug_proposed_minus_prior",
        "proposed_aug_minus_gaia",
        "prior_aug_minus_gaia",
    ]
    if not group_cols:
        row: Dict[str, Any] = {"n": len(df)}
        for col in metric_cols:
            row[col] = df[col].mean()
        if "human_eval_solve" in df.columns:
            row["human_eval_solve_rate"] = df["human_eval_solve"].mean()
        return pd.DataFrame([row])

    agg_spec = {col: (col, "mean") for col in metric_cols}
    agg_spec["n"] = ("sample_id", "count")
    if "human_eval_solve" in df.columns:
        agg_spec["human_eval_solve_rate"] = ("human_eval_solve", "mean")
    return df.groupby(group_cols, as_index=False).agg(**agg_spec)


def compute_correlations(df: pd.DataFrame) -> pd.DataFrame:
    try:
        from scipy.stats import pearsonr, spearmanr
    except Exception as exc:
        print(f"[WARN] scipy unavailable; skipping correlations: {exc}")
        return pd.DataFrame()

    if "human_eval_solve" not in df.columns:
        return pd.DataFrame()

    metric_cols = [
        "gaia_prior_planning_score",
        "gaia_proposed_planning_score",
        "aug_prior_planning_score",
        "aug_proposed_planning_score",
    ]
    rows: List[Dict[str, Any]] = []
    subset_masks = {
        "All predictions": pd.Series(True, index=df.index),
    }
    if {
        "parse_error",
        "gt_aligned_tool_success_rate",
        "pred_exec_success_rate",
    } <= set(df.columns):
        tool_clean = (
            (df["parse_error"].fillna(False) == False)  # noqa: E712
            & (df["gt_aligned_tool_success_rate"] >= df.attrs["ats_threshold"])
            & (df["pred_exec_success_rate"] >= df.attrs["tisr_threshold"])
        )
        subset_masks["Main tool-clean"] = tool_clean
        if "gold_tool_count" in df.columns:
            subset_masks["Attachment-intensive clean"] = (
                tool_clean
                & df["category"].isin(["Document Analysis", "Vision", "Audio"])
                & (df["gold_tool_count"] >= df.attrs["attachment_dense_threshold"])
            )

    for subset_name, mask in subset_masks.items():
        sub = df[mask].copy()
        model_summary = sub.groupby("model", as_index=False).agg(
            n=("sample_id", "count"),
            solve_rate=("human_eval_solve", "mean"),
            **{col: (col, "mean") for col in metric_cols},
        )
        for metric in metric_cols:
            valid = model_summary[[metric, "solve_rate"]].dropna()
            row = {
                "subset": subset_name,
                "retained_predictions": len(sub),
                "models": len(valid),
                "metric": metric,
                "mean_metric": sub[metric].mean(),
                "solve_rate": sub["human_eval_solve"].mean(),
            }
            if len(valid) >= 3:
                pearson = pearsonr(valid[metric], valid["solve_rate"])
                spearman = spearmanr(valid[metric], valid["solve_rate"])
                row.update(
                    {
                        "pearson_r": pearson.statistic,
                        "pearson_p": pearson.pvalue,
                        "spearman_rho": spearman.statistic,
                        "spearman_p": spearman.pvalue,
                    }
                )
            rows.append(row)
    return pd.DataFrame(rows)


def safe_slug(text: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_").lower()


def write_figures(out_dir: Path, overall: pd.DataFrame, model_summary: pd.DataFrame) -> None:
    try:
        import matplotlib.pyplot as plt
        import numpy as np
    except Exception as exc:
        print(f"[WARN] matplotlib unavailable; skipping figures: {exc}")
        return

    plt.rcParams.update({"font.size": 9, "axes.titlesize": 10, "axes.labelsize": 9})
    vals = [
        overall.loc[0, "gaia_prior_planning_score"],
        overall.loc[0, "gaia_proposed_planning_score"],
        overall.loc[0, "aug_prior_planning_score"],
        overall.loc[0, "aug_proposed_planning_score"],
    ]
    labels = [
        "GAIA\nprior-style",
        "GAIA\nSpan+Order",
        "Augmented\nprior-style",
        "Augmented\nSpan+Order",
    ]
    colors = ["#8d99ae", "#168aad", "#b08968", "#2d9d78"]
    fig, ax = plt.subplots(figsize=(6.8, 3.8))
    bars = ax.bar(labels, vals, color=colors)
    ax.set_ylabel("Mean planning score")
    ax.set_title("Prior-style aligned baseline vs SpanNodeF1 + OrderF1")
    ax.set_ylim(0, max(vals) * 1.22 if vals else 1.0)
    for bar, val in zip(bars, vals):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            bar.get_height() + 0.006,
            f"{val:.3f}",
            ha="center",
            va="bottom",
        )
    fig.tight_layout()
    fig.savefig(out_dir / "overall_prior_vs_span_order_bars.png", dpi=220)
    fig.savefig(out_dir / "overall_prior_vs_span_order_bars.pdf")
    plt.close(fig)

    display = model_summary.sort_values("aug_proposed_planning_score", ascending=False)
    x = np.arange(len(display))
    fig, ax = plt.subplots(figsize=(9.8, 4.6))
    ax.plot(
        x,
        display["gaia_prior_planning_score"],
        marker="o",
        label="GAIA prior-style",
        color="#6c757d",
    )
    ax.plot(
        x,
        display["gaia_proposed_planning_score"],
        marker="o",
        label="GAIA Span+Order",
        color="#168aad",
    )
    ax.plot(
        x,
        display["aug_prior_planning_score"],
        marker="o",
        label="Augmented prior-style",
        color="#b08968",
    )
    ax.plot(
        x,
        display["aug_proposed_planning_score"],
        marker="o",
        label="Augmented Span+Order",
        color="#2d9d78",
    )
    short_names = (
        display["model"]
        .str.replace("-Instruct", "", regex=False)
        .str.replace("-675B", "", regex=False)
        .str.replace("-2506", "", regex=False)
        .str.replace("-FP8", "", regex=False)
    )
    ax.set_xticks(x)
    ax.set_xticklabels(short_names, rotation=25, ha="right", fontsize=8)
    ax.set_ylabel("Mean planning score")
    ax.set_title("Model-level metric comparison")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(ncol=2, fontsize=8)
    fig.tight_layout()
    fig.savefig(out_dir / "model_prior_vs_span_order_lines.png", dpi=220)
    fig.savefig(out_dir / "model_prior_vs_span_order_lines.pdf")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    repo_root = args.repo_root.resolve()
    results_root = args.results_root.resolve()
    out_dir = args.output_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    chain_gold, async_gold = load_gold_references(repo_root)
    print(f"[INFO] Loaded {len(chain_gold)} GAIA-chain gold records")
    print(f"[INFO] Loaded {len(async_gold)} Augmented-GAIA records")

    evaluator = ASTEvaluationSystem(use_embeddings=True)
    per_sample = collect_prediction_rows(results_root, chain_gold, async_gold, evaluator)
    per_sample["gaia_proposed_minus_prior"] = (
        per_sample["gaia_proposed_planning_score"]
        - per_sample["gaia_prior_planning_score"]
    )
    per_sample["aug_proposed_minus_prior"] = (
        per_sample["aug_proposed_planning_score"]
        - per_sample["aug_prior_planning_score"]
    )
    per_sample["proposed_aug_minus_gaia"] = (
        per_sample["aug_proposed_planning_score"]
        - per_sample["gaia_proposed_planning_score"]
    )
    per_sample["prior_aug_minus_gaia"] = (
        per_sample["aug_prior_planning_score"]
        - per_sample["gaia_prior_planning_score"]
    )

    per_sample = attach_human_eval(results_root, per_sample)
    per_sample = attach_tool_clean(results_root, per_sample)
    per_sample.attrs["ats_threshold"] = args.ats_threshold
    per_sample.attrs["tisr_threshold"] = args.tisr_threshold
    per_sample.attrs["attachment_dense_threshold"] = args.attachment_dense_threshold

    per_sample.to_csv(out_dir / "per_sample_prior_vs_span_order.csv", index=False)

    overall = summarize_metrics(per_sample, []).assign(slice="All")
    # Put slice first for readability.
    overall = overall[["slice"] + [col for col in overall.columns if col != "slice"]]
    overall.to_csv(out_dir / "overall_prior_vs_span_order.csv", index=False)

    model_summary = summarize_metrics(per_sample, ["model"]).sort_values(
        "aug_proposed_planning_score",
        ascending=False,
    )
    for col in [
        "gaia_prior_planning_score",
        "gaia_proposed_planning_score",
        "aug_prior_planning_score",
        "aug_proposed_planning_score",
    ]:
        model_summary[f"{col}_rank_desc"] = (
            model_summary[col].rank(ascending=False, method="min").astype(int)
        )
    model_summary.to_csv(out_dir / "model_summary_prior_vs_span_order.csv", index=False)

    category_summary = summarize_metrics(per_sample, ["category"]).sort_values("category")
    category_summary.to_csv(
        out_dir / "category_summary_prior_vs_span_order.csv",
        index=False,
    )

    ref_counts = pd.concat(
        [
            per_sample["aug_prior_best_ref_family"]
            .value_counts()
            .rename_axis("ref_family")
            .reset_index(name="count")
            .assign(metric_family="prior_style"),
            per_sample["aug_proposed_best_ref_family"]
            .value_counts()
            .rename_axis("ref_family")
            .reset_index(name="count")
            .assign(metric_family="span_order"),
        ],
        ignore_index=True,
    )
    ref_counts.to_csv(out_dir / "augmented_best_ref_family_counts.csv", index=False)

    correlations = compute_correlations(per_sample)
    if not correlations.empty:
        correlations.to_csv(out_dir / "model_level_human_eval_correlations.csv", index=False)
        if {
            "parse_error",
            "gt_aligned_tool_success_rate",
            "pred_exec_success_rate",
        } <= set(per_sample.columns):
            tool_clean_mask = (
                (per_sample["parse_error"].fillna(False) == False)  # noqa: E712
                & (per_sample["gt_aligned_tool_success_rate"] >= args.ats_threshold)
                & (per_sample["pred_exec_success_rate"] >= args.tisr_threshold)
            )
            subset_specs = [("tool_clean", tool_clean_mask)]
            if "gold_tool_count" in per_sample.columns:
                subset_specs.append(
                    (
                        "attachment_intensive_clean",
                        tool_clean_mask
                        & per_sample["category"].isin(
                            ["Document Analysis", "Vision", "Audio"]
                        )
                        & (per_sample["gold_tool_count"] >= args.attachment_dense_threshold),
                    )
                )
            for subset_name, mask in subset_specs:
                summarize_metrics(per_sample[mask].copy(), ["model"]).to_csv(
                    out_dir / f"model_summary_{safe_slug(subset_name)}.csv",
                    index=False,
                )

    write_figures(out_dir, overall, model_summary)

    print("\n[OVERALL]")
    print(overall.round(4).to_string(index=False))
    print("\n[MODEL SUMMARY]")
    display_cols = [
        "model",
        "n",
        "gaia_prior_planning_score",
        "gaia_proposed_planning_score",
        "aug_prior_planning_score",
        "aug_proposed_planning_score",
        "gaia_proposed_minus_prior",
        "aug_proposed_minus_prior",
        "proposed_aug_minus_gaia",
    ]
    print(model_summary[display_cols].round(4).to_string(index=False))
    print("\n[AUGMENTED BEST REFERENCE COUNTS]")
    print(ref_counts.to_string(index=False))
    if not correlations.empty:
        print("\n[MODEL-LEVEL HUMAN-EVAL CORRELATIONS]")
        print(correlations.round(4).to_string(index=False))
    print(f"\n[WROTE] {out_dir}")


if __name__ == "__main__":
    main()
