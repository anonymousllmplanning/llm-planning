#!/usr/bin/env python3
"""
Extract additional multimodal tasks from GAIA validation dataset.

This script reads parquet metadata files from the GAIA validation dataset,
filters for multimodal file types, excludes existing task IDs, and formats
records to match the gaia_mini.jsonl structure.

Key transformations:
- File paths: "2023/validation/file.png" → "attachments/file.png"
- Tools field: Numbered list → JSON-serialized array

Known limitations:
- "Tool Arguments" field is omitted (not in source data, manually annotated)
- Tools field normalization is best-effort (may need manual review)

Usage:
    python scripts/expand_and_count.py \\
        --output data/gaia_expanded.jsonl \\
        --attachments_dir gaia.mini.func/data/attachments
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd


# ============================================================================
# Configuration & Constants
# ============================================================================

PROJECT_ROOT = Path(__file__).resolve().parents[2]
BASE_DATA_PATH = PROJECT_ROOT / "data" / "datasets--gaia-benchmark--GAIA"
SNAPSHOT_PATH = (
    BASE_DATA_PATH
    / "snapshots"
    / "682dd723ee1e1697e00360edccf2366dc8418dd9"
    / "2023"
    / "validation"
)

# Target multimodal extensions
MULTIMODAL_EXTENSIONS = ['.mp3', '.wav', '.pptx', '.pdf', '.png', '.jpg', '.mp4']

# Excluded task IDs (already in gaia_mini)
EXCLUDED_TASK_IDS = [
    'a3fbeb63-0e8c-4a11-bff6-0e3b484c3e9c',
    'cffe0e32-c9a6-4c52-9877-78ceb4aaa9fb',
    '1f975693-876d-457b-a649-393859e79bf3',
    '7bd855d8-463d-4ed5-93ca-5fe35145f733',
    '32102e3e-d12a-4209-9163-7b3a104efe5d',
    'edd4d4f2-1a58-45c4-b038-67337af4e029',
    '67e8878b-5cef-4375-804e-e6291fdbe78a',
    '7dd30055-0198-452e-8c25-f73dbe27dcb8',
    'bec74516-02fc-48dc-b202-55e78d0e17cf',
    '9b54f9d9-35ee-4a14-b62f-d130ea00317f',
    'da52d699-e8d2-4dc5-9191-a2199e0b6a9b',
    'c526d8d6-5987-4da9-b24c-83466fa172f3'
]

# Default target attachment directory
DEFAULT_ATTACHMENTS_DIR = "gaia.mini.func/data/attachments"


# ============================================================================
# Data Loading & Filtering Functions
# ============================================================================

def load_metadata(level: int, source_path: Path) -> pd.DataFrame:
    """Load metadata parquet file for a specific level."""
    parquet_path = source_path / f"metadata.level{level}.parquet"
    print(f"[INFO] Loading {parquet_path}")
    df = pd.read_parquet(parquet_path)
    print(f"[INFO]   Total records: {len(df)}")
    return df


def filter_by_extensions(df: pd.DataFrame, extensions: List[str]) -> pd.DataFrame:
    """Filter dataframe to only include records with specified file extensions."""
    # First filter records with files
    df_with_files = df[df['file_name'] != ''].copy()

    # Extract extension and check against list
    def has_target_extension(filename: str) -> bool:
        if not filename:
            return False
        ext = '.' + filename.split('.')[-1].lower()
        return ext in extensions

    df_filtered = df_with_files[df_with_files['file_name'].apply(has_target_extension)]
    print(f"[INFO]   Records with target extensions: {len(df_filtered)}")
    return df_filtered


def exclude_task_ids(df: pd.DataFrame, excluded_ids: List[str]) -> pd.DataFrame:
    """Exclude specified task IDs from dataframe."""
    df_filtered = df[~df['task_id'].isin(excluded_ids)].copy()
    excluded_count = len(df) - len(df_filtered)
    if excluded_count > 0:
        print(f"[INFO]   Excluded {excluded_count} task IDs")
    return df_filtered


# ============================================================================
# Tools Field Transformation
# ============================================================================

def transform_tools_field(tools_str: str) -> str:
    """
    Transform numbered list of tools to JSON-serialized array string.

    Input: "1. Web browser\n2. Search engine\n3. Calculator"
    Output: '["web_browser", "search_engine", "calculator"]'

    Handles various formats:
    - "1. Tool name"
    - "1) Tool name"
    - Lines without numbers
    - Empty lines
    """
    if not tools_str or not isinstance(tools_str, str):
        return "[]"

    # Split by newlines
    lines = tools_str.strip().split('\n')

    tools_list = []
    for line in lines:
        line = line.strip()
        if not line:
            continue

        # Remove numbering: "1. ", "2) ", etc.
        # Pattern matches: digit(s) followed by period or paren and optional space
        clean_line = re.sub(r'^\d+[\.)]\s*', '', line)

        if clean_line:
            # Normalize: lowercase, replace spaces with underscores
            normalized = clean_line.lower().replace(' ', '_')
            # Remove common articles/conjunctions at start
            normalized = re.sub(r'^(a|an|the)_', '', normalized)
            # Remove trailing periods
            normalized = normalized.rstrip('.')
            tools_list.append(normalized)

    # Serialize to JSON string
    return json.dumps(tools_list, ensure_ascii=False)


# ============================================================================
# Record Processing Functions
# ============================================================================

def format_record(row: pd.Series) -> Dict[str, Any]:
    """
    Format a DataFrame row into target JSONL structure.

    Maps fields from source parquet to target format:
    - Direct: task_id, Question, Level, Final answer, file_name
    - Constructed: file_path = "attachments/{file_name}"
    - Transformed: Annotator Metadata.Tools (numbered list -> JSON array)
    """
    file_name = row['file_name']

    # Get Annotator Metadata
    meta = row['Annotator Metadata']
    if not isinstance(meta, dict):
        meta = {}

    # Transform Tools field
    tools_raw = meta.get('Tools', '')
    tools_transformed = transform_tools_field(tools_raw)

    # Build transformed Annotator Metadata
    # Note: Tool Arguments field is NOT in source data
    # It exists in gaia_mini but appears to be manually annotated
    transformed_meta = {
        'Steps': meta.get('Steps', ''),
        'Number of steps': meta.get('Number of steps', ''),
        'How long did this take?': meta.get('How long did this take?', ''),
        'Tools': tools_transformed,
        'Number of tools': meta.get('Number of tools', ''),
    }

    record = {
        'task_id': row['task_id'],
        'Question': row['Question'],
        'Level': row['Level'],
        'Final answer': row['Final answer'],
        'file_name': file_name,
        'file_path': f"attachments/{file_name}",
        'Annotator Metadata': transformed_meta
    }

    return record


def copy_attachment_file(source_dir: Path, dest_dir: Path, filename: str) -> bool:
    """
    Copy attachment file from source to destination, resolving symlinks.

    Returns:
        True if successful, False otherwise
    """
    source_path = source_dir / filename
    dest_path = dest_dir / filename

    try:
        if not source_path.exists():
            print(f"[WARN] File not found: {source_path}")
            return False

        # Resolve symlink if necessary and copy the actual file
        if os.path.islink(str(source_path)):
            real_path = os.path.realpath(str(source_path))
            shutil.copy2(real_path, str(dest_path))
        else:
            shutil.copy2(str(source_path), str(dest_path))

        return True

    except Exception as e:
        print(f"[ERROR] Copying {filename}: {str(e)}")
        return False


# ============================================================================
# Main Processing Functions
# ============================================================================

def process_level(
    level: int,
    source_path: Path,
    dest_dir: Path,
    extensions: List[str],
    excluded_ids: List[str]
) -> List[Dict[str, Any]]:
    """
    Process a single level: load, filter, format, and copy files.

    Returns:
        List of formatted records
    """
    print(f"\n{'='*60}")
    print(f"Processing Level {level}")
    print(f"{'='*60}")

    # Load metadata
    df = load_metadata(level, source_path)

    # Apply filters
    df_filtered = filter_by_extensions(df, extensions)
    df_filtered = exclude_task_ids(df_filtered, excluded_ids)

    print(f"[INFO]   Final record count: {len(df_filtered)}")

    # Process each record
    records = []
    successful_copies = 0

    for idx, row in df_filtered.iterrows():
        task_id = row['task_id']
        file_name = row['file_name']

        print(f"\n[INFO] Processing: {task_id}")
        print(f"[INFO]   File: {file_name}")

        # Copy file
        if copy_attachment_file(source_path, dest_dir, file_name):
            print(f"[INFO]   ✓ Copied to {dest_dir}/")
            successful_copies += 1

            # Format record
            record = format_record(row)
            records.append(record)
        else:
            print(f"[WARN]   ✗ Skipping due to copy failure")

    print(f"\n{'─'*60}")
    print(f"[INFO] Level {level} Summary: {successful_copies}/{len(df_filtered)} files copied")

    return records


def write_jsonl(records: List[Dict[str, Any]], output_path: Path) -> int:
    """Write records to JSONL file."""
    print(f"\n[INFO] Writing to {output_path}")

    count = 0
    with output_path.open('w', encoding='utf-8') as f:
        for record in records:
            json_line = json.dumps(record, ensure_ascii=False)
            f.write(json_line + '\n')
            count += 1

    print(f"[INFO] Wrote {count} records")
    return count


# ============================================================================
# Statistics Functions
# ============================================================================

def calculate_statistics(records: List[Dict[str, Any]], attachments_dir: Path) -> Dict:
    """Calculate comprehensive statistics from records."""
    stats = {
        'total_records': len(records),
        'by_level': Counter(),
        'by_extension': Counter(),
        'files_copied': 0,
    }

    for record in records:
        # Count by level
        level = record.get('Level', 'unknown')
        stats['by_level'][level] += 1

        # Count by extension
        filename = record.get('file_name', '')
        if filename:
            ext = '.' + filename.split('.')[-1].lower()
            stats['by_extension'][ext] += 1

    # Count actual files in directory
    if attachments_dir.exists():
        stats['files_copied'] = len(list(attachments_dir.glob('*')))

    return stats


def display_statistics(stats: Dict):
    """Display statistics in formatted output."""
    print(f"\n{'='*60}")
    print(f"STATISTICS SUMMARY")
    print(f"{'='*60}")

    print(f"\nTotal records extracted: {stats['total_records']}")

    print(f"\nBreakdown by Level:")
    for level in sorted(stats['by_level'].keys()):
        count = stats['by_level'][level]
        print(f"  Level {level}: {count}")

    print(f"\nBreakdown by File Extension:")
    for ext, count in stats['by_extension'].most_common():
        print(f"  {ext}: {count}")

    print(f"\nFiles copied to attachments: {stats['files_copied']}")
    print(f"\n{'='*60}")


# ============================================================================
# Main CLI
# ============================================================================

def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Extract and format additional multimodal tasks from GAIA validation dataset",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Example usage:
    python scripts/expand_and_count.py \\
        --output data/gaia_expanded.jsonl \\
        --attachments_dir gaia.mini.func/data/attachments

    python scripts/expand_and_count.py \\
        --output results/gaia_multimodal.jsonl \\
        --attachments_dir results/attachments \\
        --extensions .mp3 .wav .pdf
        """
    )

    # Required arguments
    parser.add_argument(
        '--output',
        type=Path,
        required=True,
        help='Output JSONL file path'
    )

    # Optional arguments
    parser.add_argument(
        '--attachments_dir',
        type=Path,
        default=Path(DEFAULT_ATTACHMENTS_DIR),
        help=f'Target directory for attachment files (default: {DEFAULT_ATTACHMENTS_DIR})'
    )

    parser.add_argument(
        '--source_path',
        type=Path,
        default=Path(SNAPSHOT_PATH),
        help=f'Source validation directory (default: {SNAPSHOT_PATH})'
    )

    parser.add_argument(
        '--extensions',
        nargs='+',
        default=MULTIMODAL_EXTENSIONS,
        help=f'File extensions to include (default: {" ".join(MULTIMODAL_EXTENSIONS)})'
    )

    parser.add_argument(
        '--no_exclude',
        action='store_true',
        help='Do not exclude the 12 task IDs from gaia_mini'
    )

    args = parser.parse_args()

    # Banner
    print("╔════════════════════════════════════════════════════════════╗")
    print("║    GAIA Validation Dataset Multimodal Expansion Tool       ║")
    print("╚════════════════════════════════════════════════════════════╝")

    # Setup attachments directory
    args.attachments_dir.mkdir(parents=True, exist_ok=True)
    print(f"\n[INFO] Attachments directory: {args.attachments_dir}")

    # Determine exclusion list
    excluded_ids = [] if args.no_exclude else EXCLUDED_TASK_IDS
    if excluded_ids:
        print(f"[INFO] Excluding {len(excluded_ids)} task IDs from gaia_mini")

    # Process each level
    all_records = []
    for level in [1, 2, 3]:
        records = process_level(
            level=level,
            source_path=args.source_path,
            dest_dir=args.attachments_dir,
            extensions=args.extensions,
            excluded_ids=excluded_ids
        )
        all_records.extend(records)

    # Write output
    if all_records:
        write_jsonl(all_records, args.output)

        # Calculate and display statistics
        stats = calculate_statistics(all_records, args.attachments_dir)
        display_statistics(stats)

        print(f"\n[DONE] Successfully processed {len(all_records)} records")
        print(f"[DONE] Output: {args.output}")
        print(f"[DONE] Attachments: {args.attachments_dir}")
    else:
        print("\n[WARN] No records matched the filtering criteria!")
        return 1

    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
