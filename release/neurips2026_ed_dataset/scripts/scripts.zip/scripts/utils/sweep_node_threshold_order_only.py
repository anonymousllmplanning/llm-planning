#!/usr/bin/env python3
"""Sweep node-match thresholds for NodeF1+EdgeF1 vs NodeF1+OrderF1.

This is a lightweight sanity check for whether the order-only story is stable
under the node label similarity threshold. It keeps SpanNodeF1 out of the main
comparison and reports:

    node_edge_score  = (strict_node_f1 + semantic_edge_f1) / 2
    node_order_score = (strict_node_f1 + strict-node-anchored OrderF1) / 2

The script runs all thresholds in one Python process so sentence-transformer
embeddings are cached across thresholds.
"""

from __future__ import annotations

import argparse
import copy
import glob
import json
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.evaluation.metrics import (  # noqa: E402
    ASTEvaluationSystem,
    _f1_from_prec_recall,
    _semantic_node_alignment,
    _semantic_node_match_scores,
    _set_f1,
)
from scripts.utils.compare_gaia_augmented_prior_span_order import (  # noqa: E402
    CATEGORY_META,
    MODEL_ALIASES,
    attach_human_eval,
    attach_tool_clean,
    category_from_subset,
    dependency_dag_from_async_record,
    iter_jsonl,
    load_gold_references,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=REPO_ROOT)
    parser.add_argument("--gaia-results-root", type=Path, default=REPO_ROOT / "organized_results/gaia/0427")
    parser.add_argument("--taskbench-dir", type=Path, default=REPO_ROOT / "organized_results/taskbench_balanced_600")
    parser.add_argument("--output-dir", type=Path, default=REPO_ROOT / "runtime_artifacts/node_threshold_order_only_sweep_20260428")
    parser.add_argument("--thresholds", nargs="+", type=float, default=[0.35, 0.40, 0.45, 0.50, 0.55, 0.60])
    parser.add_argument("--ats-threshold", type=float, default=0.5)
    parser.add_argument("--tisr-threshold", type=float, default=0.7)
    return parser.parse_args()


def _edge_pairs_by_node_index(nodes: Sequence[Dict[str, Any]], edges: Sequence[Dict[str, Any]]) -> Set[Tuple[int, int]]:
    id_to_idx = {n.get("node_id", ""): i for i, n in enumerate(nodes)}
    pairs: Set[Tuple[int, int]] = set()
    for e in edges or []:
        source = e.get("source")
        target = e.get("target")
        sources = source if isinstance(source, list) else ([source] if source else [])
        targets = target if isinstance(target, list) else ([target] if target else [])
        for src in sources:
            s = id_to_idx.get(src)
            if s is None:
                continue
            for tgt in targets:
                t = id_to_idx.get(tgt)
                if t is not None and s != t:
                    pairs.add((s, t))
    return pairs


def _transitive_pairs_with_dist(num_nodes: int, edge_pairs: Set[Tuple[int, int]]) -> Tuple[Set[Tuple[int, int]], Dict[Tuple[int, int], int]]:
    adjacency: Dict[int, Set[int]] = {i: set() for i in range(num_nodes)}
    for s, t in edge_pairs:
        if 0 <= s < num_nodes and 0 <= t < num_nodes and s != t:
            adjacency[s].add(t)

    closure: Set[Tuple[int, int]] = set()
    shortest: Dict[Tuple[int, int], int] = {}
    for start in range(num_nodes):
        queue: List[Tuple[int, int]] = [(start, 0)]
        seen = {start}
        head = 0
        while head < len(queue):
            node, dist = queue[head]
            head += 1
            for nxt in adjacency.get(node, set()):
                if nxt in seen:
                    continue
                seen.add(nxt)
                queue.append((nxt, dist + 1))
                pair = (start, nxt)
                closure.add(pair)
                shortest[pair] = min(shortest.get(pair, dist + 1), dist + 1)
    return closure, shortest


def semantic_edge_f1(gold_dag: Dict[str, Any], pred_dag: Dict[str, Any], threshold: float) -> float:
    gold_nodes = gold_dag.get("nodes") or []
    pred_nodes = pred_dag.get("nodes") or []
    gold_edges = gold_dag.get("edges") or []
    pred_edges = pred_dag.get("edges") or []
    if not gold_nodes and not pred_nodes:
        return 1.0
    if not gold_nodes:
        return 0.0
    if not pred_nodes:
        return 0.0

    _, _, pred_to_gold = _semantic_node_alignment(gold_nodes, pred_nodes, threshold=threshold)
    gold_edge_pairs = _edge_pairs_by_node_index(gold_nodes, gold_edges)
    pred_edge_pairs = _edge_pairs_by_node_index(pred_nodes, pred_edges)
    unmatched_base = len(gold_nodes) + (2 * len(pred_nodes)) + 1
    pred_semantic: Set[Tuple[int, int]] = set()
    for s_pred, t_pred in pred_edge_pairs:
        s_gold = pred_to_gold.get(s_pred, unmatched_base + s_pred)
        t_gold = pred_to_gold.get(t_pred, unmatched_base + len(pred_nodes) + t_pred)
        pred_semantic.add((s_gold, t_gold))
    return _set_f1(gold_edge_pairs, pred_semantic, empty_is_perfect=bool(gold_nodes))[2]


def strict_node_order_f1(gold_dag: Dict[str, Any], pred_dag: Dict[str, Any], threshold: float) -> float:
    gold_nodes = gold_dag.get("nodes") or []
    pred_nodes = pred_dag.get("nodes") or []
    gold_edges = gold_dag.get("edges") or []
    pred_edges = pred_dag.get("edges") or []
    if not gold_nodes and not pred_nodes:
        return 1.0
    if not gold_nodes or not pred_nodes:
        return 0.0

    _, _, pred_to_gold = _semantic_node_alignment(gold_nodes, pred_nodes, threshold=threshold)
    gold_edge_pairs = _edge_pairs_by_node_index(gold_nodes, gold_edges)
    pred_edge_pairs = _edge_pairs_by_node_index(pred_nodes, pred_edges)
    gold_order, gold_dist = _transitive_pairs_with_dist(len(gold_nodes), gold_edge_pairs)
    pred_order, pred_dist = _transitive_pairs_with_dist(len(pred_nodes), pred_edge_pairs)
    if not gold_order and not pred_order:
        return 1.0
    if not gold_order or not pred_order:
        return 0.0

    pred_weight_denom = sum(1.0 / max(pred_dist[pair], 1) for pair in pred_order)
    pred_weight_num = 0.0
    covered_gold: Set[Tuple[int, int]] = set()
    for s_pred, t_pred in pred_order:
        s_gold = pred_to_gold.get(s_pred)
        t_gold = pred_to_gold.get(t_pred)
        if s_gold is None or t_gold is None or s_gold == t_gold:
            continue
        pair = (s_gold, t_gold)
        if pair in gold_order:
            pred_weight_num += 1.0 / max(pred_dist[(s_pred, t_pred)], 1)
            covered_gold.add(pair)

    gold_weight_denom = sum(1.0 / max(gold_dist[pair], 1) for pair in gold_order)
    gold_weight_num = sum(1.0 / max(gold_dist[pair], 1) for pair in covered_gold)
    precision = pred_weight_num / pred_weight_denom if pred_weight_denom else 0.0
    recall = gold_weight_num / gold_weight_denom if gold_weight_denom else 0.0
    return _f1_from_prec_recall(precision, recall)


def score_pair(gold_dag: Dict[str, Any], pred_dag: Dict[str, Any], threshold: float) -> Dict[str, float]:
    strict_node = _semantic_node_match_scores(
        gold_dag.get("nodes") or [],
        pred_dag.get("nodes") or [],
        threshold=threshold,
    )[2]
    sem_edge = semantic_edge_f1(gold_dag, pred_dag, threshold)
    order = strict_node_order_f1(gold_dag, pred_dag, threshold)
    return {
        "strict_node_f1": strict_node,
        "semantic_edge_f1": sem_edge,
        "strict_node_order_f1": order,
        "node_edge_score": (strict_node + sem_edge) / 2.0,
        "node_order_score": (strict_node + order) / 2.0,
    }


def choose_best(scored_refs: List[Tuple[str, Dict[str, float]]], key: str) -> Tuple[str, Dict[str, float]]:
    preference = {"chain": 0, "dag": 1}
    return max(scored_refs, key=lambda item: (item[1][key], -preference.get(item[0], 99)))


def collect_gaia_base(args: argparse.Namespace) -> Tuple[List[Dict[str, Any]], Dict[str, Any], Dict[str, Any]]:
    chain_gold, async_gold = load_gold_references(args.repo_root)
    rows: List[Dict[str, Any]] = []
    paths = sorted(
        path for path in glob.glob(str(args.gaia_results_root / "**/unified.*.jsonl"), recursive=True)
        if "/tool_creation_log." not in path
    )
    for path_string in paths:
        for record in iter_jsonl(Path(path_string)):
            meta = record.get("meta") or {}
            sample_id = meta.get("id")
            subset = meta.get("subset", "")
            rows.append({
                "sample_id": sample_id,
                "sample_prefix": str(sample_id)[:8],
                "model": meta.get("model_name"),
                "category": CATEGORY_META.get(category_from_subset(subset), {}).get("name", ""),
                "subset": subset,
                "pred_dag": (record.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []},
            })
    return rows, chain_gold, async_gold


def score_gaia_threshold(base_rows: List[Dict[str, Any]], chain_gold: Dict[str, Any], async_gold: Dict[str, Any], threshold: float) -> pd.DataFrame:
    out: List[Dict[str, Any]] = []
    for base in base_rows:
        sample_id = base["sample_id"]
        pred_dag = base["pred_dag"]
        gaia_chain = copy.deepcopy(chain_gold[sample_id]["gold"]["plan_dag"])
        aug_chain = copy.deepcopy(async_gold[sample_id]["gold"]["plan_dag"])
        aug_dag = dependency_dag_from_async_record(async_gold[sample_id])
        gaia_scores = score_pair(gaia_chain, pred_dag, threshold)
        aug_edge = choose_best(
            [("chain", score_pair(aug_chain, pred_dag, threshold)), ("dag", score_pair(aug_dag, pred_dag, threshold))],
            "node_edge_score",
        )[1]
        aug_order = choose_best(
            [("chain", score_pair(aug_chain, pred_dag, threshold)), ("dag", score_pair(aug_dag, pred_dag, threshold))],
            "node_order_score",
        )[1]
        row = {k: v for k, v in base.items() if k != "pred_dag"}
        row.update({
            "threshold": threshold,
            "gaia_node_edge_score": gaia_scores["node_edge_score"],
            "gaia_node_order_score": gaia_scores["node_order_score"],
            "aug_node_edge_score": aug_edge["node_edge_score"],
            "aug_node_order_score": aug_order["node_order_score"],
        })
        out.append(row)
    return pd.DataFrame(out)


def collect_taskbench_base(args: argparse.Namespace) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for path in sorted(args.taskbench_dir.glob("unified.*.jsonl")):
        model = path.stem.replace("unified.", "")
        for line in path.open():
            record = json.loads(line)
            meta = record.get("meta") or {}
            rows.append({
                "sample_id": meta.get("id"),
                "model": model,
                "subset": meta.get("subset"),
                "plan_type": meta.get("plan_type"),
                "gold_dag": (record.get("gold") or {}).get("plan_dag") or {"nodes": [], "edges": []},
                "pred_dag": (record.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []},
            })
    return rows


def score_taskbench_threshold(base_rows: List[Dict[str, Any]], threshold: float) -> pd.DataFrame:
    out: List[Dict[str, Any]] = []
    for base in base_rows:
        scores = score_pair(base["gold_dag"], base["pred_dag"], threshold)
        row = {k: v for k, v in base.items() if k not in {"gold_dag", "pred_dag"}}
        row["threshold"] = threshold
        row.update(scores)
        out.append(row)
    return pd.DataFrame(out)


def attach_gaia_labels_and_tools(args: argparse.Namespace, df: pd.DataFrame) -> pd.DataFrame:
    merged = attach_human_eval(args.gaia_results_root, df)
    merged = attach_tool_clean(args.gaia_results_root, merged)
    return merged


def summarize_correlations(df: pd.DataFrame, args: argparse.Namespace) -> pd.DataFrame:
    try:
        from scipy.stats import pearsonr, spearmanr
    except Exception:
        return pd.DataFrame()
    rows: List[Dict[str, Any]] = []
    parse_error = df["parse_error"].astype(str).str.lower().isin(["true", "1", "yes", "y"])
    clean = (~parse_error) & (df["gt_aligned_tool_success_rate"] >= args.ats_threshold) & (df["pred_exec_success_rate"] >= args.tisr_threshold)
    masks = {
        "all": pd.Series(True, index=df.index),
        "tool_clean": clean,
        "attachment_clean": clean & df["category"].isin(["Document Analysis", "Vision", "Audio"]) & (df["gold_tool_count"] >= 2),
    }
    for threshold, th_df in df.groupby("threshold"):
        for subset_name, base_mask in masks.items():
            sub = th_df[base_mask.loc[th_df.index]]
            model_summary = sub.groupby("model", as_index=False).agg(
                solve_rate=("human_eval_solve", "mean"),
                aug_node_edge_score=("aug_node_edge_score", "mean"),
                aug_node_order_score=("aug_node_order_score", "mean"),
            )
            for metric in ["aug_node_edge_score", "aug_node_order_score"]:
                valid = model_summary[[metric, "solve_rate"]].dropna()
                pr = pearsonr(valid[metric], valid["solve_rate"])
                sp = spearmanr(valid[metric], valid["solve_rate"])
                rows.append({
                    "threshold": threshold,
                    "subset": subset_name,
                    "retained_predictions": len(sub),
                    "metric": metric,
                    "mean_metric": sub[metric].mean(),
                    "solve_rate": sub["human_eval_solve"].mean(),
                    "pearson_r": pr.statistic,
                    "pearson_p": pr.pvalue,
                    "spearman_rho": sp.statistic,
                    "spearman_p": sp.pvalue,
                })
    return pd.DataFrame(rows)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    ASTEvaluationSystem(use_embeddings=True)

    gaia_base, chain_gold, async_gold = collect_gaia_base(args)
    taskbench_base = collect_taskbench_base(args)
    gaia_frames: List[pd.DataFrame] = []
    taskbench_frames: List[pd.DataFrame] = []
    for threshold in args.thresholds:
        print(f"[INFO] threshold={threshold}")
        gaia_frames.append(score_gaia_threshold(gaia_base, chain_gold, async_gold, threshold))
        taskbench_frames.append(score_taskbench_threshold(taskbench_base, threshold))

    gaia = pd.concat(gaia_frames, ignore_index=True)
    gaia = attach_gaia_labels_and_tools(args, gaia)
    taskbench = pd.concat(taskbench_frames, ignore_index=True)

    gaia_overall = gaia.groupby("threshold", as_index=False).agg(
        n=("sample_id", "count"),
        gaia_node_edge_score=("gaia_node_edge_score", "mean"),
        gaia_node_order_score=("gaia_node_order_score", "mean"),
        aug_node_edge_score=("aug_node_edge_score", "mean"),
        aug_node_order_score=("aug_node_order_score", "mean"),
    )
    taskbench_overall = taskbench.groupby("threshold", as_index=False).agg(
        n=("sample_id", "count"),
        node_edge_score=("node_edge_score", "mean"),
        node_order_score=("node_order_score", "mean"),
    )
    taskbench_plan_type = taskbench.groupby(["threshold", "plan_type"], as_index=False).agg(
        n=("sample_id", "count"),
        node_edge_score=("node_edge_score", "mean"),
        node_order_score=("node_order_score", "mean"),
    )
    correlations = summarize_correlations(gaia, args)

    gaia_overall.to_csv(args.output_dir / "gaia_threshold_overall.csv", index=False)
    taskbench_overall.to_csv(args.output_dir / "taskbench_threshold_overall.csv", index=False)
    taskbench_plan_type.to_csv(args.output_dir / "taskbench_threshold_by_plan_type.csv", index=False)
    correlations.to_csv(args.output_dir / "gaia_threshold_model_level_correlations.csv", index=False)

    print("\n[GAIA OVERALL]")
    print(gaia_overall.round(4).to_string(index=False))
    print("\n[TASKBENCH OVERALL]")
    print(taskbench_overall.round(4).to_string(index=False))
    print("\n[GAIA CORRELATIONS: tool_clean]")
    show = correlations[(correlations["subset"] == "tool_clean") & (correlations["metric"] == "aug_node_order_score")]
    print(show.round(4).to_string(index=False))
    print(f"\n[WROTE] {args.output_dir}")


if __name__ == "__main__":
    main()
