#!/usr/bin/env python3
"""Rebuild GAIA Cat A async DAG artifacts against the current GT labels.

This script refreshes:
1. data/GAIA/DAGs/gaia_cat_A_async_plan.jsonl
2. data/GAIA/DAGs/gaia_cat_A_restored_chain.jsonl

Design:
- Preserve existing async metadata when the old original steps align exactly
  with the current GT labels after removing the synthetic final submit step.
- Fall back to a conservative chain-only async structure when the old file is a
  generic placeholder or a parser-fragmented artifact.
"""

from __future__ import annotations

import json
import math
import re
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List


ROOT = Path(__file__).resolve().parents[2]
CAT_A_PATH = ROOT / "data/GAIA/cat_A_text/gaia.cat_A.json"
ASYNC_PATH = ROOT / "data/GAIA/DAGs/gaia_cat_A_async_plan.jsonl"
RESTORED_PATH = ROOT / "data/GAIA/DAGs/gaia_cat_A_restored_chain.jsonl"


def load_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def normalize_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"\s+", " ", text).strip()
    return text


def is_submit_step(text: str) -> bool:
    return normalize_text(text) == "submit final answer"


def chain_dependency_analysis(step_count: int) -> Dict[str, Any]:
    dependencies = []
    edges = []
    for i in range(step_count):
        if i == 0:
            dependencies.append(
                {
                    "step_id": 0,
                    "depends_on": [],
                    "dependency_types": [],
                    "reason": "starting step",
                }
            )
        else:
            dependencies.append(
                {
                    "step_id": i,
                    "depends_on": [i - 1],
                    "dependency_types": ["sequential"],
                    "reason": "preserve the current GT chain order",
                }
            )
            edges.append({"from": i - 1, "to": i})
    return {"dependencies": dependencies, "edges": edges}


def trim_submit_exec(rec: Dict[str, Any]) -> Dict[str, Any]:
    """Remove the synthetic submit step from the old async metadata."""
    new_rec = deepcopy(rec)

    original_steps = list(new_rec.get("original_steps") or [])
    step_types = list(new_rec.get("step_types") or [])
    step_mapping = {int(k): int(v) for k, v in (new_rec.get("step_mapping") or {}).items()}
    executable_steps = list(new_rec.get("executable_steps") or [])
    dep = deepcopy(new_rec.get("dependency_analysis") or {})
    parallel_groups = deepcopy(new_rec.get("parallel_groups") or [])
    possible_orderings = deepcopy(new_rec.get("possible_orderings") or [])
    metadata = deepcopy(new_rec.get("metadata") or {})

    # Remove trailing synthetic original step if present.
    if original_steps and is_submit_step(original_steps[-1]):
        original_steps = original_steps[:-1]
        if step_types:
            step_types = step_types[:-1]
        step_mapping.pop(len(original_steps), None)

    exec_submit_idx = None
    if executable_steps and is_submit_step(executable_steps[-1]):
        exec_submit_idx = len(executable_steps) - 1
        executable_steps = executable_steps[:-1]

    if exec_submit_idx is not None:
        dep["dependencies"] = [
            d for d in (dep.get("dependencies") or []) if int(d.get("step_id", -1)) != exec_submit_idx
        ]
        dep["edges"] = [
            e
            for e in (dep.get("edges") or [])
            if int(e.get("from", -1)) != exec_submit_idx and int(e.get("to", -1)) != exec_submit_idx
        ]
        parallel_groups = [
            [idx for idx in group if int(idx) != exec_submit_idx]
            for group in parallel_groups
        ]
        parallel_groups = [group for group in parallel_groups if group]
        possible_orderings = [
            [idx for idx in ordering if int(idx) != exec_submit_idx]
            for ordering in possible_orderings
        ]

    new_rec["original_steps"] = original_steps
    new_rec["step_types"] = step_types
    new_rec["step_mapping"] = {str(k): v for k, v in sorted(step_mapping.items()) if k < len(original_steps)}
    new_rec["executable_steps"] = executable_steps
    new_rec["dependency_analysis"] = dep
    new_rec["parallel_groups"] = parallel_groups
    new_rec["possible_orderings"] = possible_orderings or [list(range(len(executable_steps)))]
    metadata["original_step_count"] = len(original_steps)
    metadata["executable_step_count"] = len(executable_steps)
    metadata["redundant_step_count"] = max(0, len(original_steps) - len(executable_steps))
    metadata["parallel_group_count"] = len(parallel_groups)
    metadata["max_parallelism"] = max((len(group) for group in parallel_groups), default=1)
    metadata["version"] = "v3.1"
    new_rec["metadata"] = metadata
    return new_rec


def make_chain_fallback(current_rec: Dict[str, Any], base_meta: Dict[str, Any]) -> Dict[str, Any]:
    labels = [node["label"] for node in current_rec["gold"]["plan_dag"]["nodes"]]
    step_count = len(labels)
    fallback = {
        "meta": deepcopy(current_rec["meta"]),
        "query": deepcopy(current_rec["query"]),
        "tool_environment": deepcopy(current_rec["tool_environment"]),
        "gold": deepcopy(current_rec["gold"]),
        "original_steps": labels,
        "executable_steps": labels,
        "step_types": ["executable"] * step_count,
        "step_mapping": {str(i): i for i in range(step_count)},
        "dependency_analysis": chain_dependency_analysis(step_count),
        "parallel_groups": [[i] for i in range(step_count)],
        "possible_orderings": [list(range(step_count))],
        "total_orderings": 1,
        "metadata": {
            "version": "v3.1",
            "original_step_count": step_count,
            "executable_step_count": step_count,
            "redundant_step_count": 0,
            "parallel_group_count": step_count,
            "max_parallelism": 1,
            "note": "Rebuilt from current GT with conservative chain fallback",
            "rebuild_alignment_mode": "chain_fallback",
        },
    }
    # Preserve extra top-level metadata fields when they exist.
    for key in ("metadata",):
        if key in base_meta and isinstance(base_meta[key], dict):
            merged = deepcopy(base_meta[key])
            merged.update(fallback[key])
            fallback[key] = merged
    return fallback


def build_restored_chain(async_rec: Dict[str, Any]) -> Dict[str, Any]:
    executable_steps = list(async_rec.get("executable_steps") or [])
    n = len(executable_steps)
    max_kendall = n * (n - 1) // 2
    analysis = {
        "executable_steps_original": executable_steps,
        "restored_chain": executable_steps,
        "restored_index_order": list(range(n)),
        "validation": {
            "is_valid_topological_order": True,
            "kendall_tau_distance": 0,
            "max_kendall_tau": max_kendall,
            "normalized_distance": 0.0 if max_kendall else 0.0,
            "is_identical_to_original": True,
        },
    }
    return {
        "meta": deepcopy(async_rec.get("meta") or {}),
        "query": deepcopy(async_rec.get("query") or {}),
        "tool_environment": deepcopy(async_rec.get("tool_environment") or {}),
        "gold": deepcopy(async_rec.get("gold") or {}),
        "original_steps": deepcopy(async_rec.get("original_steps") or executable_steps),
        "step_types": deepcopy(async_rec.get("step_types") or ["executable"] * n),
        "step_mapping": deepcopy(async_rec.get("step_mapping") or {str(i): i for i in range(n)}),
        "executable_steps": executable_steps,
        "restored_chain_analysis": analysis,
        # Backward-compatible aliases for any older ad-hoc readers.
        "id": async_rec.get("meta", {}).get("id", ""),
        "restored_chain": executable_steps,
        "restored_index_order": list(range(n)),
        "validation": analysis["validation"],
    }


def main() -> None:
    current_rows = load_json(CAT_A_PATH)
    current_by_id = {row["meta"]["id"]: row for row in current_rows}
    old_async_rows = load_jsonl(ASYNC_PATH)

    rebuilt_async_rows: List[Dict[str, Any]] = []
    rebuilt_restored_rows: List[Dict[str, Any]] = []
    preserved = 0
    fallback = 0

    for old_rec in old_async_rows:
        sid = old_rec["meta"]["id"]
        current_rec = current_by_id[sid]
        current_labels = [node["label"] for node in current_rec["gold"]["plan_dag"]["nodes"]]

        trimmed_old = trim_submit_exec(old_rec)
        old_labels = list(trimmed_old.get("original_steps") or [])

        if len(current_labels) == len(old_labels) and all(
            normalize_text(a) == normalize_text(b) for a, b in zip(current_labels, old_labels)
        ):
            new_rec = deepcopy(trimmed_old)
            new_rec["meta"] = deepcopy(current_rec["meta"])
            new_rec["query"] = deepcopy(current_rec["query"])
            new_rec["tool_environment"] = deepcopy(current_rec["tool_environment"])
            new_rec["gold"] = deepcopy(current_rec["gold"])
            new_rec["original_steps"] = current_labels
            new_rec["metadata"] = deepcopy(new_rec.get("metadata") or {})
            new_rec["metadata"]["version"] = "v3.1"
            new_rec["metadata"]["rebuild_alignment_mode"] = "preserve_async_structure"
            # Keep total_orderings consistent with preserved orderings.
            new_rec["total_orderings"] = len(new_rec.get("possible_orderings") or [list(range(len(new_rec.get("executable_steps") or [])))])
            preserved += 1
        else:
            new_rec = make_chain_fallback(current_rec, old_rec)
            fallback += 1

        rebuilt_async_rows.append(new_rec)
        rebuilt_restored_rows.append(build_restored_chain(new_rec))

    write_jsonl(ASYNC_PATH, rebuilt_async_rows)
    write_jsonl(RESTORED_PATH, rebuilt_restored_rows)

    print(f"Rebuilt async DAGs: preserved={preserved}, fallback={fallback}, total={len(rebuilt_async_rows)}")


if __name__ == "__main__":
    main()
