#!/usr/bin/env python3
"""
Compute step-coverage versus semantic node-alignment metrics for GAIA plan DAGs.

This script mirrors the evaluator's current GAIA node-matching logic:

- Step Coverage Precision / Recall / F1:
  the legacy index-based metric
- Semantic Node Alignment Precision / Recall / F1:
  one-to-one semantic alignment with a discrete match threshold
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import Counter
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Tuple

from src.evaluation.metrics import _semantic_node_match_scores


@dataclass
class SummaryRow:
    model: str
    split: str
    num_samples: int
    avg_gold_nodes: float
    avg_pred_nodes: float
    step_cov_precision: float
    step_cov_recall: float
    step_cov_f1: float
    semantic_precision: float
    semantic_recall: float
    semantic_f1: float


def load_jsonl_robust(path: Path) -> List[Dict[str, Any]]:
    """Load possibly line-broken JSONL by reconstructing balanced JSON objects."""
    text = path.read_text()
    buf = []
    depth = 0
    in_str = False
    escape = False
    records: List[Dict[str, Any]] = []

    for ch in text:
        buf.append(ch)
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    payload = "".join(buf).strip()
                    if payload:
                        records.append(json.loads(payload))
                    buf = []
    return records


def step_coverage_scores(
    gold_nodes: Sequence[Dict[str, Any]],
    pred_nodes: Sequence[Dict[str, Any]],
) -> Tuple[float, float, float]:
    gold_indices = {node.get("step_index", i) for i, node in enumerate(gold_nodes)}
    pred_indices = {node.get("step_index", i) for i, node in enumerate(pred_nodes)}
    intersection = len(gold_indices & pred_indices)

    precision = intersection / len(pred_indices) if pred_indices else (1.0 if not gold_indices else 0.0)
    recall = intersection / len(gold_indices) if gold_indices else (1.0 if not pred_indices else 0.0)
    f1 = 0.0 if precision + recall == 0 else 2 * precision * recall / (precision + recall)
    return precision, recall, f1


def summarize_rows(
    model: str,
    records: Sequence[Dict[str, Any]],
    multi_order_ids: set[str],
) -> List[SummaryRow]:
    enriched = []
    for rec in records:
        gold_nodes = (rec.get("gold") or {}).get("plan_dag", {}).get("nodes") or []
        pred_nodes = (rec.get("pred") or {}).get("plan_dag", {}).get("nodes") or []
        scp, scr, scf = step_coverage_scores(gold_nodes, pred_nodes)
        snp, snr, snf = _semantic_node_match_scores(gold_nodes, pred_nodes)
        enriched.append(
            {
                "id": rec["meta"]["id"],
                "is_multi_order": rec["meta"]["id"] in multi_order_ids,
                "gold_nodes": len(gold_nodes),
                "pred_nodes": len(pred_nodes),
                "step_cov_precision": scp,
                "step_cov_recall": scr,
                "step_cov_f1": scf,
                "semantic_precision": snp,
                "semantic_recall": snr,
                "semantic_f1": snf,
            }
        )

    def build_row(split: str, subset: Iterable[Dict[str, Any]]) -> SummaryRow:
        subset = list(subset)
        return SummaryRow(
            model=model,
            split=split,
            num_samples=len(subset),
            avg_gold_nodes=sum(x["gold_nodes"] for x in subset) / len(subset),
            avg_pred_nodes=sum(x["pred_nodes"] for x in subset) / len(subset),
            step_cov_precision=sum(x["step_cov_precision"] for x in subset) / len(subset),
            step_cov_recall=sum(x["step_cov_recall"] for x in subset) / len(subset),
            step_cov_f1=sum(x["step_cov_f1"] for x in subset) / len(subset),
            semantic_precision=sum(x["semantic_precision"] for x in subset) / len(subset),
            semantic_recall=sum(x["semantic_recall"] for x in subset) / len(subset),
            semantic_f1=sum(x["semantic_f1"] for x in subset) / len(subset),
        )

    return [
        build_row("All 127", enriched),
        build_row("Multi-order 40", [x for x in enriched if x["is_multi_order"]]),
    ]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--async-plan-json", type=Path, required=True)
    parser.add_argument("--model", action="append", nargs=2, metavar=("NAME", "UNIFIED_JSONL"), required=True)
    parser.add_argument("--output-csv", type=Path, required=True)
    args = parser.parse_args()

    async_records = json.loads(args.async_plan_json.read_text())
    multi_order_ids = {rec["meta"]["id"] for rec in async_records if rec.get("total_orderings", 1) > 1}

    rows: List[SummaryRow] = []
    for model_name, unified_path in args.model:
        records = load_jsonl_robust(Path(unified_path))
        rows.extend(summarize_rows(model_name, records, multi_order_ids))

    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    with args.output_csv.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(SummaryRow.__annotations__.keys()))
        writer.writeheader()
        for row in rows:
            writer.writerow(row.__dict__)

    for row in rows:
        print(
            f"{row.model:12} {row.split:16} "
            f"step_cov_f1={row.step_cov_f1:.4f} "
            f"semantic_f1={row.semantic_f1:.4f} "
            f"(P={row.semantic_precision:.4f}, R={row.semantic_recall:.4f})"
        )


if __name__ == "__main__":
    main()
