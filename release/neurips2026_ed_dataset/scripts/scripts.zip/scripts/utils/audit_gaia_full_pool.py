#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_DIR = REPO_ROOT / "organized_results" / "analysis" / "gaia_full_pool_audit_20260420"
RECOMPUTED_DIR = REPO_ROOT / "organized_results" / "analysis" / "gaia_full_pool_recomputed_20260420"
GOLD_DATASET = {
    "A": REPO_ROOT / "data.hg/GAIA/cat_A_text/gaia.cat_A.json",
    "B": REPO_ROOT / "data.hg/GAIA/cat_B_document/gaia.cat_B.json",
    "C": REPO_ROOT / "data.hg/GAIA/cat_C_vision/gaia.cat_C.json",
    "D": REPO_ROOT / "data.hg/GAIA/cat_D_audio/gaia.cat_D.json",
}

RUNS: Dict[str, Dict[str, Path]] = {
    "Llama-4-Maverick-17B-128E-Instruct-FP8": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_183013.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_002720.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_005708.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_012447.gaia_cat_D.answer",
    },
    "Llama-3.3-Nemotron-Super-49B-v1": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_185156.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_061147.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_075320.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_084007.gaia_cat_D.answer",
    },
    "Llama-3.3-70B-Instruct": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_184507.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_005117.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_012532.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_015238.gaia_cat_D.answer",
    },
    "gpt-oss-120b": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_183211.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260418_194347.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260418_195611.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260418_202600.gaia_cat_D.answer",
    },
    "gpt-oss-20b": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_183318.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260418_203228.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260418_205135.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260418_214230.gaia_cat_D.answer",
    },
    "Mistral-Small-3.2-24B-Instruct-2506": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_183249.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_093046.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_101302.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_104958.gaia_cat_D.answer",
    },
    "gemma-3-12b-it": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260418_185120.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260419_002448.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260419_005822.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260419_012210.gaia_cat_D.answer",
    },
}

MODEL_DISPLAY = {
    "Llama-4-Maverick-17B-128E-Instruct-FP8": "Llama-4 Maverick 17B",
    "Llama-3.3-Nemotron-Super-49B-v1": "Llama-3.3 Nemotron 49B",
    "Llama-3.3-70B-Instruct": "Llama-3.3 70B",
    "gpt-oss-120b": "gpt-oss 120B",
    "gpt-oss-20b": "gpt-oss 20B",
    "Mistral-Small-3.2-24B-Instruct-2506": "Mistral Small 3.2 24B",
    "gemma-3-12b-it": "Gemma 3 12B",
}

CAT_LABEL = {
    "A": "Text Reasoning",
    "B": "Document Analysis",
    "C": "Vision",
    "D": "Audio",
}

REQUIRED_PER_SAMPLE_COLUMNS = [
    "sample_id",
    "node_f1",
    "edge_f1",
    "semantic_edge_f1",
    "dw_order_f1",
    "planning_score",
    "tool_name_f1",
    "param_name_f1",
    "type_aware_value_f1",
    "tool_usage_score",
    "gt_aligned_tool_success_rate",
    "pred_exec_success_rate",
    "observation_support_rate",
    "exact_match",
    "token_f1",
    "parse_error",
]

UNIT_INTERVAL_COLUMNS = [
    "node_f1",
    "edge_f1",
    "semantic_edge_f1",
    "dw_order_f1",
    "planning_score",
    "order_precision",
    "order_recall",
    "order_f1",
    "node_label_similarity",
    "ssi",
    "tool_name_f1",
    "param_name_f1",
    "type_aware_value_f1",
    "tool_usage_score",
    "gt_aligned_tool_success_rate",
    "pred_exec_success_rate",
    "observation_support_rate",
    "exact_match",
    "token_f1",
    "alias_match",
    "llm_judge_score",
]

GROUP_WEIGHTS = {"A": 127, "B": 25, "C": 10, "D": 3}


def normalize_text(text: Any) -> str:
    s = "" if text is None else str(text)
    s = s.strip().lower()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[\"'`]+", "", s)
    return s


def tokenize(text: str) -> List[str]:
    return re.findall(r"[a-z0-9]+", normalize_text(text))


def multiset_token_f1(a: str, b: str) -> float:
    at = tokenize(a)
    bt = tokenize(b)
    if not at and not bt:
        return 1.0
    if not at or not bt:
        return 0.0
    ca = Counter(at)
    cb = Counter(bt)
    overlap = sum(min(ca[k], cb[k]) for k in set(ca) | set(cb))
    if overlap == 0:
        return 0.0
    precision = overlap / max(1, len(bt))
    recall = overlap / max(1, len(at))
    return 2 * precision * recall / max(1e-12, precision + recall)


def safe_float(x: Any) -> Optional[float]:
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return None
    try:
        v = float(x)
    except Exception:
        return None
    if math.isnan(v):
        return None
    return v


def mean_or_none(vals: Iterable[Optional[float]]) -> Optional[float]:
    arr = [v for v in vals if v is not None]
    if not arr:
        return None
    return float(sum(arr) / len(arr))


def pearson(x: List[float], y: List[float]) -> Optional[float]:
    if len(x) < 2 or len(y) < 2:
        return None
    xv = np.asarray(x, dtype=float)
    yv = np.asarray(y, dtype=float)
    if np.std(xv) == 0 or np.std(yv) == 0:
        return None
    return float(np.corrcoef(xv, yv)[0, 1])


def rankdata(values: List[float]) -> List[float]:
    order = np.argsort(values)
    ranks = np.empty(len(values), dtype=float)
    i = 0
    while i < len(values):
        j = i
        while j + 1 < len(values) and values[order[j + 1]] == values[order[i]]:
            j += 1
        rank = (i + j) / 2 + 1
        for k in range(i, j + 1):
            ranks[order[k]] = rank
        i = j + 1
    return ranks.tolist()


def spearman(x: List[float], y: List[float]) -> Optional[float]:
    if len(x) < 2 or len(y) < 2:
        return None
    rx = rankdata(x)
    ry = rankdata(y)
    return pearson(rx, ry)


def write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    fieldnames: List[str] = []
    seen = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.add(key)
                fieldnames.append(key)
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


@dataclass
class RunBundle:
    model: str
    cat: str
    run_dir: Path
    summary_path: Path
    per_sample_path: Path
    unified_path: Path
    trace_dir: Path


def locate_run_bundle(model: str, cat: str, run_dir: Path) -> RunBundle:
    recomputed_summary = RECOMPUTED_DIR / f"summary.{model}.{cat}.json"
    recomputed_per_sample = RECOMPUTED_DIR / f"per_sample.{model}.{cat}.csv"
    if recomputed_summary.exists() and recomputed_per_sample.exists():
        summary_path = recomputed_summary
        per_sample_path = recomputed_per_sample
    else:
        summary_path = next(run_dir.glob("summary.*.json"))
        per_sample_path = next(run_dir.glob("per_sample.*.csv"))
    model_dir = [p for p in run_dir.iterdir() if p.is_dir() and p.name != "figures"]
    if len(model_dir) != 1:
        raise RuntimeError(f"Expected exactly one model dir in {run_dir}, found {model_dir}")
    trace_dir = model_dir[0]
    unified_path = next(trace_dir.glob("unified.*.jsonl"))
    return RunBundle(
        model=model,
        cat=cat,
        run_dir=run_dir,
        summary_path=summary_path,
        per_sample_path=per_sample_path,
        unified_path=unified_path,
        trace_dir=trace_dir,
    )


def load_unified_answers(path: Path) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    with path.open() as f:
        for line in f:
            row = json.loads(line)
            meta = row.get("meta") or {}
            sample_id = (
                meta.get("sample_id")
                or meta.get("id")
                or meta.get("uuid")
                or meta.get("record_id")
            )
            gold = (row.get("gold") or {}).get("final_answer") or {}
            pred = (row.get("pred") or {}).get("final_answer") or {}
            out[str(sample_id)] = {
                "sample_id": str(sample_id),
                "gold_answer": gold.get("answer"),
                "gold_type": gold.get("answer_type"),
                "gold_aliases": gold.get("aliases") or [],
                "pred_answer": pred.get("answer"),
                "pred_reasoning": pred.get("reasoning"),
            }
    return out


def load_gold_aliases(path: Path) -> Dict[str, List[str]]:
    with path.open() as f:
        records = json.load(f)
    out: Dict[str, List[str]] = {}
    for rec in records:
        sample_id = str((rec.get("meta") or {}).get("id", ""))
        aliases = ((((rec.get("gold") or {}).get("final_answer") or {}).get("aliases")) or [])
        out[sample_id] = [str(a) for a in aliases]
    return out


def inspect_trace_statuses(trace_dir: Path) -> Tuple[Counter, Counter, Counter]:
    status_counter: Counter = Counter()
    tool_counter: Counter = Counter()
    tool_success_counter: Counter = Counter()
    for trace_path in trace_dir.glob("execution_trace_*.json"):
        with trace_path.open() as f:
            trace = json.load(f)
        if not isinstance(trace, list):
            continue
        for step in trace:
            if not isinstance(step, dict):
                continue
            status = str(step.get("status") or "missing")
            status_counter[status] += 1
            tool_id = step.get("tool_id")
            if tool_id:
                tool_counter[str(tool_id)] += 1
                if status == "executed":
                    tool_success_counter[str(tool_id)] += 1
    return status_counter, tool_counter, tool_success_counter


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    canonical_aliases = {cat: load_gold_aliases(path) for cat, path in GOLD_DATASET.items()}
    bundles: List[RunBundle] = []
    for model, cats in RUNS.items():
        for cat, run_dir in cats.items():
            bundles.append(locate_run_bundle(model, cat, run_dir))

    completeness_rows: List[Dict[str, Any]] = []
    summary_rows: List[Dict[str, Any]] = []
    per_sample_audit_rows: List[Dict[str, Any]] = []
    answer_rows: List[Dict[str, Any]] = []
    suspicious_positive_rows: List[Dict[str, Any]] = []
    suspicious_negative_rows: List[Dict[str, Any]] = []
    tool_rows: List[Dict[str, Any]] = []
    controlled_rows: List[Dict[str, Any]] = []

    per_sample_by_model_cat: Dict[Tuple[str, str], pd.DataFrame] = {}

    for bundle in bundles:
        with bundle.summary_path.open() as f:
            summary = json.load(f)
        overall = summary["_overall"]
        completeness_rows.append(
            {
                "model": bundle.model,
                "cat": bundle.cat,
                "summary_exists": bundle.summary_path.exists(),
                "per_sample_exists": bundle.per_sample_path.exists(),
                "unified_exists": bundle.unified_path.exists(),
                "trace_count": len(list(bundle.trace_dir.glob("execution_trace_*.json"))),
                "num_samples": overall["num_samples"],
                "parse_errors": overall["parse_errors"],
            }
        )
        summary_rows.append(
            {
                "model": bundle.model,
                "model_display": MODEL_DISPLAY[bundle.model],
                "cat": bundle.cat,
                "group": CAT_LABEL[bundle.cat],
                "num_samples": overall["num_samples"],
                "parse_errors": overall["parse_errors"],
                "parse_error_rate": overall["parse_error_rate"],
                "plan_node_f1": overall["plan"]["node_f1"],
                "plan_edge_f1": overall["plan"]["edge_f1"],
                "plan_semantic_edge_f1": overall["plan"]["semantic_edge_f1"],
                "plan_dw_order_f1": overall["plan"]["dw_order_f1"],
                "planning_score": overall["plan"]["planning_score"],
                "tool_name_f1": overall["tool"]["tool_name_f1"],
                "param_name_f1": overall["tool"]["param_name_f1"],
                "type_aware_value_f1": overall["tool"]["type_aware_value_f1"],
                "tool_usage_score": overall["tool"]["tool_usage_score"],
                "gt_aligned_tool_success_rate": overall["tool"]["gt_aligned_tool_success_rate"],
                "pred_exec_success_rate": overall["tool"]["pred_exec_success_rate"],
                "observation_support_rate": overall["tool"]["observation_support_rate"],
                "exact_match": overall["answer"]["exact_match"],
                "token_f1": overall["answer"]["token_f1"],
                "llm_judge_score": overall["answer"]["llm_judge_score"],
            }
        )

        df = pd.read_csv(bundle.per_sample_path)
        per_sample_by_model_cat[(bundle.model, bundle.cat)] = df.copy()

        missing_cols = [c for c in REQUIRED_PER_SAMPLE_COLUMNS if c not in df.columns]
        out_of_range = {}
        nan_counts = {}
        for col in UNIT_INTERVAL_COLUMNS:
            if col in df.columns:
                vals = pd.to_numeric(df[col], errors="coerce")
                nan_counts[col] = int(vals.isna().sum())
                bad = vals[(~vals.isna()) & ((vals < -1e-9) | (vals > 1 + 1e-9))]
                out_of_range[col] = int(len(bad))
        per_sample_audit_rows.append(
            {
                "model": bundle.model,
                "model_display": MODEL_DISPLAY[bundle.model],
                "cat": bundle.cat,
                "rows": len(df),
                "missing_required_columns": ", ".join(missing_cols),
                "missing_required_count": len(missing_cols),
                "nan_total_unit_interval_fields": int(sum(nan_counts.values())),
                "out_of_range_total": int(sum(out_of_range.values())),
                "parse_error_sum": int(pd.to_numeric(df.get("parse_error", 0), errors="coerce").fillna(0).sum()),
            }
        )

        unified_answers = load_unified_answers(bundle.unified_path)
        for _, row in df.iterrows():
            sample_id = str(row["sample_id"])
            ans = unified_answers.get(sample_id, {})
            gold_answer = ans.get("gold_answer")
            pred_answer = ans.get("pred_answer")
            gold_aliases = canonical_aliases.get(bundle.cat, {}).get(sample_id) or (ans.get("gold_aliases") or [])
            gold_norm = normalize_text(gold_answer)
            pred_norm = normalize_text(pred_answer)
            raw_exact = int(bool(gold_norm) and gold_norm == pred_norm)
            alias_hit = int(any(normalize_text(a) == pred_norm for a in gold_aliases))
            token_sim = multiset_token_f1(str(gold_answer or ""), str(pred_answer or ""))
            exact_match = safe_float(row.get("exact_match")) or 0.0
            token_f1 = safe_float(row.get("token_f1")) or 0.0
            llm_judge = safe_float(row.get("llm_judge_score"))
            answer_row = {
                "model": bundle.model,
                "model_display": MODEL_DISPLAY[bundle.model],
                "cat": bundle.cat,
                "sample_id": sample_id,
                "exact_match": exact_match,
                "token_f1": token_f1,
                "llm_judge_score": llm_judge,
                "raw_exact": raw_exact,
                "alias_hit_raw": alias_hit,
                "raw_token_f1": token_sim,
                "gold_answer": gold_answer,
                "pred_answer": pred_answer,
            }
            answer_rows.append(answer_row)

            if exact_match >= 1.0 and not raw_exact and not alias_hit:
                suspicious_positive_rows.append(answer_row)
            if exact_match < 1.0 and (token_f1 >= 0.8 or (llm_judge is not None and llm_judge >= 0.8) or token_sim >= 0.8):
                suspicious_negative_rows.append(answer_row)

            if bundle.cat == "A":
                controlled_rows.append(
                    {
                        "model": bundle.model,
                        "model_display": MODEL_DISPLAY[bundle.model],
                        "sample_id": sample_id,
                        "planning_score": safe_float(row.get("planning_score")),
                        "exact_match": exact_match,
                        "token_f1": token_f1,
                        "parse_error": safe_float(row.get("parse_error")) or 0.0,
                        "pred_exec_success_rate": safe_float(row.get("pred_exec_success_rate")),
                        "gt_aligned_tool_success_rate": safe_float(row.get("gt_aligned_tool_success_rate")),
                    }
                )

        status_counter, tool_counter, tool_success_counter = inspect_trace_statuses(bundle.trace_dir)
        for tool_id, count in sorted(tool_counter.items()):
            succ = tool_success_counter.get(tool_id, 0)
            tool_rows.append(
                {
                    "model": bundle.model,
                    "model_display": MODEL_DISPLAY[bundle.model],
                    "cat": bundle.cat,
                    "tool_id": tool_id,
                    "calls": count,
                    "executed": succ,
                    "non_executed": count - succ,
                    "exec_rate": succ / count if count else None,
                }
            )
        tool_rows.append(
            {
                "model": bundle.model,
                "model_display": MODEL_DISPLAY[bundle.model],
                "cat": bundle.cat,
                "tool_id": "__status_summary__",
                "calls": sum(status_counter.values()),
                "executed": status_counter.get("executed", 0),
                "non_executed": sum(v for k, v in status_counter.items() if k != "executed"),
                "exec_rate": status_counter.get("executed", 0) / max(1, sum(status_counter.values())),
                "status_breakdown": json.dumps(dict(status_counter), ensure_ascii=False),
            }
        )

    summary_df = pd.DataFrame(summary_rows)
    # Weighted aggregate for 7-model pool.
    weighted_rows: List[Dict[str, Any]] = []
    for model, group in summary_df.groupby("model"):
        row: Dict[str, Any] = {
            "model": model,
            "model_display": MODEL_DISPLAY[model],
        }
        total_w = sum(GROUP_WEIGHTS.values())
        for metric in [
            "planning_score",
            "gt_aligned_tool_success_rate",
            "exact_match",
            "token_f1",
            "tool_usage_score",
            "type_aware_value_f1",
            "pred_exec_success_rate",
            "observation_support_rate",
        ]:
            row[f"weighted_{metric}"] = float(
                sum(float(r[metric]) * GROUP_WEIGHTS[r["cat"]] for _, r in group.iterrows()) / total_w
            )
        weighted_rows.append(row)

    # Controlled subset analyses at thresholds 0.1-0.9.
    controlled_df = pd.DataFrame(controlled_rows)
    threshold_rows: List[Dict[str, Any]] = []
    for thr in [round(x, 2) for x in np.arange(0.1, 1.0, 0.05)]:
        subset = controlled_df[
            (controlled_df["parse_error"] <= 0)
            & (controlled_df["pred_exec_success_rate"] >= 1.0 - 1e-9)
            & (controlled_df["gt_aligned_tool_success_rate"] >= thr - 1e-9)
        ].copy()
        subset = subset.dropna(subset=["planning_score", "exact_match"])
        if len(subset) == 0:
            continue
        xs = subset["planning_score"].astype(float).tolist()
        ys = subset["exact_match"].astype(float).tolist()
        subset = subset.sort_values("planning_score")
        mid = len(subset) // 2
        lower = subset.iloc[:mid]
        upper = subset.iloc[mid:]
        threshold_rows.append(
            {
                "ats_threshold": thr,
                "n": int(len(subset)),
                "solve_rate": float(subset["exact_match"].mean()),
                "pearson_r": pearson(xs, ys),
                "spearman_rho": spearman(xs, ys),
                "mean_plan_em0": float(subset[subset["exact_match"] < 1.0]["planning_score"].mean()) if len(subset[subset["exact_match"] < 1.0]) else None,
                "mean_plan_em1": float(subset[subset["exact_match"] >= 1.0]["planning_score"].mean()) if len(subset[subset["exact_match"] >= 1.0]) else None,
                "lower_half_solve_rate": float(lower["exact_match"].mean()) if len(lower) else None,
                "upper_half_solve_rate": float(upper["exact_match"].mean()) if len(upper) else None,
            }
        )

    threshold_df = pd.DataFrame(threshold_rows)

    # Compare current 7-model pool against the previous 5-model pool used in paper.
    previous_pool = {
        "Llama-4-Maverick-17B-128E-Instruct-FP8",
        "Llama-3.3-70B-Instruct",
        "gpt-oss-120b",
        "gpt-oss-20b",
        "Mistral-Small-3.2-24B-Instruct-2506",
    }
    pool_compare_rows: List[Dict[str, Any]] = []
    for pool_name, pool_models in [
        ("previous_5_model_pool", previous_pool),
        ("current_7_model_pool", set(RUNS.keys())),
    ]:
        for thr in [0.3, 0.5]:
            subset = controlled_df[
                controlled_df["model"].isin(pool_models)
                & (controlled_df["parse_error"] <= 0)
                & (controlled_df["pred_exec_success_rate"] >= 1.0 - 1e-9)
                & (controlled_df["gt_aligned_tool_success_rate"] >= thr - 1e-9)
            ].copy()
            subset = subset.dropna(subset=["planning_score", "exact_match"])
            if len(subset) == 0:
                continue
            xs = subset["planning_score"].astype(float).tolist()
            ys = subset["exact_match"].astype(float).tolist()
            subset = subset.sort_values("planning_score")
            mid = len(subset) // 2
            lower = subset.iloc[:mid]
            upper = subset.iloc[mid:]
            pool_compare_rows.append(
                {
                    "pool": pool_name,
                    "ats_threshold": thr,
                    "n": int(len(subset)),
                    "solve_rate": float(subset["exact_match"].mean()),
                    "pearson_r": pearson(xs, ys),
                    "spearman_rho": spearman(xs, ys),
                    "lower_half_solve_rate": float(lower["exact_match"].mean()) if len(lower) else None,
                    "upper_half_solve_rate": float(upper["exact_match"].mean()) if len(upper) else None,
                }
            )

    # Model-level tool behavior.
    tool_df = pd.DataFrame(tool_rows)
    model_tool_behavior_rows: List[Dict[str, Any]] = []
    for model, group in tool_df[tool_df["tool_id"] != "__status_summary__"].groupby("model"):
        total_calls = int(group["calls"].sum())
        total_executed = int(group["executed"].sum())
        top = group.sort_values("calls", ascending=False).head(5)
        status_row = tool_df[(tool_df["model"] == model) & (tool_df["tool_id"] == "__status_summary__")]
        status_breakdown = status_row.iloc[0]["status_breakdown"] if len(status_row) else "{}"
        model_tool_behavior_rows.append(
            {
                "model": model,
                "model_display": MODEL_DISPLAY[model],
                "total_calls": total_calls,
                "total_executed": total_executed,
                "overall_exec_rate": total_executed / total_calls if total_calls else None,
                "top_tools": "; ".join(f"{r.tool_id}:{int(r.calls)}" for r in top.itertuples()),
                "status_breakdown": status_breakdown,
            }
        )

    write_csv(OUTPUT_DIR / "completeness_audit.csv", completeness_rows)
    write_csv(OUTPUT_DIR / "summary_metrics_by_run.csv", summary_rows)
    write_csv(OUTPUT_DIR / "per_sample_audit.csv", per_sample_audit_rows)
    write_csv(OUTPUT_DIR / "answer_rows.csv", answer_rows)
    write_csv(OUTPUT_DIR / "suspicious_em_positive_candidates.csv", suspicious_positive_rows)
    write_csv(OUTPUT_DIR / "suspicious_em_negative_candidates.csv", suspicious_negative_rows)
    write_csv(OUTPUT_DIR / "tool_trace_stats_by_run.csv", tool_rows)
    write_csv(OUTPUT_DIR / "weighted_results_7_model_pool.csv", weighted_rows)
    write_csv(OUTPUT_DIR / "controlled_subset_threshold_sweep.csv", threshold_rows)
    write_csv(OUTPUT_DIR / "controlled_subset_pool_compare.csv", pool_compare_rows)
    write_csv(OUTPUT_DIR / "tool_behavior_by_model.csv", model_tool_behavior_rows)

    manifest = {
        "output_dir": str(OUTPUT_DIR),
        "runs": {m: {c: str(p) for c, p in cats.items()} for m, cats in RUNS.items()},
        "generated_files": sorted(p.name for p in OUTPUT_DIR.iterdir()),
    }
    with (OUTPUT_DIR / "manifest.json").open("w") as f:
        json.dump(manifest, f, indent=2)


if __name__ == "__main__":
    main()
