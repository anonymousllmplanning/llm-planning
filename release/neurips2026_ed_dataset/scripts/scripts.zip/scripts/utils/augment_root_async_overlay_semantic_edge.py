#!/usr/bin/env python3
"""
Augment existing root-async Cat A overlay diagnostics with chain-GT Semantic Edge F1.

This keeps the previously computed async-aware diagnostics intact, and only adds
the missing chain-ground-truth semantic-edge signal that is already available in
the evaluator.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List

from src.evaluation.metrics import ASTEvaluationSystem, _semantic_node_match_scores


def _load_jsonl_robust(path: Path) -> List[Dict[str, Any]]:
    text = path.read_text()
    buf: List[str] = []
    depth = 0
    in_str = False
    escape = False
    records: List[Dict[str, Any]] = []

    for ch in text:
        buf.append(ch)
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    payload = "".join(buf).strip()
                    if payload:
                        records.append(json.loads(payload))
                    buf = []
    return records


def _mean(values: Iterable[float]) -> float:
    vals = list(values)
    return sum(vals) / len(vals) if vals else 0.0


def _step_coverage_scores(
    gold_nodes: List[Dict[str, Any]],
    pred_nodes: List[Dict[str, Any]],
) -> float:
    gold_indices = {node.get("step_index", i) for i, node in enumerate(gold_nodes)}
    pred_indices = {node.get("step_index", i) for i, node in enumerate(pred_nodes)}
    inter = len(gold_indices & pred_indices)
    precision = inter / len(pred_indices) if pred_indices else (1.0 if not gold_indices else 0.0)
    recall = inter / len(gold_indices) if gold_indices else (1.0 if not pred_indices else 0.0)
    return 0.0 if precision + recall == 0 else 2 * precision * recall / (precision + recall)


def _metrics_by_id(unified_jsonl: Path) -> Dict[str, Dict[str, float]]:
    evaluator = ASTEvaluationSystem(use_embeddings=False, verifier_model=None)
    rows: Dict[str, Dict[str, float]] = {}
    for rec in _load_jsonl_robust(unified_jsonl):
        gold_dag = (rec.get("gold") or {}).get("plan_dag") or {"nodes": [], "edges": []}
        pred_dag = (rec.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []}
        scores = evaluator.evaluate_plan_dag(gold_dag, pred_dag)
        g_nodes = gold_dag.get("nodes") or []
        p_nodes = pred_dag.get("nodes") or []
        node_p, node_r, node_f1 = _semantic_node_match_scores(g_nodes, p_nodes)
        rows[rec["meta"]["id"]] = {
            "step_coverage_f1": _step_coverage_scores(g_nodes, p_nodes),
            "node_f1": float(node_f1),
            "node_precision": float(node_p),
            "node_recall": float(node_r),
            "label_sim": float(scores.node_label_similarity),
            "ssi": float(scores.ssi),
            "edge_f1": float(scores.edge_f1),
            "semantic_edge_f1": float(scores.semantic_edge_f1),
        }
    return rows


def _augment_per_sample(
    input_csv: Path,
    metric_map: Dict[str, Dict[str, float]],
    output_csv: Path,
) -> List[Dict[str, str]]:
    with input_csv.open() as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    fieldnames = list(reader.fieldnames or [])
    desired_columns = [
        "step_coverage_f1_chain",
        "node_f1_chain",
        "node_precision_chain",
        "node_recall_chain",
        "label_sim_chain",
        "ssi_chain",
        "edge_f1_chain",
        "semantic_edge_f1_chain",
    ]
    if "semantic_edge_f1_chain" not in fieldnames:
        insert_after = "edge_f1_strict" if "edge_f1_strict" in fieldnames else fieldnames[-1]
        idx = fieldnames.index(insert_after) + 1
        for col in desired_columns:
            if col not in fieldnames:
                fieldnames.insert(idx, col)
                idx += 1

    for row in rows:
        vals = metric_map.get(row["id"], {})
        for col in desired_columns:
            key = col.replace("_chain", "")
            row[col] = f"{vals.get(key, 0.0):.16f}".rstrip("0").rstrip(".")

    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return rows


def _summary_rows(
    per_sample_rows: List[Dict[str, str]],
    model_label: str,
) -> List[Dict[str, str]]:
    out = []
    for split in ["All 127", "Multi-order 40"]:
        if split == "All 127":
            subset = per_sample_rows
        else:
            subset = [r for r in per_sample_rows if int(r["total_orderings"]) > 1]
        out.append(
            {
                "model": model_label,
                "split": split,
                "step_coverage_f1": f"{_mean(float(r['step_coverage_f1_chain']) for r in subset):.16f}",
                "node_f1": f"{_mean(float(r['node_f1_chain']) for r in subset):.16f}",
                "node_precision": f"{_mean(float(r['node_precision_chain']) for r in subset):.16f}",
                "node_recall": f"{_mean(float(r['node_recall_chain']) for r in subset):.16f}",
                "label_sim": f"{_mean(float(r['label_sim_chain']) for r in subset):.16f}",
                "ssi": f"{_mean(float(r['ssi_chain']) for r in subset):.16f}",
                "edge_f1": f"{_mean(float(r['edge_f1_chain']) for r in subset):.16f}",
                "semantic_edge_f1": f"{_mean(float(r['semantic_edge_f1_chain']) for r in subset):.16f}",
                "plan_strict": f"{_mean(float(r['plan_strict']) for r in subset):.16f}",
                "plan_loose_dw_tcf1": f"{_mean(float(r['plan_loose_dw']) for r in subset):.16f}",
                "plan_loose_p": f"{_mean(float(r['plan_loose_p']) for r in subset):.16f}",
                "tcp": f"{_mean(float(r['tcp_chain']) for r in subset):.16f}",
                "tcr": f"{_mean(float(r['tcr_chain']) for r in subset):.16f}",
                "dw_tcf1": f"{_mean(float(r['dwtcf1_chain']) for r in subset):.16f}",
                "ipr": f"{_mean(float(r['ipr_async']) for r in subset):.16f}",
                "ocr": f"{_mean(float(r['ocr_async']) for r in subset):.16f}",
                "cpe": f"{_mean(float(r['cpe_async']) for r in subset):.16f}",
                "pred_parallelism": f"{_mean(float(r['pred_parallelism']) for r in subset):.16f}",
            }
        )
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--llama-unified", type=Path, required=True)
    parser.add_argument("--gptoss-unified", type=Path, required=True)
    parser.add_argument("--llama-input", type=Path, required=True)
    parser.add_argument("--gptoss-input", type=Path, required=True)
    parser.add_argument("--llama-output", type=Path, required=True)
    parser.add_argument("--gptoss-output", type=Path, required=True)
    parser.add_argument("--summary-output", type=Path, required=True)
    args = parser.parse_args()

    llama_sem = _metrics_by_id(args.llama_unified)
    gpt_sem = _metrics_by_id(args.gptoss_unified)

    llama_rows = _augment_per_sample(args.llama_input, llama_sem, args.llama_output)
    gpt_rows = _augment_per_sample(args.gptoss_input, gpt_sem, args.gptoss_output)

    summary_rows = _summary_rows(llama_rows, "Llama-4") + _summary_rows(gpt_rows, "gpt-oss-120b")
    fieldnames = list(summary_rows[0].keys())
    args.summary_output.parent.mkdir(parents=True, exist_ok=True)
    with args.summary_output.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(summary_rows)


if __name__ == "__main__":
    main()
