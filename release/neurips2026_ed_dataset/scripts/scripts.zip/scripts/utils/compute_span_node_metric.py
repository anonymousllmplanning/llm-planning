#!/usr/bin/env python3
"""
Compute a compression-aware replacement for one-to-one semantic Node F1.

Current Node F1 is semantic but still one-to-one. This script prototypes
"Span-Node F1", which lets one predicted node cover a short, local span of
gold nodes when that span is semantically aligned to a compressed
execution-oriented node.

Design choices:
- candidate gold spans are contiguous in step_index order
- span size is bounded (default: <= 3)
- multi-node spans must form a connected dependency span in the gold DAG
- span similarity uses the same semantic node matcher against a pseudo-node
  built from the span labels and tool alternatives
- final assignment is non-overlapping on gold nodes and one-span-per-pred-node
- objective maximizes similarity-weighted gold coverage

The resulting metric is:
    precision = matched_pred_nodes / |pred_nodes|
    recall    = covered_gold_nodes / |gold_nodes|
    span_node_f1 = harmonic_mean(precision, recall)

We then compare:
    old_planning_score = (node_f1 + dw_order_f1) / 2
    new_planning_score = (span_node_f1 + dw_order_f1) / 2
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.evaluation.metrics import (
    _f1_from_prec_recall,
    _get_acceptable_tool_ids,
    _get_acceptable_tool_names,
    _infer_step_type,
    _semantic_node_similarity,
)


CORE_MODELS = [
    "Llama-4-Maverick-17B-128E-Instruct-FP8",
    "Llama-3.3-70B-Instruct",
    "Mistral-Small-3.2-24B-Instruct-2506",
    "gpt-oss-120b",
    "gpt-oss-20b",
]

CAT_WEIGHTS = {"A": 127, "B": 25, "C": 10, "D": 3}


@dataclass(frozen=True)
class SpanCandidate:
    pred_idx: int
    gold_indices: Tuple[int, ...]
    similarity: float
    objective: float


def _sorted_gold_nodes(nodes: Sequence[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[int]]:
    indexed = list(enumerate(nodes))
    indexed.sort(key=lambda item: (item[1].get("step_index", item[0]), item[0]))
    sorted_nodes = [node for _, node in indexed]
    original_indices = [idx for idx, _ in indexed]
    return sorted_nodes, original_indices


def _build_undirected_adjacency(nodes: Sequence[Dict[str, Any]], edges: Sequence[Dict[str, Any]]) -> Dict[int, Set[int]]:
    id_to_idx = {n.get("node_id", ""): i for i, n in enumerate(nodes)}
    adj: Dict[int, Set[int]] = {i: set() for i in range(len(nodes))}
    for e in edges or []:
        source = e.get("source")
        target = e.get("target")
        sources = source if isinstance(source, list) else ([source] if source else [])
        targets = target if isinstance(target, list) else ([target] if target else [])
        for s in sources:
            si = id_to_idx.get(s)
            if si is None:
                continue
            for t in targets:
                ti = id_to_idx.get(t)
                if ti is None or ti == si:
                    continue
                adj[si].add(ti)
                adj[ti].add(si)
    return adj


def _is_connected_dependency_span(indices: Sequence[int], adj: Dict[int, Set[int]]) -> bool:
    if len(indices) <= 1:
        return True
    node_set = set(indices)
    stack = [indices[0]]
    seen = {indices[0]}
    while stack:
        cur = stack.pop()
        for nxt in adj.get(cur, set()):
            if nxt in node_set and nxt not in seen:
                seen.add(nxt)
                stack.append(nxt)
    return len(seen) == len(node_set)


def _make_span_pseudo_node(span_nodes: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    labels = [str(n.get("label", "") or "").strip() for n in span_nodes if str(n.get("label", "") or "").strip()]
    tool_ids: List[str] = []
    for n in span_nodes:
        tool_ids.extend(sorted(_get_acceptable_tool_ids(n)))
    tool_ids = list(dict.fromkeys(tool_ids))

    step_types = {_infer_step_type(n) for n in span_nodes}
    pseudo: Dict[str, Any] = {
        "label": " ; ".join(labels),
    }
    if len(step_types) == 1:
        pseudo["step_type"] = next(iter(step_types))
    if tool_ids:
        pseudo["tool_id"] = tool_ids[0]
        if len(tool_ids) > 1:
            pseudo["alternative_tools"] = tool_ids[1:]
    return pseudo


def _member_positive_overlap_count(span_nodes: Sequence[Dict[str, Any]], pred_node: Dict[str, Any]) -> int:
    return sum(1 for g in span_nodes if _semantic_node_similarity(g, pred_node) > 0.0)


def compute_span_node_f1(
    gold_nodes: Sequence[Dict[str, Any]],
    gold_edges: Sequence[Dict[str, Any]],
    pred_nodes: Sequence[Dict[str, Any]],
    threshold: float = 0.35,
    max_span_size: int = 3,
) -> Tuple[float, float, float]:
    """
    Compute Span-Node precision / recall / F1.

    Precision counts how many predicted nodes can be aligned to at least one
    valid gold span. Recall counts how many gold nodes are covered by the
    selected non-overlapping spans.
    """
    if not gold_nodes and not pred_nodes:
        return 1.0, 1.0, 1.0
    if not gold_nodes:
        return 0.0, 1.0, 0.0
    if not pred_nodes:
        return 1.0, 0.0, 0.0

    sorted_gold, _ = _sorted_gold_nodes(gold_nodes)
    adj = _build_undirected_adjacency(sorted_gold, gold_edges or [])

    candidates: List[SpanCandidate] = []
    for pred_idx, pred_node in enumerate(pred_nodes):
        for start in range(len(sorted_gold)):
            for span_len in range(1, max_span_size + 1):
                end = start + span_len
                if end > len(sorted_gold):
                    break
                gold_indices = tuple(range(start, end))
                if span_len > 1 and not _is_connected_dependency_span(gold_indices, adj):
                    continue
                span_nodes = [sorted_gold[i] for i in gold_indices]
                pseudo = _make_span_pseudo_node(span_nodes)
                sim = _semantic_node_similarity(pseudo, pred_node)
                if sim < threshold:
                    continue
                if span_len > 1 and _member_positive_overlap_count(span_nodes, pred_node) < 2:
                    continue
                objective = sim * span_len
                candidates.append(
                    SpanCandidate(
                        pred_idx=pred_idx,
                        gold_indices=gold_indices,
                        similarity=sim,
                        objective=objective,
                    )
                )

    by_pred: Dict[int, List[SpanCandidate]] = {}
    for cand in candidates:
        by_pred.setdefault(cand.pred_idx, []).append(cand)
    for pred_idx in list(by_pred):
        by_pred[pred_idx].sort(key=lambda c: (c.objective, c.similarity, len(c.gold_indices)), reverse=True)

    pred_order = sorted(by_pred.keys(), key=lambda idx: by_pred[idx][0].objective, reverse=True)

    @lru_cache(maxsize=None)
    def _search(pos: int, used_gold_mask: int) -> Tuple[float, int, int]:
        if pos >= len(pred_order):
            return (0.0, 0, 0)

        pred_idx = pred_order[pos]
        best = _search(pos + 1, used_gold_mask)  # skip this predicted node

        for cand in by_pred.get(pred_idx, []):
            cand_mask = 0
            for gi in cand.gold_indices:
                cand_mask |= 1 << gi
            if cand_mask & used_gold_mask:
                continue
            tail_score, tail_matched_preds, tail_covered_gold = _search(pos + 1, used_gold_mask | cand_mask)
            score = cand.objective + tail_score
            matched_preds = 1 + tail_matched_preds
            covered_gold = len(cand.gold_indices) + tail_covered_gold
            if score > best[0]:
                best = (score, matched_preds, covered_gold)
        return best

    _, matched_pred_count, covered_gold_count = _search(0, 0)
    precision = matched_pred_count / len(pred_nodes) if pred_nodes else 0.0
    recall = covered_gold_count / len(sorted_gold) if sorted_gold else 0.0
    return precision, recall, _f1_from_prec_recall(precision, recall)


def _load_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    with path.open() as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def _load_per_sample(path: Path) -> Dict[str, Dict[str, str]]:
    with path.open(newline="") as f:
        return {row["sample_id"]: row for row in csv.DictReader(f)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--manifest",
        default="organized_results/analysis/gaia_full_pool_recomputed_20260420/manifest.json",
    )
    parser.add_argument(
        "--output-dir",
        default="organized_results/analysis/span_node_metric_20260420",
    )
    parser.add_argument("--max-span-size", type=int, default=3)
    parser.add_argument("--threshold", type=float, default=0.35)
    parser.add_argument("--models", nargs="*", default=CORE_MODELS)
    args = parser.parse_args()

    manifest = json.load(open(args.manifest))
    runs = manifest["runs"]
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    per_sample_rows: List[Dict[str, Any]] = []
    summary_rows: List[Dict[str, Any]] = []

    for model in args.models:
        weighted_old = 0.0
        weighted_new = 0.0
        weighted_span = 0.0
        weighted_node = 0.0
        total_weight = 0

        for cat, weight in CAT_WEIGHTS.items():
            input_path = Path(runs[model][cat]["input"])
            per_sample_path = Path(runs[model][cat]["per_sample"])
            per_sample_lookup = _load_per_sample(per_sample_path)

            cat_rows: List[Dict[str, Any]] = []
            for obj in _load_jsonl(input_path):
                sample_id = obj["meta"]["id"]
                gold_dag = obj.get("gold", {}).get("plan_dag", {}) or {}
                pred_dag = obj.get("pred", {}).get("plan_dag", {}) or {}
                score_row = per_sample_lookup[sample_id]

                _, _, span_node_f1 = compute_span_node_f1(
                    gold_nodes=gold_dag.get("nodes") or [],
                    gold_edges=gold_dag.get("edges") or [],
                    pred_nodes=pred_dag.get("nodes") or [],
                    threshold=args.threshold,
                    max_span_size=args.max_span_size,
                )

                old_node_f1 = float(score_row["node_f1"] or 0.0)
                dw_order_f1 = float(score_row["dw_order_f1"] or 0.0)
                old_plan = float(score_row["planning_score"] or 0.0)
                new_plan = (span_node_f1 + dw_order_f1) / 2.0

                row = {
                    "model": model,
                    "cat": cat,
                    "sample_id": sample_id,
                    "old_node_f1": old_node_f1,
                    "span_node_f1": span_node_f1,
                    "dw_order_f1": dw_order_f1,
                    "old_planning_score": old_plan,
                    "new_planning_score": new_plan,
                    "delta_node": span_node_f1 - old_node_f1,
                    "delta_plan": new_plan - old_plan,
                    "gold_node_count": len(gold_dag.get("nodes") or []),
                    "pred_node_count": len(pred_dag.get("nodes") or []),
                }
                cat_rows.append(row)
                per_sample_rows.append(row)

            def _mean(key: str) -> float:
                return sum(float(r[key]) for r in cat_rows) / len(cat_rows) if cat_rows else 0.0

            summary_rows.append(
                {
                    "model": model,
                    "cat": cat,
                    "n": len(cat_rows),
                    "old_node_f1": _mean("old_node_f1"),
                    "span_node_f1": _mean("span_node_f1"),
                    "dw_order_f1": _mean("dw_order_f1"),
                    "old_planning_score": _mean("old_planning_score"),
                    "new_planning_score": _mean("new_planning_score"),
                    "delta_node": _mean("delta_node"),
                    "delta_plan": _mean("delta_plan"),
                }
            )

            weighted_old += _mean("old_planning_score") * weight
            weighted_new += _mean("new_planning_score") * weight
            weighted_span += _mean("span_node_f1") * weight
            weighted_node += _mean("old_node_f1") * weight
            total_weight += weight

        summary_rows.append(
            {
                "model": model,
                "cat": "W",
                "n": sum(CAT_WEIGHTS.values()),
                "old_node_f1": weighted_node / total_weight,
                "span_node_f1": weighted_span / total_weight,
                "dw_order_f1": "",
                "old_planning_score": weighted_old / total_weight,
                "new_planning_score": weighted_new / total_weight,
                "delta_node": (weighted_span - weighted_node) / total_weight,
                "delta_plan": (weighted_new - weighted_old) / total_weight,
            }
        )

    per_sample_out = output_dir / "per_sample_span_node_scores.csv"
    with per_sample_out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(per_sample_rows[0].keys()))
        w.writeheader()
        w.writerows(per_sample_rows)

    summary_out = output_dir / "summary_span_node_scores.csv"
    with summary_out.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(summary_rows[0].keys()))
        w.writeheader()
        w.writerows(summary_rows)

    print(per_sample_out)
    print(summary_out)


if __name__ == "__main__":
    main()
