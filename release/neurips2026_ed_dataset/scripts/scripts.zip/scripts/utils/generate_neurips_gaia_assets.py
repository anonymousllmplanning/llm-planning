#!/usr/bin/env python3
"""
Generate NeurIPS GAIA paper assets:
- native / augmented dataset statistics
- successful vs failed tool-call bar chart
- error-type percentage table
- scenario-wise main results table for selected models
"""

from __future__ import annotations

import csv
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams.update(
    {
        "font.family": "serif",
        "font.serif": [
            "TeX Gyre Termes",
            "Times New Roman",
            "Times",
            "Nimbus Roman",
            "DejaVu Serif",
        ],
        "mathtext.fontset": "stix",
        "axes.titlesize": 13,
        "axes.labelsize": 11,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,
        "legend.fontsize": 10,
        "figure.titlesize": 17,
    }
)


REPO_ROOT = Path(__file__).resolve().parents[2]
OUTPUT_DIR = REPO_ROOT / "docs" / "neurips" / "generated" / "gaia_assets"
STAGE_DIR = REPO_ROOT / "docs" / "neurips" / "generated" / "stage_diagnostics"

RUNS: Dict[str, Dict[str, Path]] = {
    "Llama-3.3-70B-Instruct": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260401_215021.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260401_195651.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260401_202615.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260401_205339.gaia_cat_D.answer",
    },
    "Llama-4-Maverick-17B-128E-Instruct-FP8": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260402_024258.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260402_010205.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260402_012221.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260402_024040.gaia_cat_D.answer",
    },
    "gpt-oss-120b": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260401_192759.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260401_205039.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260401_210524.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260401_212849.gaia_cat_D.answer",
    },
    "gpt-oss-20b": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260401_213251.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260401_235329.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260402_001456.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260402_003958.gaia_cat_D.answer",
    },
    "Mistral-Small-3.2-24B-Instruct-2506": {
        "A": REPO_ROOT / "organized_results/gaia/cat_A/20260401_180922.gaia_cat_A.answer",
        "B": REPO_ROOT / "organized_results/gaia/cat_B/20260406_000725.gaia_cat_B.answer",
        "C": REPO_ROOT / "organized_results/gaia/cat_C/20260406_002453.gaia_cat_C.answer",
        "D": REPO_ROOT / "organized_results/gaia/cat_D/20260406_004212.gaia_cat_D.answer",
    },
}

MODEL_DISPLAY = {
    "Llama-3.3-70B-Instruct": "Llama-3.3-70B",
    "Llama-4-Maverick-17B-128E-Instruct-FP8": "Llama-4",
    "gpt-oss-120b": "gpt-oss-120b",
    "gpt-oss-20b": "gpt-oss-20b",
    "Mistral-Small-3.2-24B-Instruct-2506": "Mistral",
}

SCENARIO_DESC = {
    "A": "Text-centric web reasoning",
    "B": "Document and spreadsheet reasoning",
    "C": "Vision-centered perception and recognition",
    "D": "Audio transcription and short-form audio reasoning",
}


def _mean(values: Iterable[float]) -> float:
    vals = list(values)
    return float(sum(vals) / len(vals)) if vals else 0.0


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _load_json(path: Path) -> Any:
    with path.open() as f:
        return json.load(f)


def _load_csv_rows(path: Path) -> List[Dict[str, str]]:
    with path.open() as f:
        return list(csv.DictReader(f))


def compute_dataset_stats() -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    native_paths = {
        "A": REPO_ROOT / "data.hg/GAIA/cat_A_text/gaia.cat_A.json",
        "B": REPO_ROOT / "data.hg/GAIA/cat_B_document/gaia.cat_B.json",
        "C": REPO_ROOT / "data.hg/GAIA/cat_C_vision/gaia.cat_C.json",
        "D": REPO_ROOT / "data.hg/GAIA/cat_D_audio/gaia.cat_D.json",
    }
    native_rows: List[Dict[str, Any]] = []
    total_gold_tool_calls = 0
    for cat, path in native_paths.items():
        data = _load_json(path)
        query_count = len(data)
        queries_with_attachments = 0
        attachment_files = 0
        gold_steps = 0
        gold_tool_calls = 0
        for rec in data:
            attachments = (rec.get("query") or {}).get("attachments") or []
            if attachments:
                queries_with_attachments += 1
            attachment_files += len(attachments)
            gold_tool_calls += len((rec.get("gold") or {}).get("tool_calls") or [])
            plan_dag = ((rec.get("gold") or {}).get("plan_dag") or {})
            gold_steps += len(plan_dag.get("nodes") or [])
        total_gold_tool_calls += gold_tool_calls
        native_rows.append(
            {
                "scenario": f"Cat {cat}",
                "description": SCENARIO_DESC[cat],
                "queries": query_count,
                "queries_with_attachments": queries_with_attachments,
                "attachment_files": attachment_files,
                "gold_tool_calls": gold_tool_calls,
                "avg_tool_calls": round(gold_tool_calls / query_count, 2),
                "avg_steps": round(gold_steps / query_count, 2),
            }
        )

    aug = _load_json(REPO_ROOT / "data/GAIA/DAGs/gaia_cat_A_async_plan.json")
    aug_rows: List[Dict[str, Any]] = []
    total_queries = len(aug)
    avg_orig_steps = _mean(len(rec.get("original_steps") or []) for rec in aug)
    avg_exec_steps = _mean(len(rec.get("executable_steps") or []) for rec in aug)
    avg_parallel_groups = _mean(len(rec.get("parallel_groups") or []) for rec in aug)
    avg_total_orderings = _mean(rec.get("total_orderings") or 0 for rec in aug)
    multi_order = sum(1 for rec in aug if (rec.get("total_orderings") or 0) > 1)
    aug_rows.append(
        {
            "split": "Aug. Cat A",
            "queries": total_queries,
            "avg_original_steps": round(avg_orig_steps, 2),
            "avg_executable_steps": round(avg_exec_steps, 2),
            "avg_parallel_groups": round(avg_parallel_groups, 2),
            "avg_admissible_orderings": round(avg_total_orderings, 2),
            "multi_order_queries": multi_order,
            "multi_order_pct": round(100.0 * multi_order / total_queries, 1),
        }
    )
    for cat in ["B", "C", "D"]:
        aug_rows.append(
            {
                "split": f"Aug. Cat {cat}",
                "queries": "--",
                "avg_original_steps": "--",
                "avg_executable_steps": "--",
                "avg_parallel_groups": "--",
                "avg_admissible_orderings": "--",
                "multi_order_queries": "--",
                "multi_order_pct": "--",
            }
        )
    return native_rows, aug_rows


def _find_model_subdir(run_dir: Path, model_name: str) -> Path:
    direct = run_dir / model_name
    if direct.exists():
        return direct
    normalized_target = model_name.replace("-Gaudi3", "").replace("-MI210", "")
    matches = []
    for p in run_dir.iterdir():
        if not p.is_dir():
            continue
        normalized_name = p.name.replace("-Gaudi3", "").replace("-MI210", "")
        if p.name == model_name or normalized_name == normalized_target:
            matches.append(p)
    if matches:
        return matches[0]
    raise FileNotFoundError(f"Could not find model dir for {model_name} under {run_dir}")


def _is_error_output(text: str) -> bool:
    norm = str(text or "").strip().lower()
    return (
        norm.startswith("[error]")
        or norm.startswith("error:")
        or "execution failed" in norm
        or "web browser failed" in norm
        or "failed to" in norm
    )


def _is_refusal_output(tool_id: str, text: str) -> bool:
    norm = str(text or "").lower()
    refusal_patterns = [
        "i'm sorry, but i cannot",
        "i cannot analyze images",
        "i can't analyze images",
        "cannot view or analyze images",
        "please provide a description",
        "unable to analyze the image",
        "cannot directly inspect the image",
        "cannot access the image",
    ]
    if tool_id == "image_recognition":
        return any(p in norm for p in refusal_patterns)
    return False


def _classify_error(step: Dict[str, Any]) -> str:
    status = str(step.get("status") or "")
    tool_id = str(step.get("tool_id") or "")
    output = str(step.get("output") or "")
    raw = str(step.get("raw_output") or "") + " " + str(step.get("error") or "")
    text = f"{output}\n{raw}".lower()
    if status and status != "executed":
        return "Decision Format"
    if _is_refusal_output(tool_id, text):
        return "Observation Refusal"
    if any(tok in text for tok in [
        "syntaxerror", "typeerror", "valueerror", "keyerror", "indexerror",
        "attributeerror", "nameerror", "filenotfounderror", "missing", "invalid argument",
        "execution failed", "traceback", "ssl:", "certificate verify failed"
    ]):
        return "Runtime / Arg."
    if any(tok in text for tok in [
        "403", "404", "timeout", "timed out", "connection", "network", "web browser failed",
        "download", "http", "pdf", "openresty", "apisix"
    ]):
        return "Web / Access"
    if _is_error_output(text):
        return "Runtime / Arg."
    return "Other"


def compute_tool_and_error_stats() -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], int]:
    bar_rows: List[Dict[str, Any]] = []
    error_rows: List[Dict[str, Any]] = []
    total_gold_tool_calls = 0
    native_paths = [
        REPO_ROOT / "data.hg/GAIA/cat_A_text/gaia.cat_A.json",
        REPO_ROOT / "data.hg/GAIA/cat_B_document/gaia.cat_B.json",
        REPO_ROOT / "data.hg/GAIA/cat_C_vision/gaia.cat_C.json",
        REPO_ROOT / "data.hg/GAIA/cat_D_audio/gaia.cat_D.json",
    ]
    for path in native_paths:
        for rec in _load_json(path):
            total_gold_tool_calls += len((rec.get("gold") or {}).get("tool_calls") or [])

    for model_name, cat_dirs in RUNS.items():
        success = 0
        failed = 0
        error_counter: Counter[str] = Counter()
        for _, run_dir in cat_dirs.items():
            model_dir = _find_model_subdir(run_dir, model_name)
            for trace_path in sorted(model_dir.glob("execution_trace_*.json")):
                trace = _load_json(trace_path)
                for step in trace:
                    tool_id = step.get("tool_id")
                    if not tool_id or tool_id == "submit_final_answer":
                        if str(step.get("status") or "") != "executed":
                            error_counter["Decision Format"] += 1
                        continue
                    output = str(step.get("output") or "")
                    step_failed = (
                        str(step.get("status") or "") != "executed"
                        or _is_error_output(output)
                        or _is_refusal_output(str(tool_id), output)
                    )
                    if step_failed:
                        failed += 1
                        error_counter[_classify_error(step)] += 1
                    else:
                        success += 1
        bar_rows.append(
            {
                "model": MODEL_DISPLAY[model_name],
                "successful": success,
                "failed": failed,
                "total": success + failed,
            }
        )
        total_errors = sum(error_counter.values())
        row = {"model": MODEL_DISPLAY[model_name]}
        for key in ["Decision Format", "Runtime / Arg.", "Web / Access", "Observation Refusal", "Other"]:
            pct = 100.0 * error_counter[key] / total_errors if total_errors else 0.0
            row[key] = round(pct, 2)
        error_rows.append(row)
    return bar_rows, error_rows, total_gold_tool_calls


def plot_tool_calls(bar_rows: List[Dict[str, Any]], total_gold_tool_calls: int) -> None:
    ordered = sorted(bar_rows, key=lambda row: row["total"], reverse=True)
    names = [row["model"] for row in ordered]
    succ = np.array([row["successful"] for row in ordered], dtype=float)
    fail = np.array([row["failed"] for row in ordered], dtype=float)

    fig, ax = plt.subplots(figsize=(9.6, 4.9), constrained_layout=True)
    x = np.arange(len(names))
    b1 = ax.bar(x, succ, color="#35c9b2", label="Successful")
    b2 = ax.bar(x, fail, bottom=succ, color="#ff8a5b", label="Failed")
    for idx, total in enumerate((succ + fail).tolist()):
        ax.text(idx, total + max(total * 0.015, 4), f"{int(total)}", ha="center", va="bottom", fontsize=9)
    ax.axhline(total_gold_tool_calls, color="black", linestyle=(0, (4, 3)), linewidth=1.2)
    ax.annotate(
        f"gold tool slots: {total_gold_tool_calls}",
        xy=(0.985, total_gold_tool_calls),
        xycoords=("axes fraction", "data"),
        xytext=(-4, 8),
        textcoords="offset points",
        ha="right",
        va="bottom",
        fontsize=9,
        bbox=dict(boxstyle="round,pad=0.18", facecolor="white", edgecolor="none", alpha=0.9),
    )
    ax.set_xticks(x)
    ax.set_xticklabels(names)
    ax.set_ylabel("Number of Tool Calls")
    ax.set_xlabel("Model")
    ax.legend(loc="upper right", frameon=True)
    ax.grid(axis="y", alpha=0.2)
    fig.savefig(OUTPUT_DIR / "gaia_tool_calls_success_failed.png", dpi=220, bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "gaia_tool_calls_success_failed.pdf", bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "gaia_tool_calls_success_failed.svg", bbox_inches="tight")
    plt.close(fig)


def plot_gta_style_overview(
    native_rows: List[Dict[str, Any]],
    aug_rows: List[Dict[str, Any]],
    main_rows: List[Dict[str, Any]],
) -> None:
    fig = plt.figure(figsize=(12.8, 6.2))
    gs = fig.add_gridspec(
        2,
        2,
        width_ratios=[1.7, 1.25],
        height_ratios=[1.0, 1.0],
        wspace=0.34,
        hspace=0.42,
    )

    ax_table = fig.add_subplot(gs[:, 0])
    ax_steps = fig.add_subplot(gs[0, 1])
    ax_calls = fig.add_subplot(gs[1, 1])

    fig.suptitle(
        "GAIA Overview: Native Scenarios and Augmented Planning Layer",
        fontsize=17,
        fontweight="bold",
        y=0.965,
    )

    # Left: compact table, GTA-style
    ax_table.axis("off")
    table_rows = [
        ["Cat A", "127", "0", "288", "7.97"],
        ["Cat B", "25", "25", "48", "7.16"],
        ["Cat C", "10", "10", "37", "6.90"],
        ["Cat D", "3", "3", "6", "8.00"],
        ["Aug. Cat A", "127", "--", "--", "7.25 exec."],
        ["Aug. Cat B", "--", "--", "--", "--"],
        ["Aug. Cat C", "--", "--", "--", "--"],
        ["Aug. Cat D", "--", "--", "--", "--"],
    ]
    col_labels = ["Split", "Queries", "Attach.", "GT Tool", "Steps"]
    tbl = ax_table.table(
        cellText=table_rows,
        colLabels=col_labels,
        loc="center",
        cellLoc="center",
        colLoc="center",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(10.5)
    tbl.scale(1.15, 1.5)
    for (r, c), cell in tbl.get_celld().items():
        cell.set_edgecolor("#444444")
        cell.set_linewidth(0.6)
        if r == 0:
            cell.set_facecolor("#d7eef7")
            cell.set_text_props(fontweight="bold")
        elif r <= 4:
            cell.set_facecolor("#f7f7f7")
        else:
            cell.set_facecolor("#f5ecff")
    ax_table.set_title("Basic Statistics", fontsize=13, fontweight="bold", pad=10)
    ax_table.text(
        0.5,
        0.04,
        "Augmented Cat A currently exposes 40 multi-order tasks\nwith 31.5% multi-order coverage.",
        ha="center",
        va="bottom",
        fontsize=10.5,
        transform=ax_table.transAxes,
    )

    # Top middle: step profile
    native_names = [row["scenario"] for row in native_rows]
    native_steps = [float(row["avg_steps"]) for row in native_rows]
    aug_cat_a = next(row for row in aug_rows if row["split"] == "Aug. Cat A")
    labels = native_names + ["Aug. A (orig)", "Aug. A (exec)"]
    values = native_steps + [float(aug_cat_a["avg_original_steps"]), float(aug_cat_a["avg_executable_steps"])]
    colors = ["#8ecae6", "#8ecae6", "#8ecae6", "#8ecae6", "#cdb4db", "#bde0fe"]
    y = np.arange(len(labels))
    ax_steps.barh(y, values, color=colors, edgecolor="#555555", linewidth=0.6)
    for i, val in enumerate(values):
        ax_steps.text(val + 0.08, i, f"{val:.2f}", va="center", fontsize=9)
    ax_steps.set_yticks(y)
    ax_steps.set_yticklabels(labels)
    ax_steps.invert_yaxis()
    ax_steps.set_xlabel("Average steps")
    ax_steps.set_title("Step Profile", fontsize=12.5, fontweight="bold")
    ax_steps.grid(axis="x", alpha=0.25, linestyle="--")
    ax_steps.spines["top"].set_visible(False)
    ax_steps.spines["right"].set_visible(False)

    # Bottom middle: attachments and tool calls
    attach = [int(row["attachment_files"]) for row in native_rows]
    tools = [int(row["gold_tool_calls"]) for row in native_rows]
    x = np.arange(len(native_names))
    width = 0.36
    ax_calls.bar(x - width / 2, attach, width, color="#ffcc99", label="Attachment files", edgecolor="#555555", linewidth=0.6)
    ax_calls.bar(x + width / 2, tools, width, color="#84c9b8", label="GT tool calls", edgecolor="#555555", linewidth=0.6)
    for i, (a, t) in enumerate(zip(attach, tools)):
        ax_calls.text(i - width / 2, a + max(0.4, a * 0.03), f"{a}", ha="center", va="bottom", fontsize=8.5)
        ax_calls.text(i + width / 2, t + max(0.4, t * 0.02), f"{t}", ha="center", va="bottom", fontsize=8.5)
    ax_calls.set_xticks(x)
    ax_calls.set_xticklabels(native_names)
    ax_calls.set_ylabel("Count")
    ax_calls.set_title("Scenario Resources", fontsize=12.5, fontweight="bold")
    ax_calls.legend(loc="upper right", frameon=False, fontsize=9)
    ax_calls.grid(axis="y", alpha=0.25, linestyle="--")
    ax_calls.spines["top"].set_visible(False)
    ax_calls.spines["right"].set_visible(False)

    fig.subplots_adjust(left=0.04, right=0.985, top=0.84, bottom=0.08, wspace=0.34, hspace=0.42)
    fig.savefig(OUTPUT_DIR / "gaia_overview_gta_style.png", dpi=220, bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "gaia_overview_gta_style.pdf", bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "gaia_overview_gta_style.svg", bbox_inches="tight")
    plt.close(fig)


def compute_main_results_table() -> List[Dict[str, Any]]:
    stage_runs = _load_csv_rows(STAGE_DIR / "gaia_stage_runs.csv")
    weighted_rows = _load_csv_rows(STAGE_DIR / "gaia_stage_weighted_models.csv")
    weighted_by_model = {row["model"]: row for row in weighted_rows}
    run_by_model_cat = {(row["model"], row["category"]): row for row in stage_runs}

    rows: List[Dict[str, Any]] = []
    current_models = list(RUNS.keys())
    for model_name in current_models:
        row: Dict[str, Any] = {
            "group": "API-based",
            "model": MODEL_DISPLAY[model_name],
        }
        for cat in ["A", "B", "C", "D"]:
            r = run_by_model_cat[(model_name, cat)]
            row[f"{cat}_plan"] = round(float(r["planning_score"]), 3)
            row[f"{cat}_tool"] = round(float(r["gt_aligned_tool_success_rate"]), 3)
            row[f"{cat}_em"] = round(float(r["exact_match"]), 3)
        wr = weighted_by_model[model_name]
        row["weighted_plan"] = round(float(wr["weighted_planning_score"]), 3)
        row["weighted_tool"] = round(float(wr["weighted_gt_aligned_tool_success_rate"]), 3)
        row["weighted_em"] = round(float(wr["weighted_em"]), 3)
        row["weighted_token_f1"] = round(float(wr["weighted_token_f1"]), 3)
        rows.append(row)

    for placeholder in ["Claude (placeholder)", "GPT-5.4 (placeholder)", "Gemini 3 (placeholder)"]:
        row = {"group": "API-based", "model": placeholder}
        for key in [
            "A_plan", "A_tool", "A_em", "B_plan", "B_tool", "B_em",
            "C_plan", "C_tool", "C_em", "D_plan", "D_tool", "D_em",
            "weighted_plan", "weighted_tool", "weighted_em", "weighted_token_f1"
        ]:
            row[key] = "--"
        rows.append(row)
    return rows


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    native_rows, aug_rows = compute_dataset_stats()
    _write_csv(OUTPUT_DIR / "gaia_native_dataset_stats.csv", native_rows)
    _write_csv(OUTPUT_DIR / "gaia_augmented_dataset_stats.csv", aug_rows)

    bar_rows, error_rows, total_gold_tool_calls = compute_tool_and_error_stats()
    _write_csv(OUTPUT_DIR / "gaia_tool_calls_success_failed.csv", bar_rows)
    _write_csv(OUTPUT_DIR / "gaia_error_type_percentages.csv", error_rows)
    plot_tool_calls(bar_rows, total_gold_tool_calls)

    main_rows = compute_main_results_table()
    _write_csv(OUTPUT_DIR / "gaia_main_results_api_models.csv", main_rows)
    plot_gta_style_overview(native_rows, aug_rows, main_rows)

    manifest = {
        "native_dataset_stats": str(OUTPUT_DIR / "gaia_native_dataset_stats.csv"),
        "augmented_dataset_stats": str(OUTPUT_DIR / "gaia_augmented_dataset_stats.csv"),
        "tool_calls_bar": str(OUTPUT_DIR / "gaia_tool_calls_success_failed.png"),
        "tool_calls_bar_pdf": str(OUTPUT_DIR / "gaia_tool_calls_success_failed.pdf"),
        "tool_calls_bar_svg": str(OUTPUT_DIR / "gaia_tool_calls_success_failed.svg"),
        "gta_style_overview": str(OUTPUT_DIR / "gaia_overview_gta_style.png"),
        "gta_style_overview_pdf": str(OUTPUT_DIR / "gaia_overview_gta_style.pdf"),
        "gta_style_overview_svg": str(OUTPUT_DIR / "gaia_overview_gta_style.svg"),
        "tool_calls_csv": str(OUTPUT_DIR / "gaia_tool_calls_success_failed.csv"),
        "error_table_csv": str(OUTPUT_DIR / "gaia_error_type_percentages.csv"),
        "main_results_csv": str(OUTPUT_DIR / "gaia_main_results_api_models.csv"),
    }
    with (OUTPUT_DIR / "manifest.json").open("w") as f:
        json.dump(manifest, f, indent=2)


if __name__ == "__main__":
    main()
