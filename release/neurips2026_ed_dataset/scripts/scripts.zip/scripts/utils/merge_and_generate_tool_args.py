#!/usr/bin/env python3
"""
Merge expanded records into gaia_mini.jsonl with auto-generated Tool Arguments.

This script:
1. Reads expanded records from gaia_expanded.jsonl
2. Generates Tool Arguments based on tools and file types
3. Merges with existing gaia_mini.jsonl
4. Analyzes missing tools
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List
from collections import Counter


# Tool name mapping: normalized name -> tools.py name
TOOL_NAME_MAPPING = {
    # Direct mappings
    'pptx_reader': 'pptx_reader',
    'pdf_reader': 'pdf_reader',
    'audio_transcription': 'audio_transcription',
    'file_reader': 'file_reader',
    'web_search': 'web_search',
    'excel_reader': 'excel_reader',
    'python_executor': 'python_executor',
    'zip_extractor': 'zip_extractor',
    'image_recognition': 'image_recognition',
    'calculator': 'calculator',
    'web_browser': 'web_browser',

    # Aliases and variations
    'speech-to-text_tool': 'audio_transcription',
    'python_compiler': 'python_executor',
    'search_engine': 'web_search',
    'image_recognition_tools': 'image_recognition',
    'pdf_viewer': 'pdf_reader',
    'python': 'python_executor',
    'ocr': 'image_recognition',  # OCR is a subset of image recognition
    'image_recognition/ocr': 'image_recognition',
    'computer_vision_or_ocr': 'image_recognition',

    # Tools that need implementation
    'file_interface': None,  # Needs to be implemented
    'bass_note_data': None,  # Domain-specific, may need custom implementation
    'c++_compiler': None,  # Not implemented
    'image_search_tools': None,  # Needs implementation
    'file_handling': 'file_reader',  # Map to file_reader
}


def normalize_tool_name(tool: str) -> str:
    """Normalize tool name to match tools.py implementation."""
    return TOOL_NAME_MAPPING.get(tool, tool)


def generate_tool_arguments(record: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Generate Tool Arguments for a record based on tools and file type.

    Returns a list of tool argument objects in the format:
    [
        {
            "tool": "tool_name",
            "arguments": [
                {"name": "arg_name", "value": "arg_value"},
                ...
            ]
        },
        ...
    ]
    """
    file_name = record['file_name']
    file_path = record['file_path']
    file_ext = '.' + file_name.split('.')[-1].lower()

    tools_str = record['Annotator Metadata']['Tools']
    tools = json.loads(tools_str)

    tool_arguments = []

    for tool in tools:
        normalized_tool = normalize_tool_name(tool)

        if normalized_tool is None:
            # Tool not implemented, skip
            continue

        args = []

        # Generate arguments based on tool type
        if normalized_tool in ['pptx_reader', 'pdf_reader', 'file_reader']:
            args.append({"name": "file_path", "value": file_path})

        elif normalized_tool == 'audio_transcription':
            args.append({"name": "file_path", "value": file_path})

        elif normalized_tool == 'image_recognition':
            # For image files
            if file_ext in ['.png', '.jpg', '.jpeg', '.gif', '.bmp']:
                args.append({"name": "file_path", "value": file_path})
                # Add task parameter if it's OCR-related
                if 'ocr' in tool.lower():
                    args.append({"name": "task", "value": "ocr"})
                else:
                    args.append({"name": "task", "value": "general"})

        elif normalized_tool == 'excel_reader':
            args.append({"name": "file_path", "value": file_path})

        elif normalized_tool == 'web_search':
            # For web search, we can't automatically determine the query
            # Leave it as a placeholder or extract from Steps
            args.append({"name": "query", "value": "<query_from_task>"})
            args.append({"name": "max_results", "value": "5"})

        elif normalized_tool == 'python_executor':
            # For Python executor, we can't automatically determine the code
            args.append({"name": "code", "value": "<code_from_task>"})

        elif normalized_tool == 'calculator':
            # For calculator, we can't automatically determine the expression
            args.append({"name": "expression", "value": "<expression_from_task>"})

        elif normalized_tool == 'web_browser':
            # For web browser, we can't automatically determine the URL
            args.append({"name": "url", "value": "<url_from_task>"})

        elif normalized_tool == 'zip_extractor':
            args.append({"name": "file_path", "value": file_path})

        # Add the tool argument entry
        if args:
            tool_arguments.append({
                "tool": normalized_tool,
                "arguments": args
            })

    return tool_arguments


def merge_records(existing_path: Path, expanded_path: Path, output_path: Path):
    """
    Merge expanded records with existing gaia_mini.jsonl.

    Steps:
    1. Read existing records
    2. Read expanded records
    3. Generate Tool Arguments for expanded records
    4. Combine and write to output
    """
    print("="*70)
    print("Merging Expanded Records with gaia_mini.jsonl")
    print("="*70)

    # Read existing records
    print(f"\n[INFO] Reading existing records from {existing_path}")
    existing_records = []
    with open(existing_path) as f:
        for line in f:
            existing_records.append(json.loads(line))
    print(f"[INFO]   Loaded {len(existing_records)} existing records")

    # Read expanded records
    print(f"\n[INFO] Reading expanded records from {expanded_path}")
    expanded_records = []
    with open(expanded_path) as f:
        for line in f:
            expanded_records.append(json.loads(line))
    print(f"[INFO]   Loaded {len(expanded_records)} expanded records")

    # Generate Tool Arguments for expanded records
    print(f"\n[INFO] Generating Tool Arguments for expanded records...")
    for i, record in enumerate(expanded_records, 1):
        task_id = record['task_id']
        print(f"  [{i}/{len(expanded_records)}] {task_id[:8]}...")

        # Generate Tool Arguments
        tool_arguments = generate_tool_arguments(record)

        # Add to Annotator Metadata
        record['Annotator Metadata']['Tool Arguments'] = tool_arguments

        # Show what was generated
        tools = json.loads(record['Annotator Metadata']['Tools'])
        print(f"      Tools: {tools}")
        print(f"      Generated {len(tool_arguments)} tool argument entries")

    # Combine records
    all_records = existing_records + expanded_records

    # Write combined output
    print(f"\n[INFO] Writing combined records to {output_path}")
    with open(output_path, 'w', encoding='utf-8') as f:
        for record in all_records:
            json_line = json.dumps(record, ensure_ascii=False)
            f.write(json_line + '\n')

    print(f"[DONE] Wrote {len(all_records)} total records")
    print(f"       - {len(existing_records)} existing")
    print(f"       - {len(expanded_records)} expanded")

    return all_records


def analyze_tools(records: List[Dict[str, Any]]):
    """Analyze tool usage and identify missing implementations."""
    print(f"\n{'='*70}")
    print("Tool Analysis")
    print("="*70)

    # Extract all tools from all records
    all_tools_raw = []
    all_tools_normalized = []

    for record in records:
        tools_str = record['Annotator Metadata']['Tools']
        tools = json.loads(tools_str)
        all_tools_raw.extend(tools)

        for tool in tools:
            normalized = normalize_tool_name(tool)
            if normalized:
                all_tools_normalized.append(normalized)

    # Count usage
    raw_counts = Counter(all_tools_raw)
    normalized_counts = Counter(all_tools_normalized)

    print("\nRaw tool names (as extracted):")
    for tool, count in raw_counts.most_common():
        print(f"  {tool}: {count}")

    print("\nNormalized tool names (mapped to tools.py):")
    for tool, count in normalized_counts.most_common():
        print(f"  {tool}: {count}")

    # Identify tools that need implementation
    print("\n" + "="*70)
    print("Tools Requiring Implementation or Mapping")
    print("="*70)

    unmapped_tools = []
    for tool in set(all_tools_raw):
        normalized = normalize_tool_name(tool)
        if normalized is None:
            unmapped_tools.append(tool)

    if unmapped_tools:
        print("\nTools that need implementation in tools.py:")
        for tool in sorted(unmapped_tools):
            count = raw_counts[tool]
            print(f"  - {tool} (used in {count} task{'s' if count > 1 else ''})")

        print("\nRecommended actions:")
        print("1. Add 'image_recognition' tool with OCR capability (covers ocr/image_recognition)")
        print("2. Consider adding 'file_interface' or mapping to 'file_reader'")
        print("3. Domain-specific tools (bass_note_data, c++_compiler) may require custom implementation")
    else:
        print("\n✓ All tools are mapped to existing implementations!")

    # Show tools.py implementations status
    print("\n" + "="*70)
    print("Tools.py Implementation Status")
    print("="*70)

    implemented_tools = {
        'web_search', 'excel_reader', 'audio_transcription', 'file_reader',
        'python_executor', 'pptx_reader', 'pdf_reader', 'zip_extractor',
        'web_browser', 'image_recognition', 'video_analysis', 'wikipedia_search',
        'calculator', 'reasoning', 'pdb_analyzer', 'date_calculator',
        'unit_converter', 'code_interpreter'
    }

    active_tools = {
        'web_search', 'excel_reader', 'audio_transcription', 'file_reader',
        'python_executor', 'pptx_reader', 'pdf_reader', 'zip_extractor'
    }

    mock_tools = implemented_tools - active_tools

    needed_tools = set(all_tools_normalized)

    print(f"\nActive tools (fully implemented): {len(active_tools)}")
    for tool in sorted(active_tools):
        status = "✓ USED" if tool in needed_tools else "  Available"
        print(f"  {status} {tool}")

    print(f"\nMock tools (placeholder implementation): {len(mock_tools)}")
    for tool in sorted(mock_tools):
        status = "⚠ USED" if tool in needed_tools else "  Available"
        print(f"  {status} {tool}")

    # Check if any needed tools are mock
    needed_mock = needed_tools & mock_tools
    if needed_mock:
        print(f"\n{'!'*70}")
        print("WARNING: These MOCK tools are used in the dataset:")
        print("!"*70)
        for tool in sorted(needed_mock):
            count = normalized_counts[tool]
            print(f"  ⚠ {tool}: used in {count} task{'s' if count > 1 else ''}")
        print("\nRecommendation: Upgrade these mock tools to active implementations")
        print("for full dataset execution capability.")


def main():
    """Main entry point."""
    existing_path = Path("gaia.mini.func/data/gaia_mini.jsonl")
    expanded_path = Path("data/gaia_expanded.jsonl")
    output_path = Path("gaia.mini.func/data/gaia_mini.jsonl")

    # Merge records
    all_records = merge_records(existing_path, expanded_path, output_path)

    # Analyze tools
    analyze_tools(all_records)

    print(f"\n{'='*70}")
    print("COMPLETE")
    print("="*70)
    print(f"✓ Updated: {output_path}")
    print(f"✓ Total records: {len(all_records)}")
    print(f"✓ Tool Arguments generated for all new records")


if __name__ == "__main__":
    main()
