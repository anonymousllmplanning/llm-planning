#!/usr/bin/env python3
from __future__ import annotations

import csv
from pathlib import Path
from typing import Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from scipy.stats import pearsonr, spearmanr


REPO_ROOT = Path(__file__).resolve().parents[2]
PAPER_DIR = REPO_ROOT / "organized_results" / "gaia" / "paper"
FIG_DIR = REPO_ROOT / "docs" / "neurips" / "generated" / "custom_figures"
TABLE_DIR = REPO_ROOT / "docs" / "neurips" / "generated" / "stage_diagnostics"

FIG_NAME = "tool_invocation_dense_main"
ATS_THRESHOLD = 0.3
TISR_THRESHOLD = 0.7

SCENARIO_MAP = {
    "gaia_cat_A": "Text Reasoning",
    "gaia_cat_B": "Document Analysis",
    "gaia_cat_C": "Vision",
    "gaia_cat_D": "Audio",
}


def _load_reviewed_rows() -> pd.DataFrame:
    rows: List[pd.DataFrame] = []
    for per_path in sorted(PAPER_DIR.glob("*/per_sample.*.csv")):
        model = per_path.stem.replace("per_sample.", "")
        review_path = per_path.parent / f"answer_review.{model}.xlsx"
        if not review_path.exists():
            continue
        per = pd.read_csv(per_path)
        review = pd.read_excel(review_path)
        if "Human Eval" not in review.columns:
            continue
        human = review["Human Eval"].astype(str).str.strip().str.lower()
        review = review[human.isin(["y", "n"])].copy()
        if review.empty:
            continue
        per["short_id"] = per["sample_id"].astype(str).str[:8] + "..."
        review["short_id"] = review["sample_id"].astype(str)
        merged = per.merge(review[["short_id", "Human Eval"]], on="short_id", how="inner")
        merged["accepted_solve"] = (
            merged["Human Eval"].astype(str).str.strip().str.lower() == "y"
        ).astype(int)
        scenario_key = per_path.parent.name.split(".")[1]
        merged["scenario"] = SCENARIO_MAP.get(scenario_key, scenario_key)
        merged["model"] = model
        rows.append(merged)
    if not rows:
        raise RuntimeError("No reviewed per-sample rows found under organized_results/gaia/paper")
    return pd.concat(rows, ignore_index=True)


def _dense_task_group(df: pd.DataFrame) -> pd.DataFrame:
    task_df = df[["scenario", "sample_id", "gold_tool_count"]].drop_duplicates()
    dense = task_df[task_df["gold_tool_count"] >= 3].copy()
    counts = (
        dense.groupby("scenario")
        .size()
        .rename("task_count")
        .reset_index()
        .sort_values(["task_count", "scenario"], ascending=[False, True])
    )
    return counts


def _tool_clean_dense_subset(df: pd.DataFrame) -> pd.DataFrame:
    subset = df[
        (df["parse_error"] == False)
        & (df["gold_tool_count"] >= 3)
        & (df["pred_tool_count"] >= 1)
        & (df["gt_aligned_tool_success_rate"] >= ATS_THRESHOLD)
        & (df["pred_exec_success_rate"] >= TISR_THRESHOLD)
    ].copy()
    return subset


def _threshold_sweep(df: pd.DataFrame) -> List[Dict[str, float]]:
    dense = df[
        (df["parse_error"] == False)
        & (df["gold_tool_count"] >= 3)
        & (df["pred_tool_count"] >= 1)
        & (df["gt_aligned_tool_success_rate"] >= ATS_THRESHOLD)
    ].copy()
    rows: List[Dict[str, float]] = []
    for thr in [0.5, 0.7, 0.9, 1.0]:
        subset = dense[dense["pred_exec_success_rate"] >= thr].copy()
        if len(subset) < 20:
            continue
        xs = subset["planning_score"].astype(float)
        ys = subset["accepted_solve"].astype(float)
        r, p_r = pearsonr(xs, ys)
        rho, p_rho = spearmanr(xs, ys)
        ordered = subset.sort_values("planning_score").reset_index(drop=True)
        lower = ordered.iloc[: len(ordered) // 2]
        upper = ordered.iloc[len(ordered) // 2 :]
        rows.append(
            {
                "tool_invocation_success_rate_threshold": thr,
                "n": int(len(subset)),
                "accepted_0_plan": float(subset.loc[subset["accepted_solve"] == 0, "planning_score"].mean()),
                "accepted_1_plan": float(subset.loc[subset["accepted_solve"] == 1, "planning_score"].mean()),
                "lower_accepted_rate": float(lower["accepted_solve"].mean()),
                "upper_accepted_rate": float(upper["accepted_solve"].mean()),
                "pearson_r": float(r),
                "pearson_p": float(p_r),
                "spearman_rho": float(rho),
                "spearman_p": float(p_rho),
            }
        )
    return rows


def _write_csv(path: Path, rows: List[Dict[str, float]]) -> None:
    if not rows:
        return
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def _make_figure(group_counts: pd.DataFrame, subset: pd.DataFrame, output_stem: Path) -> None:
    ordered = subset.sort_values("planning_score").reset_index(drop=True)
    lower = ordered.iloc[: len(ordered) // 2]
    upper = ordered.iloc[len(ordered) // 2 :]
    pearson_r, pearson_p = pearsonr(subset["planning_score"], subset["accepted_solve"])
    spearman_rho, spearman_p = spearmanr(subset["planning_score"], subset["accepted_solve"])

    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": [
                "TeX Gyre Termes",
                "Times New Roman",
                "Times",
                "Nimbus Roman",
                "DejaVu Serif",
            ],
            "mathtext.fontset": "stix",
            "axes.titlesize": 12,
            "axes.labelsize": 11,
            "xtick.labelsize": 10,
            "ytick.labelsize": 10,
        }
    )

    fig, ax_right = plt.subplots(1, 1, figsize=(6.3, 4.1))
    rates = [float(lower["accepted_solve"].mean()), float(upper["accepted_solve"].mean())]
    right_labels = ["Lower-planning half", "Higher-planning half"]
    right_colors = ["#D87B2D", "#2E8B57"]
    bars = ax_right.bar(right_labels, rates, color=right_colors, width=0.62)
    ax_right.set_title("Accepted Solve Rate in Tool-Clean Dense Subset")
    ax_right.set_ylabel("Accepted solve rate")
    ax_right.set_ylim(0, max(rates) * 1.45)
    for bar, rate in zip(bars, rates):
        ax_right.text(bar.get_x() + bar.get_width() / 2, rate + 0.01, f"{rate:.3f}", ha="center", va="bottom", fontsize=10)
    ax_right.text(
        0.03,
        0.96,
        "\n".join(
            [
                f"TISR $\\geq$ {TISR_THRESHOLD:.1f}, ATS $\\geq$ {ATS_THRESHOLD:.1f}",
                f"Reviewed rows: $n={len(subset)}$",
                f"Dense-tool tasks: {int(group_counts['task_count'].sum())}",
                "Group mix: 38 Text, 5 Vision",
                f"Pearson $r={pearson_r:.3f}$, $p={pearson_p:.3f}$",
                f"Spearman $\\rho={spearman_rho:.3f}$, $p={spearman_p:.3f}$",
            ]
        ),
        transform=ax_right.transAxes,
        va="top",
        fontsize=9,
        bbox=dict(facecolor="white", alpha=0.9, edgecolor="#d0d0d0"),
    )

    plt.tight_layout()
    output_stem.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_stem.with_suffix(".png"), dpi=240, bbox_inches="tight")
    fig.savefig(output_stem.with_suffix(".pdf"), bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    reviewed = _load_reviewed_rows()
    group_counts = _dense_task_group(reviewed)
    subset = _tool_clean_dense_subset(reviewed)
    if len(subset) < 20:
        raise RuntimeError("Tool-clean dense subset is unexpectedly small.")

    FIG_DIR.mkdir(parents=True, exist_ok=True)
    TABLE_DIR.mkdir(parents=True, exist_ok=True)

    _write_csv(TABLE_DIR / "tool_invocation_threshold_sweep.csv", _threshold_sweep(reviewed))
    _write_csv(TABLE_DIR / "tool_intensive_group_counts.csv", group_counts.to_dict(orient="records"))
    _make_figure(group_counts, subset, FIG_DIR / FIG_NAME)

    print(f"[OK] Wrote {FIG_DIR / (FIG_NAME + '.pdf')}")
    print(f"[OK] Wrote {TABLE_DIR / 'tool_invocation_threshold_sweep.csv'}")


if __name__ == "__main__":
    main()
