#!/usr/bin/env python3
"""
Model-guided replay for GAIA async ordering candidates.

This script is intentionally separate from the main inference pipeline. It does
not ask the model to create an abstract plan. Instead, it fixes a reference
ordering from the async GAIA files, asks one model to translate that fixed list
of executable steps into concrete tool invocations, and then executes those
invocations through src.inference.tools.

The output mirrors the existing tool-layer execution filter:
  - rows.csv / rows.jsonl: per-ordering VALID/INVALID decisions
  - chain_baseline.jsonl: native-chain gold-tool replay diagnostics
  - summary.json: aggregate counts
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import signal
import sys
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config.models import get_api_base, get_api_key
from src.inference.gaia_utils import resolve_attachment_path
from src.inference.prompts import get_answer_mode_tool_context, normalize_tool_environment
from src.inference.runner import generate_with_api
from src.inference.tools import TOOL_IMPLEMENTATIONS, execute_tool, normalize_submitted_answer


CATEGORY_DIRS = {
    "A": "cat_A_text",
    "B": "cat_B_document",
    "C": "cat_C_vision",
    "D": "cat_D_audio",
}

NO_TOOL_IDS = {"", "none", "null", "no_tool", "no-tool", "reasoning_only"}

ORDER_DEP_MARKERS = (
    "<n",
    "variable",
    "not found in store",
    "no such file or directory",
    "file not found",
    "does not exist",
    "cannot find",
    "missing file",
    "missing argument",
    "keyerror",
    "indexerror",
    "nameerror",
)

NOISE_MARKERS = (
    "timeout",
    "timed out",
    "403",
    "404",
    "forbidden",
    "connection",
    "network",
    "ssl",
    "temporarily unavailable",
    "rate limit",
    "ddgs",
    "duckduckgo",
    "failed to download",
    "api unavailable",
)


@dataclass
class ReplayResult:
    passed: bool
    failure_bucket: Optional[str]
    failed_step_index: Optional[int]
    failed_tool_id: Optional[str]
    failed_output: str
    steps_completed: int
    total_steps: int
    tool_calls_executed: int
    successful_tool_calls: int
    final_answer: str
    model_json_ok: bool
    trace: List[Dict[str, Any]]


@dataclass
class GoldReplayResult:
    passed: bool
    failure_bucket: Optional[str]
    failed_tool_id: Optional[str]
    failed_output: str
    successful_calls: int
    total_calls: int
    answer_match: Optional[bool]


def load_json(path: Path) -> List[Dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        data = json.load(f)
    return data if isinstance(data, list) else [data]


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    with path.open(encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def write_rows_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def append_csv(path: Path, row: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not path.exists() or path.stat().st_size == 0
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            writer.writeheader()
        writer.writerow(row)


def normalize_text(text: Any) -> str:
    text = "" if text is None else str(text)
    text = text.strip().lower()
    return re.sub(r"\s+", " ", text)


def is_success_output(output: Any) -> bool:
    text = str(output or "")
    if "Output:\n" in text:
        text = text.split("Output:\n", 1)[1]
    norm = text.strip().lower()
    return not (
        norm.startswith("[error]")
        or norm.startswith("error:")
        or norm.startswith("execution failed:")
    )


def classify_failure_bucket(output: Any) -> str:
    norm = normalize_text(output)
    if any(marker in norm for marker in ORDER_DEP_MARKERS):
        return "order_dependency"
    if any(marker in norm for marker in NOISE_MARKERS):
        return "environment_noise"
    return "other_failure"


def args_to_dict(arguments: Any) -> Dict[str, Any]:
    if isinstance(arguments, dict):
        return dict(arguments)
    if isinstance(arguments, list):
        out: Dict[str, Any] = {}
        for item in arguments:
            if isinstance(item, dict) and item.get("name"):
                out[str(item["name"])] = item.get("value")
        return out
    return {}


def resolve_variables(value: Any, var_store: Dict[str, str]) -> Any:
    if isinstance(value, str):
        matches = re.findall(r"<n\d+>|<step_\d+>", value)
        if not matches:
            return value
        if len(matches) == 1 and value.strip() == matches[0]:
            return var_store.get(matches[0], value)
        result = value
        for var_name in matches:
            if var_name in var_store:
                result = result.replace(var_name, str(var_store[var_name]))
        return result
    if isinstance(value, dict):
        return {k: resolve_variables(v, var_store) for k, v in value.items()}
    if isinstance(value, list):
        return [resolve_variables(v, var_store) for v in value]
    return value


def execute_tool_with_timeout(
    tool_id: str,
    resolved_args: Dict[str, Any],
    attachments_dir: str,
    output_dir: str,
    timeout_sec: int,
) -> str:
    if timeout_sec <= 0:
        return execute_tool(tool_id, resolved_args, attachments_dir=attachments_dir, output_dir=output_dir)

    def _handle_timeout(_signum, _frame):
        raise TimeoutError(f"tool call timed out after {timeout_sec}s")

    old_handler = signal.getsignal(signal.SIGALRM)
    signal.signal(signal.SIGALRM, _handle_timeout)
    signal.setitimer(signal.ITIMER_REAL, float(timeout_sec))
    try:
        return execute_tool(tool_id, resolved_args, attachments_dir=attachments_dir, output_dir=output_dir)
    except TimeoutError as exc:
        return f"[ERROR] {exc}"
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.0)
        signal.signal(signal.SIGALRM, old_handler)


def infer_attachments_dir(record: Dict[str, Any]) -> str:
    attachments = ((record.get("query") or {}).get("attachments") or [])
    if not attachments:
        return ""
    first = attachments[0]
    resolved = resolve_attachment_path(
        first.get("file_path"),
        first.get("file_name"),
        record=record,
    )
    return str(Path(resolved).parent) if resolved else ""


def format_attachments(record: Dict[str, Any]) -> str:
    attachments = ((record.get("query") or {}).get("attachments") or [])
    if not attachments:
        return "No attachments."
    lines = []
    for item in attachments:
        name = item.get("file_name") or Path(str(item.get("file_path") or "")).name
        path = item.get("file_path") or ""
        lines.append(f"- {name}: {path}")
    return "\n".join(lines)


def compact_tool_specs(record: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Return prompt-friendly executable tools visible for this GAIA record."""
    context = get_answer_mode_tool_context(record)
    tools = context.get("tools") or normalize_tool_environment(record)
    compact: List[Dict[str, Any]] = []
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        tool_id = str(tool.get("tool_id") or "").strip()
        if not tool_id or tool_id not in TOOL_IMPLEMENTATIONS:
            continue
        compact.append(
            {
                "tool_id": tool_id,
                "description": str(tool.get("description") or "")[:220],
                "arguments_schema": tool.get("arguments_schema") or {},
            }
        )
    return compact


def get_orderings(async_rec: Dict[str, Any]) -> Tuple[List[List[int]], str]:
    sampled = async_rec.get("sampled_orderings")
    if isinstance(sampled, list) and sampled:
        return sampled, "sampled_orderings"
    possible = async_rec.get("possible_orderings")
    if isinstance(possible, list) and possible:
        return possible, "possible_orderings"
    n = len(async_rec.get("executable_steps") or [])
    return [list(range(n))], "fallback_chain_order"


def build_node_maps(record: Dict[str, Any]) -> Tuple[Dict[str, int], Dict[str, List[str]]]:
    node_to_step: Dict[str, int] = {}
    node_to_output_vars: Dict[str, List[str]] = {}
    nodes = (((record.get("gold") or {}).get("plan_dag") or {}).get("nodes") or [])
    for node in nodes:
        node_id = str(node.get("node_id", "")).strip()
        if not node_id:
            continue
        raw_step = node.get("step_index")
        if isinstance(raw_step, int):
            node_to_step[node_id] = raw_step
        elif isinstance(raw_step, str) and raw_step.isdigit():
            node_to_step[node_id] = int(raw_step)
        vars_list = node.get("output_vars") or []
        if isinstance(vars_list, list):
            node_to_output_vars[node_id] = [str(v) for v in vars_list if isinstance(v, str) and v]
    return node_to_step, node_to_output_vars


def parse_node_step_index(node_id: str) -> Optional[int]:
    match = re.fullmatch(r"n(\d+)", node_id.strip())
    return int(match.group(1)) if match else None


def reorder_gold_tool_calls_for_ordering(async_rec: Dict[str, Any], ordering: List[int]) -> List[Dict[str, Any]]:
    calls = list(((async_rec.get("gold") or {}).get("tool_calls") or []))
    if not calls:
        return []
    node_to_step, _node_to_vars = build_node_maps(async_rec)
    raw_map = async_rec.get("step_mapping") or {}
    step_mapping: Dict[int, Optional[int]] = {}
    if isinstance(raw_map, dict):
        for key, value in raw_map.items():
            try:
                step_key = int(key)
            except Exception:
                continue
            try:
                step_mapping[step_key] = None if value is None else int(value)
            except Exception:
                step_mapping[step_key] = None

    pos = {int(step): idx for idx, step in enumerate(ordering)}
    fallback_rank = len(ordering) + 10_000

    def call_key(call: Dict[str, Any]) -> Tuple[int, int]:
        node_id = str(call.get("node_id") or "").strip()
        orig_step = node_to_step.get(node_id) if node_id in node_to_step else parse_node_step_index(node_id)
        if orig_step is None:
            rank = fallback_rank
        else:
            exec_step = step_mapping.get(orig_step, orig_step)
            rank = fallback_rank if exec_step is None else pos.get(int(exec_step), fallback_rank + int(exec_step))
        call_index = call.get("call_index")
        return rank, call_index if isinstance(call_index, int) else 0

    return sorted(calls, key=call_key)


def replay_gold_calls(
    record: Dict[str, Any],
    tool_calls: List[Dict[str, Any]],
    output_dir: Path,
    attempt_tag: str,
    tool_timeout_sec: int,
) -> GoldReplayResult:
    attempt_dir = output_dir / "runtime_artifacts" / attempt_tag
    attempt_dir.mkdir(parents=True, exist_ok=True)
    attachments_dir = infer_attachments_dir(record)
    _node_to_step, node_to_output_vars = build_node_maps(record)
    var_store: Dict[str, str] = {}

    failed_tool_id: Optional[str] = None
    failed_output = ""
    failure_bucket: Optional[str] = None
    successful_calls = 0
    submit_seen = False
    submit_answer: Any = None

    for call in tool_calls:
        tool_id = str(call.get("tool_id") or "").strip()
        call_args = args_to_dict(call.get("arguments"))
        resolved_args = resolve_variables(call_args, var_store)
        output = execute_tool_with_timeout(
            tool_id=tool_id,
            resolved_args=resolved_args,
            attachments_dir=attachments_dir,
            output_dir=str(attempt_dir),
            timeout_sec=tool_timeout_sec,
        )
        ok = is_success_output(output)
        if ok:
            successful_calls += 1
        elif failed_tool_id is None:
            failed_tool_id = tool_id
            failed_output = str(output or "")
            failure_bucket = classify_failure_bucket(output)

        node_id = str(call.get("node_id") or "").strip()
        if node_id:
            var_store[f"<{node_id}>"] = str(output or "")
            for var_name in node_to_output_vars.get(node_id, []):
                var_store[var_name] = str(output or "")

        if tool_id == "submit_final_answer":
            submit_seen = True
            submit_answer = resolved_args.get("answer")

    passed = failed_tool_id is None
    answer_match: Optional[bool] = None
    if submit_seen:
        normalized_submit, _note = normalize_submitted_answer(submit_answer)
        gold_answer = ((record.get("gold") or {}).get("final_answer") or {}).get("answer", "")
        answer_match = normalize_text(normalized_submit) == normalize_text(gold_answer)
        passed = passed and bool(answer_match)

    return GoldReplayResult(
        passed=passed,
        failure_bucket=failure_bucket,
        failed_tool_id=failed_tool_id,
        failed_output=failed_output[:1000],
        successful_calls=successful_calls,
        total_calls=len(tool_calls),
        answer_match=answer_match,
    )


def evaluate_gold_chain(
    record: Dict[str, Any],
    retries: int,
    stable_threshold: int,
    output_dir: Path,
    attempt_prefix: str,
    tool_timeout_sec: int,
) -> Tuple[int, List[GoldReplayResult]]:
    calls = list(((record.get("gold") or {}).get("tool_calls") or []))
    attempts: List[GoldReplayResult] = []
    pass_count = 0
    for i in range(retries):
        result = replay_gold_calls(
            record=record,
            tool_calls=calls,
            output_dir=output_dir,
            attempt_tag=f"{attempt_prefix}.chain_gold.try{i+1}",
            tool_timeout_sec=tool_timeout_sec,
        )
        attempts.append(result)
        if result.passed:
            pass_count += 1
        remaining = retries - (i + 1)
        if pass_count >= stable_threshold or pass_count + remaining < stable_threshold:
            break
    return pass_count, attempts


def ordering_is_valid(ordering: List[int], n_steps: int) -> bool:
    return len(ordering) == n_steps and sorted(ordering) == list(range(n_steps))


def build_action_prompt(
    record: Dict[str, Any],
    async_rec: Dict[str, Any],
    ordering: List[int],
    tools: List[Dict[str, Any]],
) -> str:
    question = (record.get("query") or {}).get("text") or async_rec.get("query") or ""
    executable_steps = async_rec.get("executable_steps") or []
    ordered_steps = [
        {"step_index": int(idx), "step": str(executable_steps[int(idx)])}
        for idx in ordering
        if 0 <= int(idx) < len(executable_steps)
    ]
    return f"""You are validating a fixed GAIA reference ordering by executing it with tools.

Do not create a new plan. Do not reorder steps. Convert each fixed step into either one concrete tool call or no tool call.

Task question:
{question}

Attachments:
{format_attachments(record)}

Available executable tools:
{json.dumps(tools, ensure_ascii=False, indent=2)}

Fixed executable-step ordering:
{json.dumps(ordered_steps, ensure_ascii=False, indent=2)}

Rules:
1. Preserve the exact step order.
2. For each step, return one entry in "calls" with the same step_index.
3. If a step is only local reasoning, evaluation, or a note whose content is already present, set tool_id to null and arguments to {{}}.
4. If a step needs external evidence, choose one tool from the available tool list and provide concrete JSON arguments.
5. For attached files, use the attachment path shown above.
6. Use image_recognition for image evidence, audio_transcription for audio evidence, and python_executor/calculator for computation when appropriate.
7. Do not include markdown. Return only JSON.

Return this JSON schema:
{{
  "calls": [
    {{
      "step_index": 0,
      "tool_id": "tool name or null",
      "arguments": {{}},
      "reason": "short reason"
    }}
  ],
  "final_answer": "optional answer if the fixed ordering reaches one"
}}
"""


def parse_model_action_json(raw: str) -> Tuple[Optional[Dict[str, Any]], str]:
    text = (raw or "").strip()
    if not text:
        return None, "empty model output"

    fence = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.DOTALL | re.IGNORECASE)
    if fence:
        text = fence.group(1).strip()

    start = text.find("{")
    if start < 0:
        return None, "model output does not contain a JSON object"

    depth = 0
    in_string = False
    escape_next = False
    end = -1
    for i, ch in enumerate(text[start:], start):
        if escape_next:
            escape_next = False
            continue
        if ch == "\\":
            escape_next = True
            continue
        if ch == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                break

    if end < 0:
        return None, "model JSON object is not balanced"
    candidate = text[start:end]
    try:
        data = json.loads(candidate)
    except json.JSONDecodeError as exc:
        return None, f"JSON parse error: {exc}"
    if not isinstance(data, dict):
        return None, "model output was not a JSON object"
    return data, ""


def normalize_model_calls(payload: Dict[str, Any], ordering: List[int]) -> Tuple[List[Dict[str, Any]], List[str]]:
    raw_calls = payload.get("calls")
    if raw_calls is None:
        raw_calls = payload.get("tool_calls")
    if raw_calls is None:
        raw_calls = payload.get("steps")
    warnings: List[str] = []
    if not isinstance(raw_calls, list):
        return [], ["missing calls list"]

    by_step: Dict[int, Dict[str, Any]] = {}
    for item in raw_calls:
        if not isinstance(item, dict):
            warnings.append("non-dict call entry")
            continue
        try:
            step_index = int(item.get("step_index"))
        except Exception:
            warnings.append("call missing integer step_index")
            continue
        by_step[step_index] = item

    normalized: List[Dict[str, Any]] = []
    for idx in ordering:
        step_index = int(idx)
        item = by_step.get(step_index)
        if item is None:
            warnings.append(f"missing step {step_index}; treated as no_tool")
            item = {"step_index": step_index, "tool_id": None, "arguments": {}, "reason": "missing from model output"}
        tool_id_raw = item.get("tool_id")
        tool_id = "" if tool_id_raw is None else str(tool_id_raw).strip()
        if tool_id.lower() in NO_TOOL_IDS:
            tool_id = ""
        arguments = item.get("arguments") if isinstance(item.get("arguments"), dict) else {}
        normalized.append(
            {
                "step_index": step_index,
                "tool_id": tool_id,
                "arguments": arguments,
                "reason": str(item.get("reason") or "")[:300],
            }
        )
    return normalized, warnings


def replay_model_ordering(
    record: Dict[str, Any],
    async_rec: Dict[str, Any],
    ordering: List[int],
    model_name: str,
    output_dir: Path,
    attempt_tag: str,
    tool_timeout_sec: int,
    max_new_tokens: int,
    api_retries: int,
) -> ReplayResult:
    executable_steps = async_rec.get("executable_steps") or []
    if not ordering_is_valid(ordering, len(executable_steps)):
        return ReplayResult(
            passed=False,
            failure_bucket="invalid_ordering_shape",
            failed_step_index=None,
            failed_tool_id=None,
            failed_output="ordering is not a permutation of executable step indices",
            steps_completed=0,
            total_steps=len(ordering),
            tool_calls_executed=0,
            successful_tool_calls=0,
            final_answer="",
            model_json_ok=False,
            trace=[],
        )

    tools = compact_tool_specs(record)
    prompt = build_action_prompt(record, async_rec, ordering, tools)
    raw = generate_with_api(
        api_model=model_name,
        prompt=prompt,
        max_new_tokens=max_new_tokens,
        max_retries=api_retries,
        retry_delay=5.0,
        dataset="gaia_async_ordering_replay",
        attachments=None,
        allow_reasoning_content_fallback=True,
        require_json_like_reasoning_fallback=True,
    )
    payload, parse_error = parse_model_action_json(raw)
    if payload is None:
        return ReplayResult(
            passed=False,
            failure_bucket="model_parse_error",
            failed_step_index=None,
            failed_tool_id=None,
            failed_output=parse_error[:1000],
            steps_completed=0,
            total_steps=len(ordering),
            tool_calls_executed=0,
            successful_tool_calls=0,
            final_answer="",
            model_json_ok=False,
            trace=[{"raw_model_output": raw[:2000]}],
        )

    model_calls, warnings = normalize_model_calls(payload, ordering)
    schema_errors = [w for w in warnings if w == "missing calls list"]
    if schema_errors:
        return ReplayResult(
            passed=False,
            failure_bucket="model_schema_error",
            failed_step_index=None,
            failed_tool_id=None,
            failed_output="; ".join(schema_errors),
            steps_completed=0,
            total_steps=len(ordering),
            tool_calls_executed=0,
            successful_tool_calls=0,
            final_answer=str(payload.get("final_answer") or "")[:500],
            model_json_ok=True,
            trace=[
                {
                    "warnings": warnings,
                    "model_payload_keys": sorted(str(k) for k in payload.keys()),
                    "raw_model_output": raw[:2000],
                }
            ],
        )
    allowed_tools = {tool["tool_id"] for tool in tools}
    attachments_dir = infer_attachments_dir(record)
    attempt_dir = output_dir / "runtime_artifacts" / attempt_tag
    attempt_dir.mkdir(parents=True, exist_ok=True)
    var_store: Dict[str, str] = {}
    trace: List[Dict[str, Any]] = []
    successful_tool_calls = 0
    tool_calls_executed = 0
    steps_completed = 0

    for call in model_calls:
        step_index = int(call["step_index"])
        tool_id = str(call.get("tool_id") or "").strip()
        if not tool_id:
            trace.append(
                {
                    "step_index": step_index,
                    "tool_id": None,
                    "arguments": {},
                    "output": "[NO_TOOL] Step treated as local reasoning or already-observed content.",
                    "success": True,
                    "reason": call.get("reason", ""),
                }
            )
            var_store[f"<step_{step_index}>"] = trace[-1]["output"]
            var_store[f"<n{step_index}>"] = trace[-1]["output"]
            steps_completed += 1
            continue

        if tool_id not in allowed_tools:
            return ReplayResult(
                passed=False,
                failure_bucket="model_invalid_tool",
                failed_step_index=step_index,
                failed_tool_id=tool_id,
                failed_output=f"Model selected unavailable tool {tool_id}. Allowed tools: {sorted(allowed_tools)}",
                steps_completed=steps_completed,
                total_steps=len(ordering),
                tool_calls_executed=tool_calls_executed,
                successful_tool_calls=successful_tool_calls,
                final_answer=str(payload.get("final_answer") or "")[:500],
                model_json_ok=True,
                trace=trace,
            )

        resolved_args = resolve_variables(call.get("arguments") or {}, var_store)
        output = execute_tool_with_timeout(
            tool_id=tool_id,
            resolved_args=resolved_args,
            attachments_dir=attachments_dir,
            output_dir=str(attempt_dir),
            timeout_sec=tool_timeout_sec,
        )
        tool_calls_executed += 1
        success = is_success_output(output)
        if success:
            successful_tool_calls += 1
            steps_completed += 1
        trace.append(
            {
                "step_index": step_index,
                "tool_id": tool_id,
                "arguments": resolved_args,
                "output": str(output or "")[:2000],
                "success": success,
                "reason": call.get("reason", ""),
            }
        )
        var_store[f"<step_{step_index}>"] = str(output or "")
        var_store[f"<n{step_index}>"] = str(output or "")

        if not success:
            return ReplayResult(
                passed=False,
                failure_bucket=classify_failure_bucket(output),
                failed_step_index=step_index,
                failed_tool_id=tool_id,
                failed_output=str(output or "")[:1000],
                steps_completed=steps_completed,
                total_steps=len(ordering),
                tool_calls_executed=tool_calls_executed,
                successful_tool_calls=successful_tool_calls,
                final_answer=str(payload.get("final_answer") or "")[:500],
                model_json_ok=True,
                trace=trace,
            )

    if warnings:
        trace.append({"warnings": warnings})

    passed = steps_completed == len(ordering)
    return ReplayResult(
        passed=passed,
        failure_bucket=None if passed else "incomplete_ordering",
        failed_step_index=None,
        failed_tool_id=None,
        failed_output="" if passed else "not all ordered steps were completed",
        steps_completed=steps_completed,
        total_steps=len(ordering),
        tool_calls_executed=tool_calls_executed,
        successful_tool_calls=successful_tool_calls,
        final_answer=str(payload.get("final_answer") or "")[:500],
        model_json_ok=True,
        trace=trace,
    )


def category_from_async_path(path: Path) -> str:
    match = re.search(r"gaia_cat_([ABCD])_", path.name)
    if match:
        return match.group(1)
    raise ValueError(f"Cannot infer GAIA category from filename: {path}")


def async_paths_from_args(base_dir: Path, categories: List[str], async_paths: Optional[List[Path]]) -> List[Path]:
    if async_paths:
        return [p if p.is_absolute() else base_dir / p for p in async_paths]
    return [base_dir / "Asynchronous" / f"gaia_cat_{cat}_async_plan.jsonl" for cat in categories]


def run_category(
    base_dir: Path,
    async_path: Path,
    model_name: str,
    output_dir: Path,
    retries: int,
    chain_stable_threshold: int,
    max_samples: Optional[int],
    sample_offset: int,
    max_orderings_per_sample: Optional[int],
    tool_timeout_sec: int,
    max_new_tokens: int,
    api_retries: int,
    require_gold_chain_stable: bool,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    category = category_from_async_path(async_path)
    chain_path = base_dir / "data.hg" / "GAIA" / CATEGORY_DIRS[category] / f"gaia.cat_{category}.json"
    if not chain_path.exists():
        fallback = base_dir / "data" / "GAIA" / CATEGORY_DIRS[category] / f"gaia.cat_{category}.json"
        chain_path = fallback if fallback.exists() else chain_path
    if not chain_path.exists():
        raise FileNotFoundError(f"Missing GAIA chain file for category {category}: {chain_path}")
    if not async_path.exists():
        raise FileNotFoundError(f"Missing async path: {async_path}")

    chain_records = load_json(chain_path)
    async_records = load_jsonl(async_path)
    chain_by_id = {str((rec.get("meta") or {}).get("id", "")): rec for rec in chain_records}
    async_by_id = {str((rec.get("meta") or {}).get("id", "")): rec for rec in async_records}
    sample_ids = sorted(sid for sid in chain_by_id if sid in async_by_id)
    sample_ids = sample_ids[max(0, sample_offset):]
    if max_samples is not None:
        sample_ids = sample_ids[:max_samples]

    ordering_rows: List[Dict[str, Any]] = []
    chain_rows: List[Dict[str, Any]] = []

    for local_idx, sample_id in enumerate(sample_ids, start=1):
        chain_rec = chain_by_id[sample_id]
        async_rec = async_by_id[sample_id]
        prefix = f"{category}.{local_idx:04d}.{sample_id}"

        orderings, ordering_source = get_orderings(async_rec)
        clean_orderings: List[List[int]] = []
        for ordering in orderings:
            if not isinstance(ordering, list):
                continue
            try:
                clean_orderings.append([int(x) for x in ordering])
            except Exception:
                continue
        if max_orderings_per_sample is not None:
            clean_orderings = clean_orderings[:max_orderings_per_sample]

        chain_pass_count, chain_attempts = evaluate_gold_chain(
            record=chain_rec,
            retries=retries,
            stable_threshold=chain_stable_threshold,
            output_dir=output_dir,
            attempt_prefix=prefix,
            tool_timeout_sec=tool_timeout_sec,
        )
        chain_stable = chain_pass_count >= chain_stable_threshold
        chain_rows.append(
            {
                "category": category,
                "sample_id": sample_id,
                "chain_pass_count": chain_pass_count,
                "chain_retries": retries,
                "chain_stable_threshold": chain_stable_threshold,
                "chain_stable_pass": chain_stable,
                "chain_failure_buckets": [a.failure_bucket for a in chain_attempts if not a.passed],
                "chain_attempts": [asdict(a) for a in chain_attempts],
            }
        )
        append_jsonl(output_dir / "chain_baseline.live.jsonl", chain_rows[-1])

        for ordering_index, ordering in enumerate(clean_orderings):
            result = replay_model_ordering(
                record=chain_rec,
                async_rec=async_rec,
                ordering=ordering,
                model_name=model_name,
                output_dir=output_dir,
                attempt_tag=f"{prefix}.ord{ordering_index:03d}.model",
                tool_timeout_sec=tool_timeout_sec,
                max_new_tokens=max_new_tokens,
                api_retries=api_retries,
            )
            decision = "VALID" if (result.passed and (chain_stable or not require_gold_chain_stable)) else "INVALID"
            row = {
                "category": category,
                "sample_id": sample_id,
                "ordering_source": ordering_source,
                "ordering_index": ordering_index,
                "ordering": json.dumps(ordering, ensure_ascii=False),
                "model_name": model_name,
                "chain_pass_count": chain_pass_count,
                "chain_retries": retries,
                "chain_stable_pass": chain_stable,
                "require_gold_chain_stable": require_gold_chain_stable,
                "ordering_model_pass": result.passed,
                "steps_completed": result.steps_completed,
                "total_steps": result.total_steps,
                "tool_calls_executed": result.tool_calls_executed,
                "successful_tool_calls": result.successful_tool_calls,
                "model_json_ok": result.model_json_ok,
                "decision": decision,
                "failure_bucket": result.failure_bucket or "",
                "failed_step_index": result.failed_step_index if result.failed_step_index is not None else "",
                "first_failed_tool": result.failed_tool_id or "",
                "first_failed_output": result.failed_output[:300],
                "final_answer_preview": result.final_answer[:200],
            }
            ordering_rows.append(row)
            append_jsonl(output_dir / "rows.live.jsonl", row)
            append_csv(output_dir / "rows.live.csv", row)
            print(
                f"[{category}] sample {local_idx}/{len(sample_ids)} "
                f"ordering {ordering_index + 1}/{len(clean_orderings)} -> {decision} "
                f"({result.steps_completed}/{result.total_steps} steps, "
                f"{result.successful_tool_calls}/{result.tool_calls_executed} tools)",
                flush=True,
            )
            trace_path = output_dir / "traces" / category / f"{sample_id}.ord{ordering_index:03d}.json"
            trace_path.parent.mkdir(parents=True, exist_ok=True)
            with trace_path.open("w", encoding="utf-8") as f:
                json.dump(
                    {
                        "category": category,
                        "sample_id": sample_id,
                        "ordering_index": ordering_index,
                        "ordering": ordering,
                        "model_name": model_name,
                        "decision": decision,
                        "result": asdict(result),
                    },
                    f,
                    ensure_ascii=False,
                    indent=2,
                )

    return ordering_rows, chain_rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Gemma/model-guided replay for GAIA async orderings.")
    parser.add_argument("--base-dir", type=Path, default=PROJECT_ROOT)
    parser.add_argument("--async-path", action="append", type=Path, default=None, help="Async JSONL path. Repeatable.")
    parser.add_argument("--categories", nargs="+", default=["A", "B", "C", "D"], choices=["A", "B", "C", "D"])
    parser.add_argument("--model-name", default="gemma-4-31B-it")
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--retries", type=int, default=1, help="Gold-chain replay retries.")
    parser.add_argument("--chain-stable-threshold", type=int, default=1)
    parser.add_argument("--max-samples-per-category", type=int, default=None)
    parser.add_argument("--sample-offset", type=int, default=0)
    parser.add_argument("--max-orderings-per-sample", type=int, default=None)
    parser.add_argument("--tool-timeout-sec", type=int, default=45)
    parser.add_argument("--max-new-tokens", type=int, default=4096)
    parser.add_argument("--api-retries", type=int, default=3)
    parser.add_argument(
        "--no-require-gold-chain-stable",
        action="store_true",
        help="Do not require the native chain gold-tool replay to pass when assigning VALID.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    base_dir = args.base_dir.resolve()
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    output_dir = args.output_dir or (
        base_dir / "Asynchronous" / "tool_layer_validation" / f"gemma4_model_replay_{timestamp}"
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    api_base = get_api_base()
    api_key = get_api_key()
    if not api_base or not api_key:
        raise RuntimeError(
            "Missing API configuration. Set LLM_API_BASE/NCHC_API_BASE and LLM_API_KEY/NCHC_API_KEY."
        )

    all_ordering_rows: List[Dict[str, Any]] = []
    all_chain_rows: List[Dict[str, Any]] = []
    for async_path in async_paths_from_args(base_dir, args.categories, args.async_path):
        ordering_rows, chain_rows = run_category(
            base_dir=base_dir,
            async_path=async_path.resolve(),
            model_name=args.model_name,
            output_dir=output_dir,
            retries=args.retries,
            chain_stable_threshold=args.chain_stable_threshold,
            max_samples=args.max_samples_per_category,
            sample_offset=args.sample_offset,
            max_orderings_per_sample=args.max_orderings_per_sample,
            tool_timeout_sec=args.tool_timeout_sec,
            max_new_tokens=args.max_new_tokens,
            api_retries=args.api_retries,
            require_gold_chain_stable=not args.no_require_gold_chain_stable,
        )
        all_ordering_rows.extend(ordering_rows)
        all_chain_rows.extend(chain_rows)

    write_rows_csv(output_dir / "rows.csv", all_ordering_rows)
    write_jsonl(output_dir / "rows.jsonl", all_ordering_rows)
    write_jsonl(output_dir / "chain_baseline.jsonl", all_chain_rows)

    decision_counts = Counter(row["decision"] for row in all_ordering_rows)
    per_category_counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    failure_counts = Counter(row["failure_bucket"] or "pass" for row in all_ordering_rows)
    for row in all_ordering_rows:
        per_category_counts[row["category"]][row["decision"]] += 1

    summary = {
        "output_dir": str(output_dir),
        "model_name": args.model_name,
        "api_base": api_base,
        "categories": args.categories,
        "async_paths": [str(p) for p in async_paths_from_args(base_dir, args.categories, args.async_path)],
        "retries": args.retries,
        "chain_stable_threshold": args.chain_stable_threshold,
        "require_gold_chain_stable": not args.no_require_gold_chain_stable,
        "max_samples_per_category": args.max_samples_per_category,
        "max_orderings_per_sample": args.max_orderings_per_sample,
        "total_chain_samples": len(all_chain_rows),
        "chain_stable_samples": sum(1 for row in all_chain_rows if row["chain_stable_pass"]),
        "total_ordering_rows": len(all_ordering_rows),
        "decision_counts": dict(decision_counts),
        "failure_counts": dict(failure_counts),
        "per_category_decision_counts": {
            cat: dict(counter) for cat, counter in sorted(per_category_counts.items())
        },
        "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    with (output_dir / "summary.json").open("w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)

    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
