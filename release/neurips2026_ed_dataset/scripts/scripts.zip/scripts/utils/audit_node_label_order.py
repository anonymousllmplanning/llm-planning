#!/usr/bin/env python3
"""Audit Node Label Similarity + OrderF1 with sentence-transformer matching.

Node Label Similarity is the soft node-coverage metric used in prior graph
evaluation work:

    NLS = mean_gold max_pred cosine(label_gold, label_pred)

It does not produce a node alignment by itself, so this audit reports two
order pairings:

* nls_strict_order: (node_label_similarity + strict-node-anchored OrderF1) / 2
* nls_span_order:   (node_label_similarity + span-reanchored OrderF1) / 2

For reference, it also reports:

* node_edge:        (strict_node_f1 + semantic_edge_f1) / 2
* node_order:       (strict_node_f1 + strict-node-anchored OrderF1) / 2
* nls_edge:         (node_label_similarity + semantic_edge_f1) / 2

The GAIA augmented setting treats the original chain and dependency DAG as
candidate references and selects the best reference separately for each metric.
"""

from __future__ import annotations

import argparse
import copy
import glob
import json
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

import pandas as pd
from scipy.stats import pearsonr, spearmanr


REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.utils.audit_order_only_swap_gaia_taskbench import (  # noqa: E402
    strict_node_anchored_order_f1,
)
from scripts.utils.compare_gaia_augmented_prior_span_order import (  # noqa: E402
    CATEGORY_META,
    category_from_subset,
    dependency_dag_from_async_record,
    iter_jsonl,
    load_gold_references,
)
from src.evaluation.metrics import ASTEvaluationSystem  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=REPO_ROOT)
    parser.add_argument(
        "--gaia-results-root",
        type=Path,
        default=REPO_ROOT / "organized_results/gaia/0427",
    )
    parser.add_argument(
        "--taskbench-dir",
        type=Path,
        default=REPO_ROOT / "organized_results/taskbench_balanced_600",
    )
    parser.add_argument(
        "--gaia-filter-source",
        type=Path,
        default=REPO_ROOT
        / "runtime_artifacts/prior_vs_span_order_gaia_augmented_20260428_exact_span/per_sample_prior_vs_span_order.csv",
        help="Optional GAIA per-sample file containing human/tool-clean columns.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=REPO_ROOT / "runtime_artifacts/node_label_order_audit_20260428",
    )
    parser.add_argument("--ats-threshold", type=float, default=0.5)
    parser.add_argument("--tisr-threshold", type=float, default=0.7)
    parser.add_argument("--attachment-dense-threshold", type=int, default=2)
    return parser.parse_args()


def choose_best(
    scored_refs: List[Tuple[str, Dict[str, float]]],
    metric_key: str,
) -> Tuple[str, Dict[str, float]]:
    preference = {"chain": 0, "dag": 1}
    return max(scored_refs, key=lambda item: (item[1][metric_key], -preference.get(item[0], 99)))


def score_plan(evaluator: ASTEvaluationSystem, gold_dag: Dict[str, Any], pred_dag: Dict[str, Any]) -> Dict[str, float]:
    scores = evaluator.evaluate_plan_dag(gold_dag, pred_dag)
    strict_order = strict_node_anchored_order_f1(gold_dag, pred_dag)
    node_label = scores.node_label_similarity
    return {
        "strict_node_f1": scores.strict_node_f1,
        "node_label_similarity": node_label,
        "span_node_f1": scores.span_node_f1,
        "semantic_edge_f1": scores.semantic_edge_f1,
        "strict_node_order_f1": strict_order,
        "span_order_f1": scores.dw_order_f1,
        "node_edge_score": (scores.strict_node_f1 + scores.semantic_edge_f1) / 2.0,
        "node_order_score": (scores.strict_node_f1 + strict_order) / 2.0,
        "nls_edge_score": (node_label + scores.semantic_edge_f1) / 2.0,
        "nls_strict_order_score": (node_label + strict_order) / 2.0,
        "nls_span_order_score": (node_label + scores.dw_order_f1) / 2.0,
        "span_order_score": (scores.span_node_f1 + scores.dw_order_f1) / 2.0,
    }


def collect_gaia(args: argparse.Namespace, evaluator: ASTEvaluationSystem) -> pd.DataFrame:
    chain_gold, async_gold = load_gold_references(args.repo_root)
    rows: List[Dict[str, Any]] = []
    unified_paths = sorted(
        path
        for path in glob.glob(str(args.gaia_results_root / "**/unified.*.jsonl"), recursive=True)
        if "/tool_creation_log." not in path
    )
    for path_string in unified_paths:
        path = Path(path_string)
        for record in iter_jsonl(path):
            meta = record.get("meta") or {}
            sample_id = meta.get("id")
            if sample_id not in chain_gold or sample_id not in async_gold:
                continue
            pred_dag = (record.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []}
            subset = meta.get("subset", "")
            category_code = category_from_subset(subset)
            category = CATEGORY_META.get(category_code, {}).get("name", "")
            model = meta.get("model_name")

            gaia_chain = copy.deepcopy(chain_gold[sample_id]["gold"]["plan_dag"])
            aug_chain = copy.deepcopy(async_gold[sample_id]["gold"]["plan_dag"])
            aug_dag = dependency_dag_from_async_record(async_gold[sample_id])

            gaia_scores = score_plan(evaluator, gaia_chain, pred_dag)
            aug_candidates = [
                ("chain", score_plan(evaluator, aug_chain, pred_dag)),
                ("dag", score_plan(evaluator, aug_dag, pred_dag)),
            ]

            row = {
                "dataset": "gaia",
                "sample_id": sample_id,
                "sample_prefix": str(sample_id)[:8],
                "model": model,
                "category": category,
                "subset": subset,
            }
            for key, value in gaia_scores.items():
                row[f"gaia_{key}"] = value
            for metric_key in [
                "node_edge_score",
                "node_order_score",
                "nls_edge_score",
                "nls_strict_order_score",
                "nls_span_order_score",
                "span_order_score",
            ]:
                ref, scores = choose_best(aug_candidates, metric_key)
                row[f"aug_{metric_key}"] = scores[metric_key]
                row[f"aug_{metric_key}_best_ref"] = ref
                for component_key in [
                    "strict_node_f1",
                    "node_label_similarity",
                    "semantic_edge_f1",
                    "strict_node_order_f1",
                    "span_order_f1",
                ]:
                    row[f"aug_{metric_key}_{component_key}"] = scores[component_key]
            rows.append(row)
    df = pd.DataFrame(rows)

    if args.gaia_filter_source.exists():
        filters = pd.read_csv(args.gaia_filter_source)
        keep_cols = [
            "sample_id",
            "model",
            "human_eval_solve",
            "gt_aligned_tool_success_rate",
            "pred_exec_success_rate",
            "tool_usage_score",
            "parse_error",
            "gold_tool_count",
            "pred_tool_count",
        ]
        available = [col for col in keep_cols if col in filters.columns]
        df = df.merge(filters[available].drop_duplicates(["sample_id", "model"]), on=["sample_id", "model"], how="left")
    return df


def collect_taskbench(args: argparse.Namespace, evaluator: ASTEvaluationSystem) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for unified_path in sorted(args.taskbench_dir.glob("unified.*.jsonl")):
        model = unified_path.stem.replace("unified.", "")
        for line in unified_path.open("r", encoding="utf-8"):
            record = json.loads(line)
            meta = record.get("meta") or {}
            gold_dag = (record.get("gold") or {}).get("plan_dag") or {"nodes": [], "edges": []}
            pred_dag = (record.get("pred") or {}).get("plan_dag") or {"nodes": [], "edges": []}
            scores = score_plan(evaluator, gold_dag, pred_dag)
            rows.append(
                {
                    "dataset": "taskbench",
                    "sample_id": meta.get("id"),
                    "model": model,
                    "subset": meta.get("subset"),
                    "plan_type": meta.get("plan_type"),
                    **scores,
                }
            )
    return pd.DataFrame(rows)


def summarize(df: pd.DataFrame, group_cols: List[str]) -> pd.DataFrame:
    metric_cols = [
        col
        for col in df.columns
        if col.endswith("_score")
        or col.endswith("_f1")
        or col.endswith("_similarity")
    ]
    return df.groupby(group_cols, as_index=False).agg(
        n=("sample_id", "count"),
        **{col: (col, "mean") for col in metric_cols},
    )


def parse_bool_series(series: pd.Series) -> pd.Series:
    filled = series.fillna(False)
    if filled.dtype == object:
        return filled.astype(str).str.lower().isin(["true", "1", "yes"])
    return filled.astype(bool)


def model_level_correlations(args: argparse.Namespace, gaia: pd.DataFrame) -> pd.DataFrame:
    if "human_eval_solve" not in gaia.columns:
        return pd.DataFrame()
    parse_error = parse_bool_series(gaia.get("parse_error", pd.Series(False, index=gaia.index)))
    tool_clean = (
        (~parse_error)
        & (gaia["gt_aligned_tool_success_rate"] >= args.ats_threshold)
        & (gaia["pred_exec_success_rate"] >= args.tisr_threshold)
    )
    subsets = {
        "all": pd.Series(True, index=gaia.index),
        "tool_clean": tool_clean,
        "text_clean": tool_clean & (gaia["category"] == "Text Reasoning"),
        "attachment_clean": tool_clean
        & gaia["category"].isin(["Document Analysis", "Vision", "Audio"])
        & (gaia["gold_tool_count"] >= args.attachment_dense_threshold),
    }
    metrics = [
        "gaia_node_label_similarity",
        "gaia_nls_edge_score",
        "gaia_nls_strict_order_score",
        "gaia_nls_span_order_score",
        "aug_nls_edge_score",
        "aug_nls_strict_order_score",
        "aug_nls_span_order_score",
        "aug_node_order_score",
        "aug_span_order_score",
    ]
    rows: List[Dict[str, Any]] = []
    for subset_name, mask in subsets.items():
        subset = gaia[mask].dropna(subset=["human_eval_solve"])
        for metric in metrics:
            if metric not in subset.columns:
                continue
            grouped = subset.groupby("model", as_index=False).agg(
                metric_value=(metric, "mean"),
                solve_rate=("human_eval_solve", "mean"),
                n=("sample_id", "count"),
            )
            if len(grouped) >= 3 and grouped["metric_value"].nunique() > 1 and grouped["solve_rate"].nunique() > 1:
                pearson = pearsonr(grouped["metric_value"], grouped["solve_rate"])
                spearman = spearmanr(grouped["metric_value"], grouped["solve_rate"])
                pearson_r, pearson_p = pearson.statistic, pearson.pvalue
                spearman_rho, spearman_p = spearman.statistic, spearman.pvalue
            else:
                pearson_r = pearson_p = spearman_rho = spearman_p = float("nan")
            rows.append(
                {
                    "subset": subset_name,
                    "retained_predictions": len(subset),
                    "metric": metric,
                    "mean_metric": subset[metric].mean(),
                    "solve_rate": subset["human_eval_solve"].mean(),
                    "pearson_r": pearson_r,
                    "pearson_p": pearson_p,
                    "spearman_rho": spearman_rho,
                    "spearman_p": spearman_p,
                }
            )
    return pd.DataFrame(rows)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    evaluator = ASTEvaluationSystem(use_embeddings=True)

    gaia = collect_gaia(args, evaluator)
    taskbench = collect_taskbench(args, evaluator)

    gaia.to_csv(args.output_dir / "gaia_node_label_order_per_sample.csv", index=False)
    taskbench.to_csv(args.output_dir / "taskbench_node_label_order_per_sample.csv", index=False)

    gaia_overall = summarize(gaia.assign(all="all"), ["all"])
    gaia_model = summarize(gaia, ["model"])
    gaia_category = summarize(gaia, ["category"])
    task_overall = summarize(taskbench.assign(all="all"), ["all"])
    task_model = summarize(taskbench, ["model"])
    task_plan_type = summarize(taskbench, ["plan_type"])
    correlations = model_level_correlations(args, gaia)

    gaia_overall.to_csv(args.output_dir / "gaia_node_label_order_overall.csv", index=False)
    gaia_model.to_csv(args.output_dir / "gaia_node_label_order_by_model.csv", index=False)
    gaia_category.to_csv(args.output_dir / "gaia_node_label_order_by_category.csv", index=False)
    task_overall.to_csv(args.output_dir / "taskbench_node_label_order_overall.csv", index=False)
    task_model.to_csv(args.output_dir / "taskbench_node_label_order_by_model.csv", index=False)
    task_plan_type.to_csv(args.output_dir / "taskbench_node_label_order_by_plan_type.csv", index=False)
    correlations.to_csv(args.output_dir / "gaia_node_label_order_model_level_correlations.csv", index=False)

    print("[GAIA OVERALL]")
    print(
        gaia_overall[
            [
                "n",
                "gaia_node_label_similarity",
                "gaia_nls_edge_score",
                "gaia_nls_strict_order_score",
                "gaia_nls_span_order_score",
                "aug_nls_edge_score",
                "aug_nls_strict_order_score",
                "aug_nls_span_order_score",
            ]
        ].round(4).to_string(index=False)
    )
    print("\n[TASKBENCH OVERALL]")
    print(
        task_overall[
            [
                "n",
                "node_label_similarity",
                "nls_edge_score",
                "nls_strict_order_score",
                "nls_span_order_score",
            ]
        ].round(4).to_string(index=False)
    )
    print("\n[GAIA CORRELATIONS: selected]")
    selected = correlations[
        correlations["metric"].isin(
            [
                "aug_nls_strict_order_score",
                "aug_nls_span_order_score",
                "gaia_node_label_similarity",
                "aug_node_order_score",
            ]
        )
    ]
    print(selected.round(4).to_string(index=False))
    print(f"\n[WROTE] {args.output_dir}")


if __name__ == "__main__":
    main()
