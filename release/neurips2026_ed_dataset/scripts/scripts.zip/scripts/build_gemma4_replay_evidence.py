#!/usr/bin/env python3
"""Build the Gemma4 replay evidence bundle used by the paper tables.

The paper combines Cat A from the 20260501 Gemma4 replay run with Cat B/C/D
from the 20260502 BCD replay run.  The retained policy is intentionally not the
raw VALID verdict: correct-to-correct surface variants are also retained because
they are gold-equivalent.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any, Iterable


COMBINED_JSONL = "gemma4_replay_validation_catA_20260501_catBCD_20260502.combined.jsonl"

RETAINED_TRANSITIONS = {
    "correct_to_correct_same",
    "correct_to_correct_different",
    "wrong_to_wrong_same",
}

TRANSITION_ORDER = [
    "correct_to_correct_same",
    "wrong_to_wrong_different",
    "wrong_to_wrong_same",
    "chain_unavailable",
    "correct_to_wrong",
    "wrong_to_correct",
    "ordering_no_answer",
    "correct_to_correct_different",
]


def repo_root_from_script() -> Path:
    return Path(__file__).resolve().parents[1]


def read_jsonl(path: Path) -> Iterable[dict]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON in {path}:{line_number}: {exc}") from exc


def relative_path(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def sanitize_path_string(value: str, root: Path) -> str:
    """Remove machine-local prefixes from replay evidence paths."""
    text = value
    replay_match = re.search(r"(?:^|/)(execute_layer_replay_validation/.*)$", text)
    if replay_match:
        return replay_match.group(1)
    for prefix in (root.as_posix() + "/",):
        if text.startswith(prefix):
            return text[len(prefix) :]
    return text


def sanitize_replay_value(value: Any, root: Path) -> Any:
    if isinstance(value, dict):
        return {key: sanitize_replay_value(item, root) for key, item in value.items()}
    if isinstance(value, list):
        return [sanitize_replay_value(item, root) for item in value]
    if isinstance(value, str) and ("/home/" in value or "/tmp/" in value):
        return sanitize_path_string(value, root)
    return value


def load_filtered_rows(sources: OrderedDict[str, tuple[Path, str]]) -> tuple[list[dict], dict[str, Counter]]:
    rows: list[dict] = []
    skipped: dict[str, Counter] = {}

    for label, (path, expected_category) in sources.items():
        source_skipped: Counter = Counter()
        for row in read_jsonl(path):
            category = row.get("category")
            if category != expected_category:
                source_skipped[str(category)] += 1
                continue
            rows.append(row)
        if source_skipped:
            skipped[label] = source_skipped

    return rows, skipped


def write_combined_jsonl(rows: list[dict], output_path: Path, root: Path) -> None:
    with output_path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(sanitize_replay_value(row, root), ensure_ascii=False, sort_keys=False))
            handle.write("\n")


def summarize(rows: list[dict], sources: OrderedDict[str, tuple[Path, str]], skipped: dict[str, Counter], root: Path) -> dict:
    transition_counts = Counter(row.get("outcome_transition") for row in rows)
    verdict_counts = Counter(row.get("verdict") for row in rows)
    filter_group_counts = Counter(row.get("filter_reason_group") for row in rows)
    category_counts = Counter(row.get("category") for row in rows)

    retained = sum(transition_counts[transition] for transition in RETAINED_TRANSITIONS)
    total = len(rows)
    native_unavailable = transition_counts["chain_unavailable"]

    source_paths = {
        label: relative_path(path, root) for label, (path, _category) in sources.items()
    }
    source_filters = {
        label: category for label, (_path, category) in sources.items()
    }

    skipped_summary = {
        source_label: dict(counter) for source_label, counter in skipped.items()
    }

    # Preserve the original compact field used by the manually curated bundle.
    cat_a_skipped = skipped_summary.get("A", {})

    return {
        "description": "Gemma4 behavior-preserving replay evidence used for Augmented GAIA GT construction.",
        "policy": (
            "Retain candidate async orderings when reordered replay preserves the native-chain "
            "final-answer outcome, including gold-equivalent surface variants and same-wrong-answer "
            "reproducibility."
        ),
        "sources": source_paths,
        "source_category_filters": source_filters,
        "skipped_rows_from_catA_source_due_to_category_filter": cat_a_skipped,
        "skipped_rows_by_source_due_to_category_filter": skipped_summary,
        "total_candidate_ordering_rows": total,
        "retained_under_behavior_preserving_filter": retained,
        "filtered_under_behavior_preserving_filter": total - retained,
        "native_chain_replay_unavailable": native_unavailable,
        "ordering_specific_non_reproducible_outcome": total - retained - native_unavailable,
        "by_category": {label: category_counts[f"cat_{label}"] for label in sources},
        "by_verdict": dict(verdict_counts),
        "by_filter_group_raw": dict(filter_group_counts),
        "by_transition": dict(transition_counts),
    }


def write_summary(summary: dict, output_path: Path) -> None:
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def write_transition_counts(rows: list[dict], output_path: Path) -> None:
    transition_counts = Counter(row.get("outcome_transition") for row in rows)
    total = len(rows)
    ordered_transitions = list(TRANSITION_ORDER)
    for transition in transition_counts:
        if transition not in ordered_transitions:
            ordered_transitions.append(transition)

    with output_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["transition", "count", "rate"])
        for transition in ordered_transitions:
            count = transition_counts[transition]
            if count == 0:
                continue
            writer.writerow([transition, count, count / total if total else 0.0])


def write_manifest(
    sources: OrderedDict[str, tuple[Path, str]],
    output_path: Path,
    combined_path: Path,
    summary_path: Path,
    root: Path,
) -> None:
    lines = [
        "Gemma4 gold-equivalent behavior-preserving replay validation sources used for paper numbers",
    ]
    for label, (path, category) in sources.items():
        lines.append(f"Cat {label}: {relative_path(path, root)} (category filter: {category})")
    lines.extend(
        [
            "",
            f"Combined evidence file: {relative_path(combined_path, root)}",
            f"Summary: {relative_path(summary_path, root)}",
            "",
            (
                "Policy: retain a candidate async ordering when the async replay preserves the "
                "native-chain execution outcome, including gold-equivalent surface variants and "
                "same-wrong-answer reproducibility. This is the 76.7% retained policy used for "
                "Augmented GAIA GT construction."
            ),
        ]
    )
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def maybe_copy_paper_manifest(root: Path, output_path: Path, sources: OrderedDict[str, tuple[Path, str]]) -> None:
    paper_manifest = root / "version2/paper_results/gemma4_replay_validation/source_manifest.txt"
    if paper_manifest.exists():
        lines = [
            "Sanitized copy of version2/paper_results/gemma4_replay_validation/source_manifest.txt",
            "The original paper-results manifest used machine-local /tmp paths; this copy records the equivalent repository-relative sources.",
        ]
        for label, (path, category) in sources.items():
            lines.append(f"Cat {label}: {relative_path(path, root)} (category filter: {category})")
        lines.extend(
            [
                "",
                (
                    "Policy: retain a candidate async ordering when the async replay preserves the "
                    "native-chain execution outcome, including gold-equivalent surface variants. "
                    "This is the 76.7% retained policy used for Augmented GAIA GT construction."
                ),
            ]
        )
        output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_checksums(output_dir: Path, file_names: list[str]) -> None:
    checksum_path = output_dir / "checksums.sha256"
    with checksum_path.open("w", encoding="utf-8") as handle:
        for file_name in file_names:
            path = output_dir / file_name
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            handle.write(f"{digest}  {file_name}\n")


def parse_args() -> argparse.Namespace:
    root = repo_root_from_script()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=root)
    parser.add_argument("--output-dir", type=Path, default=root / "replay_evidence")
    parser.add_argument(
        "--cat-a-jsonl",
        type=Path,
        default=root / "execute_layer_replay_validation/20260501_191815_replay/gemma4/replay_validation.jsonl",
    )
    parser.add_argument(
        "--cat-b-jsonl",
        type=Path,
        default=root / "execute_layer_replay_validation/20260502_025559_bcd/cat_B/gemma4/replay_validation.jsonl",
    )
    parser.add_argument(
        "--cat-c-jsonl",
        type=Path,
        default=root / "execute_layer_replay_validation/20260502_025559_bcd/cat_C/gemma4/replay_validation.jsonl",
    )
    parser.add_argument(
        "--cat-d-jsonl",
        type=Path,
        default=root / "execute_layer_replay_validation/20260502_025559_bcd/cat_D/gemma4/replay_validation.jsonl",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = args.repo_root.resolve()
    output_dir = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    sources: OrderedDict[str, tuple[Path, str]] = OrderedDict(
        [
            ("A", (args.cat_a_jsonl, "cat_A")),
            ("B", (args.cat_b_jsonl, "cat_B")),
            ("C", (args.cat_c_jsonl, "cat_C")),
            ("D", (args.cat_d_jsonl, "cat_D")),
        ]
    )

    for label, (path, _category) in sources.items():
        if not path.exists():
            raise FileNotFoundError(f"Missing Cat {label} replay source: {path}")

    rows, skipped = load_filtered_rows(sources)
    summary = summarize(rows, sources, skipped, root)

    combined_path = output_dir / COMBINED_JSONL
    summary_path = output_dir / "summary.json"
    transition_path = output_dir / "transition_counts.csv"
    manifest_path = output_dir / "source_manifest.txt"
    paper_manifest_path = output_dir / "source_manifest.paper_results.txt"

    write_combined_jsonl(rows, combined_path, root)
    write_summary(summary, summary_path)
    write_transition_counts(rows, transition_path)
    write_manifest(sources, manifest_path, combined_path, summary_path, root)
    maybe_copy_paper_manifest(root, paper_manifest_path, sources)

    checksum_targets = [
        COMBINED_JSONL,
        "summary.json",
        "transition_counts.csv",
        "source_manifest.txt",
    ]
    if paper_manifest_path.exists():
        checksum_targets.append("source_manifest.paper_results.txt")
    write_checksums(output_dir, checksum_targets)

    retained = summary["retained_under_behavior_preserving_filter"]
    total = summary["total_candidate_ordering_rows"]
    print(f"Wrote {output_dir}")
    print(f"Rows: {total}")
    print(f"Retained: {retained} ({retained / total:.1%})")


if __name__ == "__main__":
    main()
