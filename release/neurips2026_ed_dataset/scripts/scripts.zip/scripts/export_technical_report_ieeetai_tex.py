#!/usr/bin/env python3
"""Export docs/technical_reports.md into an IEEE TAI styled LaTeX file.

This keeps the original Markdown untouched and reuses the existing Markdown
converter for tables, figures, code blocks, and section parsing, but swaps in
an IEEE-style preamble derived from docs/tai2026.tex.
"""

from __future__ import annotations

import re
from pathlib import Path

import export_technical_report_tex as base


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "docs" / "technical_reports.md"
DST = ROOT / "docs" / "technical_reports_tai2026.tex"

TITLE_FALLBACK = "Multi-Stage LLM Planning: Order-Based and Answer-Based Evaluation of Tool-Augmented Language Models"
DATE_FALLBACK = "March 31, 2026"
KEYWORDS = (
    "tool-augmented language models, multi-stage planning, TaskBench, GAIA, "
    "order-based evaluation, answer-based evaluation"
)


def extract_title(text: str) -> str:
    match = re.search(r"^#\s+(.+)$", text, flags=re.MULTILINE)
    return match.group(1).strip() if match else TITLE_FALLBACK


def extract_update_date(text: str) -> str:
    match = re.search(r"Updated on ([^.]+)\.", text)
    return match.group(1).strip() if match else DATE_FALLBACK


def split_abstract_and_body(text: str) -> tuple[str, str]:
    lines = text.splitlines()
    abstract_lines: list[str] = []
    body_lines: list[str] = []
    in_abstract = False
    body_started = False

    for line in lines:
        stripped = line.strip()
        if stripped.startswith("# "):
            continue
        if stripped.startswith("> **Updated on "):
            continue
        if stripped == "## 摘要":
            in_abstract = True
            continue
        if in_abstract and stripped == "---":
            in_abstract = False
            body_started = True
            continue
        if in_abstract:
            abstract_lines.append(line)
        elif body_started:
            body_lines.append(line)

    return "\n".join(abstract_lines).strip(), "\n".join(body_lines).strip()


def convert_abstract(md_text: str) -> str:
    paragraphs: list[str] = []
    para_lines: list[str] = []
    list_items: list[str] = []

    def flush_paragraph() -> None:
        nonlocal para_lines
        if para_lines:
            text = " ".join(line.strip() for line in para_lines if line.strip())
            paragraphs.append(base.inline_to_tex(text))
            para_lines = []

    def flush_list() -> None:
        nonlocal list_items
        if list_items:
            joined = "；".join(f"（{idx}）{item}" for idx, item in enumerate(list_items, start=1))
            if not joined.endswith("。"):
                joined += "。"
            paragraphs.append(base.inline_to_tex(joined))
            list_items = []

    for raw_line in md_text.splitlines():
        stripped = raw_line.strip()
        if not stripped:
            flush_paragraph()
            flush_list()
            continue
        if stripped.startswith(">"):
            continue
        match = re.match(r"^\d+\.\s+(.*)$", stripped)
        if match:
            flush_paragraph()
            list_items.append(match.group(1).strip())
            continue
        flush_list()
        para_lines.append(stripped)

    flush_paragraph()
    flush_list()
    return "\n\n".join(paragraphs)


def normalize_body(body: str) -> str:
    body = re.sub(r"\n\\bigskip\\hrule\\bigskip\n+", "\n\n", body)
    body = re.sub(r"\\addcontentsline\{toc\}\{[^}]+\}\{[^}]+\}\n?", "", body)
    body = body.replace(r"\appendix", r"\appendices")
    body = body.replace(r"\section*{附錄}", "")
    body = re.sub(
        r"\\subsection\*\{[A-Z]\.\s*([^}]+)\}",
        lambda m: rf"\section{{{m.group(1).strip()}}}",
        body,
    )
    body = re.sub(r"\\caption\{Figure\s+\d+\.\s*", lambda _: r"\caption{", body)
    body = body.replace(r"\begin{figure}[H]", r"\begin{figure}[t]")
    body = body.replace(r"\begin{enumerate}[leftmargin=2em]", r"\begin{enumerate}")
    body = body.replace(r"\begin{itemize}[leftmargin=2em]", r"\begin{itemize}")
    body = re.sub(r"\n{3,}", "\n\n", body)
    return body.strip() + "\n"


def build_document(title: str, updated_on: str, abstract_tex: str, body_tex: str) -> str:
    safe_title = base.escape_tex(title)
    safe_keywords = base.escape_tex(KEYWORDS)
    return rf"""% For IEEE-style two-column layout, use:
% \documentclass[journal]{{IEEEtai}}
\documentclass[journal,onecolumn]{{IEEEtai}}

% ------------------------------------------------------------
% Encoding and fonts (pdfLaTeX for Chinese text)
% ------------------------------------------------------------
\usepackage[T1]{{fontenc}}
\usepackage[utf8]{{inputenc}}
\usepackage{{newtxtext}}
\usepackage{{newtxmath}}
\usepackage{{CJKutf8}}
\usepackage{{microtype}}

% ------------------------------------------------------------
% Math
% ------------------------------------------------------------
\usepackage{{amsmath,mathtools}}
\usepackage{{bm}}

% ------------------------------------------------------------
% Figures, tables, colors
% ------------------------------------------------------------
\usepackage{{graphicx}}
\graphicspath{{{{figures/}}}}
\usepackage{{float}}
\usepackage{{array}}
\usepackage{{booktabs}}
\usepackage{{multirow}}
\usepackage{{longtable}}
\usepackage[table]{{xcolor}}
\usepackage{{colortbl}}
\usepackage{{subfig}}
\usepackage{{placeins}}
\usepackage{{stfloats}}
\usepackage{{caption}}
\captionsetup{{font=small,labelfont=bf}}

% ------------------------------------------------------------
% Layout helpers
% ------------------------------------------------------------
\usepackage{{fvextra}}
\usepackage{{ragged2e}}
\usepackage{{setspace}}
\setstretch{{1.02}}
\emergencystretch=2em
\setlength{{\LTleft}}{{0pt}}
\setlength{{\LTright}}{{0pt}}
\setlength{{\textfloatsep}}{{10pt plus 2pt minus 2pt}}
\setlength{{\floatsep}}{{8pt plus 2pt minus 2pt}}
\setlength{{\intextsep}}{{8pt plus 2pt minus 2pt}}
\newcolumntype{{C}}[1]{{>{{\centering\arraybackslash}}p{{#1}}}}
\newcolumntype{{L}}[1]{{>{{\raggedright\arraybackslash}}p{{#1}}}}

% ------------------------------------------------------------
% References and links
% ------------------------------------------------------------
\usepackage[square,sort,comma,numbers]{{natbib}}
\usepackage[colorlinks,urlcolor=blue,linkcolor=blue,citecolor=blue]{{hyperref}}
\usepackage[capitalise,noabbrev]{{cleveref}}
\usepackage{{url}}
\usepackage{{xspace}}
\usepackage{{pifont}}
\usepackage{{csquotes}}

\hyphenpenalty=800

\title{{{safe_title}}}
\author{{Tsung Hsien Chuang}}
% To show running headers again, replace the next line with:
% \markboth{{IEEE Transactions on Artificial Intelligence}}{{Chuang: {safe_title}}}
\markboth{{}}{{}}

\begin{{document}}
\begin{{CJK*}}{{UTF8}}{{bsmi}}
\pagestyle{{plain}}
\maketitle

\begin{{abstract}}
{abstract_tex}
\end{{abstract}}

\begin{{IEEEkeywords}}
{safe_keywords}
\end{{IEEEkeywords}}

\noindent\textit{{Version updated on {base.escape_tex(updated_on)}.}}

\vspace{{1em}}

{body_tex}

\end{{CJK*}}
\end{{document}}
"""


def main() -> None:
    raw_text = SRC.read_text(encoding="utf-8")
    title = extract_title(raw_text)
    updated_on = extract_update_date(raw_text)
    abstract_md, body_md = split_abstract_and_body(raw_text)

    base.ASSET_DIR = Path("figures")

    abstract_tex = convert_abstract(abstract_md)
    body_tex = normalize_body(base.convert_markdown(body_md))

    tex = build_document(title, updated_on, abstract_tex, body_tex)
    DST.write_text(tex, encoding="utf-8")
    print(f"Wrote {DST}")


if __name__ == "__main__":
    main()
