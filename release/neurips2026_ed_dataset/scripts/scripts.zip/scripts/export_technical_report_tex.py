#!/usr/bin/env python3
"""Export docs/technical_reports.md to an Overleaf-friendly XeLaTeX file.

This converter intentionally supports only the subset of Markdown used by the
technical report:
- headings (#, ##, ###, ####)
- paragraphs
- blockquotes
- fenced code blocks
- unordered / ordered lists
- markdown tables
- inline bold / emphasis / code / links
- simple centered HTML image blocks used in the report

The goal is not perfect generic Markdown support; it is to generate a clean,
readable .tex file from the current report without modifying the source .md.
"""

from __future__ import annotations

import html
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "docs" / "technical_reports.md"
DST = ROOT / "docs" / "technical_reports.tex"
ASSET_DIR = Path("technical_reports_assets")

FIGURE_MAP = {
    "https://hackmd.io/_uploads/SkadmTuibe.png": "fig1_overall_comparison.png",
    "https://hackmd.io/_uploads/Hy6dmpdoWe.png": "fig2_facet_by_dataset.png",
    "https://hackmd.io/_uploads/SkRd76usWx.png": "fig3_gaia_stability.png",
    "https://hackmd.io/_uploads/rkaO7TdsZe.png": "fig4_parse_error_impact.png",
}


def escape_tex(text: str) -> str:
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def escape_tex_verbatim_safe(text: str) -> str:
    return text.replace("\\", r"\textbackslash{}").replace("{", r"\{").replace("}", r"\}")


def inline_to_tex(text: str) -> str:
    placeholders: list[str] = []

    def stash(value: str) -> str:
        placeholders.append(value)
        return f"@@PLACEHOLDER{len(placeholders) - 1}@@"

    def repl_code(match: re.Match[str]) -> str:
        content = escape_tex(match.group(1))
        for needle in (r"\_", "-", "/", ".", "=", ":", ",", ")", "]"):
            content = content.replace(needle, needle + r"\allowbreak{}")
        content = content.replace("(", r"\allowbreak{}(").replace("[", r"\allowbreak{}[")
        return stash(rf"\texttt{{{content}}}")

    def repl_math(match: re.Match[str]) -> str:
        return stash(match.group(0))

    def repl_link(match: re.Match[str]) -> str:
        label = inline_to_tex(match.group(1))
        url = match.group(2).replace("\\", "/")
        return stash(rf"\href{{{url}}}{{{label}}}")

    def repl_bold(match: re.Match[str]) -> str:
        return stash(rf"\textbf{{{inline_to_tex(match.group(1))}}}")

    def repl_em(match: re.Match[str]) -> str:
        return stash(rf"\emph{{{inline_to_tex(match.group(1))}}}")

    text = re.sub(r"(?<!\$)\$([^$\n]+)\$(?!\$)", repl_math, text)
    text = re.sub(r"`([^`]+)`", repl_code, text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", repl_link, text)
    text = re.sub(r"\*\*([^*]+)\*\*", repl_bold, text)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", repl_em, text)
    text = escape_tex(text)

    changed = True
    while changed:
        changed = False
        for i, value in enumerate(placeholders):
            token = f"@@PLACEHOLDER{i}@@"
            if token in text:
                text = text.replace(token, value)
                changed = True
    return text


def clean_heading(title: str) -> str:
    return re.sub(r"^\d+(?:\.\d+)*\.?\s+", "", title).strip()


def parse_table(block: list[str]) -> str:
    rows = []
    for line in block:
        stripped = line.strip()
        if not stripped.startswith("|"):
            continue
        cells = [cell.strip() for cell in stripped.strip("|").split("|")]
        rows.append(cells)
    if len(rows) < 2:
        return "\n".join(inline_to_tex(line) for line in block) + "\n"

    header = rows[0]
    data = rows[2:]
    ncols = len(header)
    width = 0.85 / max(ncols, 1)
    colspec = "".join([rf">{{\RaggedRight\arraybackslash}}p{{{width:.3f}\linewidth}}" for _ in range(ncols)])

    out = [
        r"\begingroup",
        r"\small",
        r"\setlength{\tabcolsep}{3pt}",
        r"\renewcommand{\arraystretch}{1.12}",
        r"\setlength{\LTleft}{0pt}",
        r"\setlength{\LTright}{0pt}",
        rf"\begin{{longtable}}{{{colspec}}}",
        r"\toprule",
    ]
    out.append(" & ".join(inline_to_tex(cell) for cell in header) + r" \\")
    out.append(r"\midrule")
    out.append(r"\endfirsthead")
    out.append(r"\toprule")
    out.append(" & ".join(inline_to_tex(cell) for cell in header) + r" \\")
    out.append(r"\midrule")
    out.append(r"\endhead")
    out.append(r"\midrule")
    out.append(r"\multicolumn{" + str(ncols) + r"}{r}{\small Continued on next page} \\")
    out.append(r"\midrule")
    out.append(r"\endfoot")
    out.append(r"\bottomrule")
    out.append(r"\endlastfoot")
    for row in data:
        if len(row) < ncols:
            row = row + [""] * (ncols - len(row))
        out.append(" & ".join(inline_to_tex(cell) for cell in row[:ncols]) + r" \\")
    out.append(r"\end{longtable}")
    out.append(r"\endgroup")
    return "\n".join(out) + "\n"


def parse_code(block: list[str]) -> str:
    language = block[0].strip()[3:].strip()
    code = "\n".join(block[1:-1])
    opt = f"[breaklines,breakanywhere,fontsize=\\small,frame=single,label={{{escape_tex(language)}}}]" if language else "[breaklines,breakanywhere,fontsize=\\small,frame=single]"
    return rf"\begin{{Verbatim}}{opt}" + "\n" + code + "\n" + r"\end{Verbatim}" + "\n"


def parse_list(block: list[str], ordered: bool) -> str:
    env = "enumerate" if ordered else "itemize"
    out = [rf"\begin{{{env}}}[leftmargin=2em]"]
    pattern = r"^\d+\.\s+" if ordered else r"^[-*]\s+"
    for line in block:
        item = re.sub(pattern, "", line.strip())
        out.append(r"\item " + inline_to_tex(item))
    out.append(rf"\end{{{env}}}")
    return "\n".join(out) + "\n"


def preprocess_figures(text: str) -> str:
    pattern = re.compile(
        r'<p align="center">\s*<img src="([^"]+)" width="([^"]+)">\s*</p>\s*'
        r'<p align="center"><em>(.*?)</em></p>',
        re.DOTALL,
    )

    def repl(match: re.Match[str]) -> str:
        url = match.group(1)
        width_px = float(match.group(2))
        caption = html.unescape(re.sub(r"\s+", " ", match.group(3)).strip())
        asset = FIGURE_MAP.get(url, Path(url).name)
        width_ratio = min(0.98, max(0.65, width_px / 930.0))
        return f"\n[[FIGURE::{asset}::{width_ratio:.2f}::{caption}]]\n"

    return re.sub(pattern, repl, text)


def parse_paragraph(lines: list[str]) -> str:
    text = " ".join(line.strip() for line in lines)
    return inline_to_tex(text) + "\n"


def figure_to_tex(line: str) -> str:
    _, asset, width_ratio, caption = line.split("::", 3)
    width = float(width_ratio)
    caption_tex = inline_to_tex(caption[:-2] if caption.endswith("]]") else caption)
    return "\n".join(
        [
            r"\begin{figure}[H]",
            r"\centering",
            rf"\includegraphics[width={width:.2f}\linewidth]{{{ASSET_DIR / asset}}}",
            rf"\caption{{{caption_tex}}}",
            r"\end{figure}",
        ]
    ) + "\n"


def convert_markdown(text: str) -> str:
    text = preprocess_figures(text)
    lines = text.splitlines()
    out: list[str] = []
    i = 0
    in_appendix = False
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if not stripped:
            out.append("")
            i += 1
            continue

        if stripped.startswith("[[FIGURE::"):
            out.append(figure_to_tex(stripped))
            i += 1
            continue

        if stripped == "$$":
            block = [stripped]
            i += 1
            while i < len(lines):
                block.append(lines[i])
                if lines[i].strip() == "$$":
                    break
                i += 1
            i += 1
            out.append("\n".join(block) + "\n")
            continue

        if stripped == "---":
            out.append(r"\bigskip\hrule\bigskip")
            i += 1
            continue

        if stripped.startswith("```"):
            block = [line]
            i += 1
            while i < len(lines):
                block.append(lines[i])
                if lines[i].strip().startswith("```"):
                    break
                i += 1
            i += 1
            out.append(parse_code(block))
            continue

        if stripped.startswith("|") and i + 1 < len(lines) and re.match(r"^\|(?:\s*:?-+:?\s*\|)+\s*$", lines[i + 1].strip()):
            block = [line, lines[i + 1]]
            i += 2
            while i < len(lines) and lines[i].strip().startswith("|"):
                block.append(lines[i])
                i += 1
            out.append(parse_table(block))
            continue

        if stripped.startswith(">"):
            block = []
            while i < len(lines) and lines[i].strip().startswith(">"):
                block.append(lines[i].strip()[1:].strip())
                i += 1
            quote_text = " ".join(block)
            if "Updated on March 31, 2026" in quote_text:
                continue
            out.append(r"\begin{quote}" + "\n" + parse_paragraph(block) + r"\end{quote}")
            continue

        if re.match(r"^\d+\.\s+", stripped):
            block = []
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i].strip()):
                block.append(lines[i])
                i += 1
            out.append(parse_list(block, ordered=True))
            continue

        if re.match(r"^[-*]\s+", stripped):
            block = []
            while i < len(lines) and re.match(r"^[-*]\s+", lines[i].strip()):
                block.append(lines[i])
                i += 1
            out.append(parse_list(block, ordered=False))
            continue

        if stripped.startswith("#### "):
            title = stripped[5:]
            if not in_appendix:
                title = clean_heading(title)
            out.append(r"\subsubsection{" + inline_to_tex(title) + "}")
            i += 1
            continue
        if stripped.startswith("### "):
            title = stripped[4:]
            if in_appendix:
                out.append(r"\subsection*{" + inline_to_tex(title) + "}")
                out.append(r"\addcontentsline{toc}{subsection}{" + inline_to_tex(title) + "}")
            else:
                out.append(r"\subsection{" + inline_to_tex(clean_heading(title)) + "}")
            i += 1
            continue
        if stripped.startswith("## "):
            title = stripped[3:]
            if title == "摘要":
                out.append(r"\section*{摘要}")
                out.append(r"\addcontentsline{toc}{section}{摘要}")
            elif title == "附錄":
                in_appendix = True
                out.append(r"\appendix")
                out.append(r"\section*{附錄}")
                out.append(r"\addcontentsline{toc}{section}{附錄}")
            else:
                out.append(r"\section{" + inline_to_tex(clean_heading(title)) + "}")
            i += 1
            continue
        if stripped.startswith("# "):
            # Top-level title is handled by the LaTeX preamble.
            i += 1
            continue

        block = [line]
        i += 1
        while i < len(lines):
            next_stripped = lines[i].strip()
            if (
                not next_stripped
                or next_stripped.startswith("#")
                or next_stripped.startswith("```")
                or next_stripped.startswith("|")
                or next_stripped.startswith("[[FIGURE::")
                or next_stripped.startswith(">")
                or re.match(r"^\d+\.\s+", next_stripped)
                or re.match(r"^[-*]\s+", next_stripped)
                or next_stripped == "---"
            ):
                break
            block.append(lines[i])
            i += 1
        out.append(parse_paragraph(block))

    return "\n".join(out)


def build_document(body: str) -> str:
    title = "Multi-Stage LLM Planning: Order-Based and Answer-Based Evaluation of Tool-Augmented Language Models"
    return rf"""\documentclass[11pt,a4paper]{{ctexart}}
\usepackage[a4paper,margin=1in]{{geometry}}
\usepackage{{graphicx}}
\usepackage{{float}}
\usepackage[dvipsnames]{{xcolor}}
\usepackage{{booktabs}}
\usepackage{{longtable}}
\usepackage{{array}}
\usepackage{{caption}}
\usepackage{{enumitem}}
\usepackage{{hyperref}}
\usepackage{{xurl}}
\usepackage{{amsmath,amssymb}}
\usepackage{{fvextra}}
\usepackage{{parskip}}
\usepackage{{setspace}}
\usepackage{{fancyhdr}}
\usepackage{{titlesec}}
\usepackage{{ragged2e}}
\setstretch{{1.12}}
\setlength{{\parindent}}{{2em}}
\setlength{{\parskip}}{{0.45em}}
\emergencystretch=1.8em
\pagestyle{{fancy}}
\fancyhf{{}}
\fancyfoot[C]{{\thepage}}
\hypersetup{{
  colorlinks=true,
  linkcolor=blue!50!black,
  urlcolor=blue!50!black,
  citecolor=blue!50!black
}}
\titleformat{{\section}}{{\Large\bfseries}}{{\thesection}}{{0.75em}}{{}}
\titleformat{{\subsection}}{{\large\bfseries}}{{\thesubsection}}{{0.75em}}{{}}
\titleformat{{\subsubsection}}{{\normalsize\bfseries}}{{\thesubsubsection}}{{0.75em}}{{}}
\IfFontExistsTF{{Noto Serif CJK TC}}{{%
  \setCJKmainfont{{Noto Serif CJK TC}}%
  \setCJKfamilyfont{{zhsong}}{{Noto Serif CJK TC}}%
  \setCJKfamilyfont{{zhfs}}{{Noto Serif CJK TC}}%
}}{{%
  \IfFontExistsTF{{AR PL UMing TW}}{{%
    \setCJKmainfont[AutoFakeBold=2,AutoFakeSlant=.2]{{AR PL UMing TW}}%
    \setCJKfamilyfont{{zhsong}}[AutoFakeBold=2,AutoFakeSlant=.2]{{AR PL UMing TW}}%
    \setCJKfamilyfont{{zhfs}}[AutoFakeBold=2,AutoFakeSlant=.2]{{AR PL UMing TW}}%
  }}{{}}%
}}
\IfFontExistsTF{{Noto Sans CJK TC}}{{%
  \setCJKsansfont{{Noto Sans CJK TC}}%
  \setCJKfamilyfont{{zhhei}}{{Noto Sans CJK TC}}%
}}{{%
  \IfFontExistsTF{{Droid Sans Fallback}}{{%
    \setCJKsansfont[AutoFakeBold=2]{{Droid Sans Fallback}}%
    \setCJKfamilyfont{{zhhei}}[AutoFakeBold=2]{{Droid Sans Fallback}}%
  }}{{}}%
}}
\IfFontExistsTF{{AR PL KaitiM Big5}}{{%
  \setCJKfamilyfont{{zhkai}}[AutoFakeBold=2]{{AR PL KaitiM Big5}}%
}}{{}}
\IfFontExistsTF{{DejaVu Sans Mono}}{{\setmonofont{{DejaVu Sans Mono}}}}{{}}
\title{{{escape_tex(title)}}}
\date{{Updated on March 31, 2026}}

\begin{{document}}
\maketitle
\tableofcontents
\newpage

{body}

\end{{document}}
"""


def main() -> None:
    text = SRC.read_text(encoding="utf-8")
    body = convert_markdown(text)
    tex = build_document(body)
    DST.write_text(tex, encoding="utf-8")
    print(f"Wrote {DST}")


if __name__ == "__main__":
    main()
