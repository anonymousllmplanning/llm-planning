#!/usr/bin/env python3
"""Build Gemma4 replay-filtered Augmented GAIA DAG files.

The public Augmented GAIA release keeps two DAG views:

* ``DAGs/`` contains the GPT-4o dependency annotations plus the unfiltered
  candidate async orderings derived from those dependencies.
* ``Gemma4_Filtered_DAGs/`` keeps the same task-level dependency DAGs, but
  filters ``sampled_orderings`` down to the behavior-preserving orderings
  retained by the Gemma4 replay validation evidence.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, Iterable


RETAINED_TRANSITIONS = {
    "correct_to_correct_same",
    "correct_to_correct_different",
    "wrong_to_wrong_same",
}

POLICY_NAME = "gemma4_behavior_preserving_replay_filter"


def repo_root_from_script() -> Path:
    return Path(__file__).resolve().parents[1]


def read_jsonl(path: Path) -> Iterable[dict]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON in {path}:{line_number}: {exc}") from exc


def write_jsonl(path: Path, rows: Iterable[dict]) -> None:
    with path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=False))
            handle.write("\n")


def load_retained_replay_rows(replay_jsonl: Path) -> tuple[dict[tuple[str, str], dict[int, dict]], Counter]:
    retained: dict[tuple[str, str], dict[int, dict]] = defaultdict(dict)
    transition_counts: Counter = Counter()
    for row in read_jsonl(replay_jsonl):
        transition = row.get("outcome_transition")
        transition_counts[transition] += 1
        if transition not in RETAINED_TRANSITIONS:
            continue
        category = str(row.get("category") or "")
        task_id = str(row.get("task_id") or "")
        ordering_index = int(row.get("ordering_index"))
        if not category or not task_id:
            raise ValueError(f"Replay row missing category/task_id: {row}")
        retained[(category, task_id)][ordering_index] = row
    return retained, transition_counts


def category_from_file_name(path: Path) -> str:
    stem = path.name
    for cat in ("A", "B", "C", "D"):
        if f"cat_{cat}" in stem:
            return cat
    raise ValueError(f"Cannot infer GAIA category from {path}")


def task_id_from_dag_record(record: Dict[str, Any]) -> str:
    meta = record.get("meta") or record.get("metadata") or {}
    return str(meta.get("id") or meta.get("sample_id") or record.get("id") or "")


def filter_dag_records(
    dag_path: Path,
    retained: dict[tuple[str, str], dict[int, dict]],
) -> tuple[list[dict], list[dict], Counter]:
    cat = category_from_file_name(dag_path)
    category = f"cat_{cat}"
    output_rows: list[dict] = []
    task_rows: list[dict] = []
    aggregate = Counter()

    for record in read_jsonl(dag_path):
        task_id = task_id_from_dag_record(record)
        if not task_id:
            raise ValueError(f"DAG record missing task id in {dag_path}")
        sampled_orderings = record.get("sampled_orderings") or []
        retained_for_task = retained.get((category, task_id), {})
        retained_indices = sorted(
            index for index in retained_for_task if 0 <= index < len(sampled_orderings)
        )
        filtered_orderings = [sampled_orderings[index] for index in retained_indices]
        retained_transitions = [
            retained_for_task[index].get("outcome_transition") for index in retained_indices
        ]

        updated = deepcopy(record)
        updated["sampled_orderings"] = filtered_orderings
        metadata = dict(updated.get("metadata") or {})
        metadata["num_candidate_orderings_before_gemma4_filter"] = len(sampled_orderings)
        metadata["num_sampled_orderings"] = len(filtered_orderings)
        metadata["num_gemma4_retained_orderings"] = len(filtered_orderings)
        metadata["num_gemma4_filtered_orderings"] = len(sampled_orderings) - len(filtered_orderings)
        metadata["gemma4_retained_original_ordering_indices"] = retained_indices
        metadata["gemma4_retained_outcome_transitions"] = retained_transitions
        metadata["replay_filter_policy"] = POLICY_NAME
        metadata["replay_filter_model"] = "gemma-4-31B-it"
        updated["metadata"] = metadata
        output_rows.append(updated)

        task_summary = {
            "category": category,
            "task_id": task_id,
            "candidate_orderings": len(sampled_orderings),
            "retained_orderings": len(filtered_orderings),
            "filtered_orderings": len(sampled_orderings) - len(filtered_orderings),
            "retained_original_ordering_indices": " ".join(str(i) for i in retained_indices),
        }
        task_rows.append(task_summary)

        aggregate["tasks"] += 1
        aggregate["candidate_orderings"] += len(sampled_orderings)
        aggregate["retained_orderings"] += len(filtered_orderings)
        aggregate["filtered_orderings"] += len(sampled_orderings) - len(filtered_orderings)
        if filtered_orderings:
            aggregate["tasks_with_retained_ordering"] += 1
        else:
            aggregate["tasks_with_no_retained_ordering"] += 1
        if len(filtered_orderings) == 1:
            aggregate["tasks_with_exactly_one_retained_ordering"] += 1
        if len(filtered_orderings) >= 2:
            aggregate["multi_order_rich_tasks"] += 1

    return output_rows, task_rows, aggregate


def write_task_summary_csv(path: Path, rows: list[dict]) -> None:
    fieldnames = [
        "category",
        "task_id",
        "candidate_orderings",
        "retained_orderings",
        "filtered_orderings",
        "retained_original_ordering_indices",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def relative_path(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def write_manifest(output_dir: Path, source_dag_dir: Path, replay_jsonl: Path, root: Path, augmented_root: Path) -> None:
    text = f"""# Gemma4 Filtered DAGs

This folder contains the replay-filtered Augmented GAIA DAG view.

- Source DAGs: `{relative_path(source_dag_dir, augmented_root)}`
- Replay evidence: `{relative_path(replay_jsonl, root)}`
- Filter policy: `{POLICY_NAME}`
- Replay model: `gemma-4-31B-it`

`DAGs/` stores GPT-4o dependency annotations and all candidate async orderings.
This folder keeps the same task-level dependency DAGs, but replaces
`sampled_orderings` with only the Gemma4 behavior-preserving replay-retained
orderings. Tasks with no retained async ordering remain present and have an
empty `sampled_orderings` list, so the native chain remains the fallback
reference during evaluation.
"""
    (output_dir / "README.md").write_text(text, encoding="utf-8")


def write_summary(path: Path, summary: dict) -> None:
    with path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
        handle.write("\n")


def write_checksums(output_dir: Path, files: list[Path]) -> None:
    with (output_dir / "checksums.sha256").open("w", encoding="utf-8") as handle:
        for path in files:
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            handle.write(f"{digest}  {path.name}\n")


def parse_args() -> argparse.Namespace:
    root = repo_root_from_script()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=root)
    parser.add_argument("--augmented-root", type=Path, default=root / "data/Augmented")
    parser.add_argument("--output-dir-name", default="Gemma4_Filtered_DAGs")
    parser.add_argument(
        "--replay-jsonl",
        type=Path,
        default=root / "replay_evidence/gemma4_replay_validation_catA_20260501_catBCD_20260502.combined.jsonl",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = args.repo_root.resolve()
    augmented_root = args.augmented_root
    source_dag_dir = augmented_root / "DAGs"
    output_dir = augmented_root / args.output_dir_name
    output_dir.mkdir(parents=True, exist_ok=True)

    if not source_dag_dir.exists():
        raise FileNotFoundError(f"Missing source DAG folder: {source_dag_dir}")
    if not args.replay_jsonl.exists():
        raise FileNotFoundError(f"Missing replay evidence file: {args.replay_jsonl}")

    retained, transition_counts = load_retained_replay_rows(args.replay_jsonl)

    per_category: dict[str, dict[str, int]] = {}
    all_task_rows: list[dict] = []
    totals = Counter()
    written_files: list[Path] = []

    for cat in ("A", "B", "C", "D"):
        dag_path = source_dag_dir / f"gaia_cat_{cat}_async_plan.jsonl"
        output_path = output_dir / dag_path.name
        filtered_records, task_rows, aggregate = filter_dag_records(dag_path, retained)
        write_jsonl(output_path, filtered_records)
        written_files.append(output_path)
        all_task_rows.extend(task_rows)
        totals.update(aggregate)
        per_category[f"cat_{cat}"] = dict(aggregate)

    task_summary_path = output_dir / "gemma4_filtered_dag_task_summary.csv"
    write_task_summary_csv(task_summary_path, all_task_rows)
    written_files.append(task_summary_path)

    summary = {
        "description": "Gemma4 replay-filtered Augmented GAIA DAG view.",
        "source_dag_dir": relative_path(source_dag_dir, augmented_root),
        "replay_evidence": relative_path(args.replay_jsonl, root),
        "replay_filter_policy": POLICY_NAME,
        "replay_filter_model": "gemma-4-31B-it",
        "retained_transition_policy": sorted(RETAINED_TRANSITIONS),
        "totals": dict(totals),
        "per_category": per_category,
        "replay_transition_counts": dict(transition_counts),
    }
    summary_path = output_dir / "gemma4_filtered_dag_summary.json"
    write_summary(summary_path, summary)
    written_files.append(summary_path)

    write_manifest(output_dir, source_dag_dir, args.replay_jsonl, root, augmented_root)
    written_files.append(output_dir / "README.md")
    write_checksums(output_dir, written_files)

    print(f"Wrote {output_dir}")
    print(f"Tasks: {totals['tasks']}")
    print(f"Candidates: {totals['candidate_orderings']}")
    print(f"Retained: {totals['retained_orderings']}")


if __name__ == "__main__":
    main()
